// Copyright CESSDA ERIC 2017-2025
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not
// use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import {
  useRange,
  UseRangeProps,
  useRefinementList,
  UseRefinementListProps,
  useSortBy,
  UseSortByProps
} from 'react-instantsearch';

function VirtualRefinementList(props: UseRefinementListProps) {
  useRefinementList(props);

  return null;
}

function VirtualRangeInput(props: UseRangeProps) {
  useRange(props);

  return null;
}

function VirtualSortBy(props: UseSortByProps) {
  useSortBy(props);

  return null;
}

export { VirtualRefinementList, VirtualRangeInput, VirtualSortBy };
