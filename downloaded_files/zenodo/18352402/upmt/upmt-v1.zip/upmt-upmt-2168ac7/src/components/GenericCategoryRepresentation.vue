<template>
  <div class="genericsynchroniccategory-container row"
       v-if="genericcategory"
       :data-genericcategory="genericcategory.name">
    <custom-expansion-item
      class="genericsynchroniccategory-body"
      :expand-icon-class="{ 'invisible': genericcategory.children?.length == 0 }"
      >

      <template v-slot:header>
        <DragElement
          class="genericsynchroniccategory-name"
          :class="{ 'has-error': genericcategory.errors?.length }"
          :style="{ backgroundColor: genericcategory.color }"
          @click="debug"
          type="genericsynchroniccategory"
          :data="genericcategory.name">
          <q-icon
            ref="handle"
            class="genericsynchroniccategory-handle"
            size="xs"
            name="mdi-alpha-s-box" />
          <q-icon
            v-if="isSpecialization"
            size="xs"
            name="mdi-triangle-outline" />
          <q-icon
            v-if="isAggregation"
            size="xs"
            name="mdi-cards-diamond-outline" />

          <q-tooltip class="bg-red-5" anchor="top right" self="top left" v-if="genericcategory.errors?.length">
            <div v-for="error, key in genericcategory.errors"
                    :key="key">
              {{ error }}
            </div>
          </q-tooltip>
          <span
            class="genericsynchroniccategory-label">
            {{ genericcategory.name }} <q-btn
                                         :title="currentInterviewMomentsLabel"
                                         size="sm"
                                         dense>
              <q-menu class="column">
                <div  v-for="moment in currentMoments"
                      class="flex row justify-between"
                      :key="moment.id">
                  <q-btn
                    :label="moment.name"
                    align="left"
                    no-caps
                    flat
                    @click="highlightMoment(moment.id)"
                    size="sm"
                    :style="{ backgroundColor: moment.color }"
                    icon="mdi-alpha-d-box-outline">
                  </q-btn>
                  <q-btn
                    icon="mdi-graph-outline"
                    flat
                    dense
                    size="sm"
                    @click="editSpecificSynchronicModel(moment.specificsynchronicmodel?.id ?? '')">
                  </q-btn>
                </div>
              </q-menu>
              {{ currentMoments.length }}</q-btn> /
            <q-btn
              :title="momentsLabel"
              size="sm"
              dense>
              <q-menu class="column">
                <div class="row items-left no-wrap"
                     :key="name"
                     v-for="[ name, count ] in byInterview(moments)">
                  <q-btn class="full-width justify-content-between"
                         align="left"
                         no-caps
                         :label="name"
                         icon="mdi-comment-text-outline"
                         @click="switchTab(name)"
                         size="sm">
                  </q-btn>
                  <strong class="interview-moment-count">{{ count }}</strong>
                </div>
                <div class="row items-left no-wrap"
                     :key="name"
                     v-for="[ name, modelId, count ] in byDetachedModel(detachedModelInfos)">
                  <q-btn class="full-width justify-content-between"
                         align="left"
                         no-caps
                         :label="name"
                         @click="editSpecificSynchronicModel(modelId)"
                         size="sm">
                  </q-btn>
                  <strong class="interview-moment-count">{{ count }}</strong>
                </div>
              </q-menu>
              {{ moments.length + detachedModelInfos.length }}</q-btn>
            <q-popup-edit
              ref="popupEdit"
              v-model="genericcategoryName"
              auto-save
              v-slot="scope">
              <q-input v-model="scope.value"
                       @focus="($event.target as HTMLInputElement).select()"
                       dense autofocus counter @keyup.enter="scope.set" />
            </q-popup-edit>
          </span>
          <q-space />
          <ElementMenu
            :actions="menuActions" />
        </DragElement>

      </template>

      <div class="genericsynchroniccategory-children">
        <GenericCategoryRepresentation
          v-for="cat in genericcategory.children"
          :key="cat.name"
          :genericGraphs="genericGraphs"
          :genericcategory="cat"
          :currentInterviewId="currentInterviewId"
          />
      </div>
    </custom-expansion-item>
  </div>
</template>

<script setup lang="ts">

  import { computed, ref } from 'vue'
  import { useRouter } from 'vue-router'
  import { useQuasar } from 'quasar'

  import CustomExpansionItem from './CustomExpansionItem.vue'
  import DragElement from './DragElement.vue'
  import ElementMenu from './ElementMenu.vue'
  import SpecificSynchronicModel from 'stores/models/specificsynchronicmodel'
  import Moment from 'stores/models/moment'
  import Interview from 'stores/models/interview'
  import { useProjectStore } from 'stores/projectStore'
  import { useInterfaceStore } from 'stores/interface'
  import { groupBy } from './util'

  import type { GenericCategory, GraphInfo, ContainerInfo } from 'stores/projectStore'

  const istore = useInterfaceStore()

  const store = useProjectStore()

  interface Props {
      genericcategory: GenericCategory,
      genericGraphs: GraphInfo,
      currentInterviewId: string
  }

  const props = withDefaults(defineProps<Props>(), {
      currentInterviewId: ""
  })

  const $q = useQuasar()

  const popupEdit = ref(null)

  const router = useRouter()

  function debug () {
      (window as any).genericcategory = props.genericcategory
      console.log("genericcategory", props.genericcategory)
  }

  const moments = computed((): Moment[] => {
      const momentIds = props.genericcategory.instances
            .map(ssc => props.genericGraphs.instanceIdToContainerInfo[ssc.id]?.momentId)
            .filter(id => !!id) as string[]
      return store.getMoments(momentIds)
  })

  const detachedModelInfos = computed(() => {
      const modelInfos = props.genericcategory.instances
            .map(ssc => props.genericGraphs.instanceIdToContainerInfo[ssc.id])
            .filter(info => info && info.detachedModelId) as ContainerInfo[]
      return modelInfos
  })

  const currentMoments = computed(() => moments.value?.filter((m: Moment) => m.interviewId === props.currentInterviewId) || [])

  const isAggregation = computed(() => props.genericcategory.abstractionType == 'aggregation')
  const isSpecialization = computed(() => props.genericcategory.abstractionType == 'specialization')

  const genericcategoryName = computed({
      get () {
          return props.genericcategory ? props.genericcategory.name : ""
      },
      set (value: string) {
          const instances = props.genericcategory.instances
          console.log(`Renaming ${props.genericcategory.name} to ${value}`)
          $q.dialog({
              title: 'Confirm category renaming',
              html: true,
              message: `Do you confirm the renaming of ${instances.length} Specific Synchronic Categories from <strong>${props.genericcategory.name}</strong> to <strong>${value}</strong>?`,
              cancel: true,
              persistent: true
          }).onOk(() => {
              instances.forEach(ssc => {
                  store.updateElement(ssc, { name: value })
              })
              $q.notify({
                  type: 'info',
                  message: `Renamed ${instances.length} categories as "${value}"`
              })
           })
      }
  })

  const currentInterviewMomentsLabel = computed(() => {
      const count = currentMoments.value.length
      if (count) {
          return `Present in ${count} moments in the current interview`
      } else {
          return "Not present in the current interview"
      }
  })

  const momentsLabel = computed(() => {
      let output = ""
      const count = moments.value.length
      if (count) {
          output = `Present in ${count} moments`
      } else {
          output = "Not present in any interview"
      }
      const countModel = detachedModelInfos.value.length
      if (countModel) {
          output = `${output} and in ${countModel} detached models`
      }
      return output
  })

  function highlightMoment (momentId: string) {
      istore.setHighlightedMomentId(momentId)
  }

  function editSpecificSynchronicModel (modelId: string) {
      istore.setEditedSpecificSynchronicModelId(modelId)
  }

  function byInterview (moments: Array<Moment>) {
      const repo = store.getRepo()
      const names = Object.fromEntries(repo.Interview.get().map((i: Interview) => [ i.id, i.label ]))

      return Object.entries(groupBy(moments, 'interviewId'))
          .map(([id, arr]) => [ names[id], (arr as Array<any>).length ])
  }

  function byDetachedModel (modelInfos: Array<ContainerInfo>) {
      const repo = store.getRepo()
      // ! Detached model name is taken from the SSM proxy name, not directly the DetachedModel instance
      const specificSynchronicModelIds = modelInfos.map(info => info.specificSynchronicModelId)
      const names = Object.fromEntries(repo.SpecificSynchronicModel
          .find(specificSynchronicModelIds)
          .map((i: SpecificSynchronicModel) => [ i.id, i.name ]))
      return specificSynchronicModelIds.map((modelId: string) => [names[modelId], modelId, 1] as [string, string, number] )
  }

  function switchTab (interviewName: string) {
      router.push({
          query: {
              tab: interviewName
          }
      }).catch(e => {
          console.log(`Error when switching view: ${e}`)
      })
  }

  import type { NamedAction } from 'components/util.ts'
  const menuActions: NamedAction[] = [
      [ "Debug", () => debug() ]
  ]
</script>

<style scoped>
  .genericsynchroniccategory-handle {
      opacity: .5;
      cursor: pointer;
  }
  .genericsynchroniccategory-handle:hover {
      opacity: .7;
  }
  .genericsynchroniccategory-name {
      align-items: center;
  }
  .genericsynchroniccategory-name:hover .on-name-hover {
      opacity: 1;
  }
  .genericsynchroniccategory-children {
      border-left: 1px dotted black;
  }
  .q-list--dense > .q-item, .q-item--dense {
    min-height: 18px;
    padding: 0 2px !important;
    line-height: 1;
  }
  .interview-name {
      font-weight: 200;
  }
  .has-error {
      border: 2px solid red;
  }
</style>
