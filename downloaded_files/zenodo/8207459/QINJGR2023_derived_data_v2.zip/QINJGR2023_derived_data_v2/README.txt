Description of the files

1. Altitude_IUVS_bestfit_YYYYMM.txt

This is the file that contains the coronal scan derived from the IUVS level 1b data.

First column: Tangent point altitudes of the lines-of-sight (km)

Second column: Intensities measured by IUVS (Rayleigh)

Third column: Best-fit intensities obtained from the inversion (Rayleigh)

2. plot_IUVS_bestfit.m

This is a simple MATLAB code that can be used to plot the results.

3. Table1

Same as Table 1 in the manuscript.