clc
clear

data = load('Altitude_IUVS_bestfit_201601.txt');

altitude = data(:,1);
iuvs = data(:,2);
bestfit = data(:,3);

figure(1)
semilogx(iuvs,altitude,'b+','linewidth',1.0,'MarkerSize',6.0)
hold on
semilogx(bestfit,altitude,'-r','linewidth',1.5)
set(gca, 'FontSize', 20)
axis([5e-1 1e3 0 4200])
xlabel('Intensity (R)', 'FontSize', 20)
ylabel('Altitude (km)', 'FontSize', 20)
