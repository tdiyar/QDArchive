
class Query:

    @classmethod
    # construct the query string include variety of sentences
    def construct_query_string(cls):
        # verbs = ['have', 'use', 'got']
        # vendors = ['PayPal', 'cashapp', 'venmo']
        # # Construct the query string using the provided verbs and vendors
        # verb_query = ' OR '.join(f'"{verb}"' for verb in verbs)
        # vendor_query = ' OR '.join(f'"{vendor}"' for vendor in vendors)
        # query = f'("you" ({verb_query}) ({vendor_query}))'

        # query_string = (
        #     '("do you have" OR "can you accept" OR "can I send you" OR "do you take" OR "do you use" OR '
        #     '"is it possible to pay with" OR "do you accept" OR "can you provide" OR "can I donate via" OR '
        #     '"can I pay via" OR "can I send money via" OR "you got a" OR "send me your" OR "share your") '
        #     '"and" ("paypal" OR "venmo" OR "zelle" OR "cash app" OR "apple pay" OR "google pay")'
        # )

        # testing query string
        query_string = '"do you have paypal"'
        return query_string
