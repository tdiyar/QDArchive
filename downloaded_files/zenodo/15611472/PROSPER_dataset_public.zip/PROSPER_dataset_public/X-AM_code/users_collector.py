import os
import json
import tweepy
import time
from config import Config
from datetime import datetime


class UserInfoProcessor:
    def __init__(self, source_folder, user_info_folder, bearer_token):
        self.source_folder = source_folder
        self.user_info_folder = user_info_folder
        self.bearer_token = bearer_token

    def process_user_info(self):
        while True:
            print("Starting user information processing cycle...")
            for filename in os.listdir(self.source_folder):
                if filename.endswith('.json'):
                    file_path = os.path.join(self.source_folder, filename)
                    print(f"Processing file: {filename}")
                    try:
                        with open(file_path, 'r') as file:
                            data = json.load(file)
                    except json.JSONDecodeError as e:
                        print(f"Error decoding JSON from file {filename}: {e}")
                        continue

                    if any(item.get("ignored") == "yes" for item in data):
                        print(f"File {filename} is already processed.")
                        continue

                    clusters = self.group_users_by_cluster(data)
                    if clusters:
                        conversation_id = self.extract_conversation_id(filename)
                        try:
                            self.fetch_and_save_user_info(clusters, conversation_id)
                            self.mark_as_ignored(file_path, data)
                            print(f"File {filename} processed and user information saved.")
                        except tweepy.errors.TweepyException as e:
                            print(f"Tweepy error occurred: {e}")
                            # Handle Tweepy exceptions here
                        except Exception as e:
                            print(f"Unexpected error processing file {filename}: {e}")
                            # Handle other unexpected errors here
                    else:
                        print(f"No valid clusters found in file {filename}.")
                        self.mark_as_ignored(file_path, data)

            print("User information processing cycle completed. Waiting for the next cycle...")
            time.sleep(900)  # Wait for 15 minutes between cycles

    def group_users_by_cluster(self, data):
        clusters = {}
        for item in data:
            cluster = item.get("cluster")
            if cluster is not None and cluster >= 0:
                user = item["user"]
                if cluster not in clusters:
                    clusters[cluster] = set()
                clusters[cluster].add(user)

        # Remove clusters with fewer than 2 distinct users
        clusters = {k: v for k, v in clusters.items() if len(v) >= 2}
        return clusters

    def fetch_and_save_user_info(self, clusters, conversation_id):
        client = tweepy.Client(bearer_token=self.bearer_token)

        user_info = {}
        for cluster, users in clusters.items():
            user_info[cluster] = []
            for user in users:
                try:
                    user_data = client.get_users(usernames=[user],
                                                 user_fields=['id', 'name', 'username', 'created_at', 'description',
                                                              'profile_image_url', 'location', 'public_metrics',
                                                              'protected', 'url', 'verified', 'entities']).data

                    if user_data is None:
                        user_dict = {'username': user,
                                     'id': '',
                                     'name': '',
                                     'created_at': '',
                                     'description': '',
                                     'profile_image_url': '',
                                     'location': '',
                                     'public_metrics': {},
                                     'protected': '',
                                     'url': '',
                                     'verified': '',
                                     'entities': {}}
                    else:
                        # Assuming we always get one user back

                        user_data = user_data[0] if user_data[0] else {}
                        user_dict = {
                            'username': user_data.get('username', user),
                            'id': user_data.get('id', ''),
                            'name': user_data.get('name', ''),
                            'created_at': self.format_datetime(user_data.get('created_at', ' ')),
                            'description': user_data.get('description', ''),
                            'profile_image_url': user_data.get('profile_image_url', ''),
                            'location': user_data.get('location', ''),
                            'public_metrics': user_data.get('public_metrics', {}),
                            'protected': user_data.get('protected', ''),
                            'url': user_data.get('url', ''),
                            'verified': user_data.get('verified', ''),
                            'entities': user_data.get('entities', {})
                        }

                    user_info[cluster].append(user_dict)
                except tweepy.errors.TweepyException as e:
                    print(f"Tweepy error fetching data for user {user}: {e}")
                    raise  # Raise the exception to handle it in the caller (process_user_info)
                except Exception as e:
                    print(f"Unexpected error fetching data for user {user}: {e}")
                    raise  # Raise the exception to handle it in the caller (process_user_info)

        if not os.path.exists(self.user_info_folder):
            os.makedirs(self.user_info_folder)

        for cluster, info in user_info.items():
            file_path = os.path.join(self.user_info_folder, f"cluster_{cluster}_conversation_{conversation_id}.json")
            with open(file_path, 'w') as file:
                json.dump(info, file, indent=4)

    def mark_as_ignored(self, file_path, data):
        for item in data:
            item["ignored"] = "yes"
        with open(file_path, 'w') as file:
            json.dump(data, file, indent=4)

    def extract_conversation_id(self, filename):
        try:
            return filename.split('_')[1].split('.')[0]
        except IndexError:
            return 'unknown'

    def format_datetime(self, dt):
        if isinstance(dt, datetime):
            return dt.isoformat()
        return str(dt)  # Fallback in case dt is not datetime


if __name__ == "__main__":
    source_folder = "potential_positive"
    user_info_folder = "users"

    bearer_token = Config.BEARER_TOKEN

    processor = UserInfoProcessor(source_folder, user_info_folder, bearer_token)
    processor.process_user_info()
