import os
import json
import requests
import time


class ProfileImageDownloader:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.profile_pics_folder = 'profile_pics'
        os.makedirs(self.profile_pics_folder, exist_ok=True)

    def run(self):
        while True:
            self.process_files()
            print("Cycle complete. Sleeping for 2 minutes...")
            time.sleep(120)  # Sleep for 15 minutes

    def process_files(self):
        json_files = [f for f in os.listdir(self.folder_path) if f.endswith('.json')]

        for json_file in json_files:
            try:
                self.process_file(json_file)
            except Exception as e:
                print(f"Error processing file {json_file}: {e}")
            print(f"Finished processing file {json_file}. Sleeping for 10 seconds...")
            time.sleep(10)  # Sleep for 10 seconds after processing each file

    def process_file(self, json_file):
        file_path = os.path.join(self.folder_path, json_file)
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)

        json_file_base = os.path.splitext(json_file)[0]
        json_file_folder = os.path.join(self.profile_pics_folder, json_file_base)
        os.makedirs(json_file_folder, exist_ok=True)

        for user_dict in data:
            if user_dict.get("count", 0) >= 3:
                continue

            try:
                if self.process_user(user_dict, json_file_folder):
                    user_dict["count"] = 3
                    print(f"Processed user {user_dict['username']}")
                else:
                    user_dict["count"] = user_dict.get("count", 0) + 1
            except Exception as e:
                user_dict["count"] = user_dict.get("count", 0) + 1
                print(f"Error processing user {user_dict['username']}: {e}")

            print("Sleeping for 3 seconds before processing next user")
            time.sleep(3)  # Sleep for 3 seconds after each user

        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(data, file, ensure_ascii=False, indent=4)

    def process_user(self, user_dict, json_file_folder):
        if not user_dict.get('profile_image_url'):
            print(f"No profile image URL for user {user_dict['username']}")
            return False

        return self.download_image(user_dict, json_file_folder)

    def download_image(self, user_dict, json_file_folder):
        username = user_dict['username']
        image_url = user_dict['profile_image_url']
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://twitter.com/'
        }

        try:
            response = requests.get(image_url, headers=headers, timeout=10)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"Failed to download image for user {username}: {e}")
            return False

        file_extension = image_url.split('.')[-1].split('?')[0]  # handle URL parameters
        image_path = os.path.join(json_file_folder, f"{username}.{file_extension}")

        try:
            with open(image_path, 'wb') as file:
                file.write(response.content)
        except IOError as e:
            print(f"Failed to save image for user {username}: {e}")
            return False

        return True


if __name__ == "__main__":
    downloader = ProfileImageDownloader('users')
    downloader.run()
