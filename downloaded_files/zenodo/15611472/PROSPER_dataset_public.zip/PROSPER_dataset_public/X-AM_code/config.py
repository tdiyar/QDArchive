# config.py

class Config:
    API_KEY = ''
    API_SECRET_KEY = ''
    ACCESS_TOKEN = ''
    ACCESS_TOKEN_SECRET = ''
    BEARER_TOKEN = ''

