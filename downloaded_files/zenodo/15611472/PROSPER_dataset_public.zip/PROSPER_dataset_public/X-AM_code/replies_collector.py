import tweepy
import json
import os
import time
from datetime import datetime
from config import Config
from datetime import datetime, timedelta
# from config import Config1

class TwitterAPI:
    def __init__(self, bearer_token):
        self.client = tweepy.Client(bearer_token=bearer_token)

    @staticmethod
    def datetime_to_str(dt):
        if isinstance(dt, datetime):
            return dt.isoformat()
        return dt

    # this is to get information of a particular tweet id and return a dictionary
    def get_tweet(self, tweet_id):
        current_tweet = self.client.get_tweet(tweet_id,
                                              tweet_fields=[
                                                  'author_id', 'conversation_id', 'created_at', 'text',
                                                  'public_metrics', 'entities', 'lang', 'source',
                                                  'referenced_tweets', 'possibly_sensitive'
                                              ],
                                              expansions='author_id')

        # Check if the current_tweet object and its data are valid
        if not current_tweet or not current_tweet.data:
            return {
                'tweet_id': tweet_id,
                'created_at': '',
                'user': '',
                'user_profile': '',
                'user_description': '',
                'text': '',
                'public_metrics': {"reply_count": 0, "retweet_count": 0},
                'entities': {},
                'lang': '',
                'source': '',
                'possibly_sensitive': False
            }

        current_tweet_data = current_tweet.data
        current_tweet_user = current_tweet.includes['users'][0] if 'users' in current_tweet.includes and \
                                                                   current_tweet.includes['users'] else {}

        current_tweet_info = {
            'tweet_id': current_tweet_data.get('id', ''),
            'created_at': self.datetime_to_str(current_tweet_data.get('created_at', '')),
            'user': current_tweet_user.get('username', ''),
            'user_profile': current_tweet_user.get('url', ''),
            'user_description': current_tweet_user.get('description', ''),
            'text': current_tweet_data.get('text', ''),
            'public_metrics': current_tweet_data.get('public_metrics', {}),
            'entities': current_tweet_data.get('entities', {}),
            'lang': current_tweet_data.get('lang', ''),
            'source': current_tweet_data.get('source', ''),
            'possibly_sensitive': current_tweet_data.get('possibly_sensitive', False)
        }

        return current_tweet_info

    # this is to get the replies of a tweet id along with that tweet and also the tweet to which it relies to
    # A --> B --> C
    def get_conversation(self, tweet_id, conversation_id):
        try:
            # Get the details of the current tweet (tweet B)
            current_tweet_info = self.get_tweet(tweet_id)

            public_metrics = current_tweet_info['public_metrics']

            # Check if the tweet has at least 1 reply or retweet
            if public_metrics['reply_count'] + public_metrics['retweet_count'] < 1:
                print(f"Tweet ID {tweet_id} has insufficient interactions. Skipping.")
                return

            # after this tweet is eligible to pull

            # get the details of its parent tweet which is A

            parent_tweet_info = self.get_tweet(conversation_id)

            query = f'(in_reply_to_tweet_id:{tweet_id})'
            # query = f'(id:{tweet_id})'
            # query = f'(in_reply_to_tweet_id:{tweet_id} OR retweets_of_tweet_id:{tweet_id})'
            interactions = []
            next_token = None

            while True:
                response = self.client.search_recent_tweets(
                    query=query,
                    tweet_fields=[
                        'author_id', 'conversation_id', 'created_at', 'text',
                        'public_metrics', 'entities', 'lang', 'source',
                        'referenced_tweets', 'possibly_sensitive'
                    ],
                    expansions='author_id',
                    next_token=next_token,
                    max_results=100
                )

                if response.data:
                    interactions.extend(response.data)
                    next_token = response.meta.get('next_token')
                    if not next_token:
                        break
                else:
                    break

            conversation = [parent_tweet_info, current_tweet_info]

            # Sort interactions by created_at timestamp
            interactions = sorted(interactions, key=lambda x: x['created_at'])

            for interaction in interactions:
                interaction_user = next((u for u in response.includes['users'] if u['id'] == interaction['author_id']),
                                        None)
                if interaction_user:
                    conversation.append({
                        'tweet_id': interaction['id'],
                        'created_at': self.datetime_to_str(interaction['created_at']),
                        'user': interaction_user['username'],
                        'user_profile': interaction_user.get('url', ''),
                        'user_description': interaction_user.get('description', ''),
                        'text': interaction['text'],
                        'public_metrics': interaction['public_metrics'],
                        'entities': interaction.get('entities', {}),
                        'lang': interaction['lang'],
                        'source': interaction['source'],
                        'possibly_sensitive': interaction.get('possibly_sensitive', False)
                    })

            os.makedirs('conversations', exist_ok=True)
            filename = f'conversations/conversation_{tweet_id}.json'
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(conversation, f, ensure_ascii=False, indent=4)

            print(f"Conversation saved to {filename}")

        except tweepy.TweepyException as e:
            print(f"Error: {e}")

    def process_files(self):
        directory = 'files'
        current_time = datetime.utcnow()
        time_threshold = current_time - timedelta(minutes=20)

        for filename in os.listdir(directory):
            if filename.endswith('.json'):
                try:
                    filepath = os.path.join(directory, filename)
                    with open(filepath, 'r', encoding='utf-8') as file:
                        data = json.load(file)
                    print(f"Opening file {filename}")
                    for tweet in data:
                        # check if the tweet is already handled and no need to check
                        ignore_status = tweet.get("ignored", "no")
                        if ignore_status == "yes":
                            print(f"Tweet ID {tweet['id']} has been handled. Skipping.")
                            continue

                        # This id is for the current tweet called B
                        tweet_id = tweet['id']
                        # This id is for the original tweet which B replied to called A
                        conversation_id = tweet.get('conversation_id', '')
                        # This id is for the original tweet which B replied to called A
                        self.get_conversation(tweet_id, conversation_id)
                        # check if the tweet was past 120 minutes
                        tweet_created_at = datetime.strptime(tweet['created_at'], "%Y-%m-%dT%H:%M:%S.%fZ")
                        if tweet_created_at <= time_threshold:
                            tweet["ignored"] = "yes"

                    # Rewrite the JSON file with the updated data
                    with open(filepath, 'w', encoding='utf-8') as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)

                    # stop for a minute before making another call. the rate limit for get tweet is 15/ 15 minutes
                    print("Entering sleep mode for 1 minute")
                    time.sleep(60)

                except Exception as e:
                    print(f"Error processing file {filename}: {e}")

                    # in case something happens, stop for a minute as well
                    print("Entering sleep mode for 1 minute")
                    time.sleep(60)


# Example usage:
if __name__ == "__main__":
    api_key = Config.API_KEY
    api_secret_key = Config.API_SECRET_KEY
    access_token = Config.ACCESS_TOKEN
    access_token_secret = Config.ACCESS_TOKEN_SECRET
    bearer_token = Config.BEARER_TOKEN

    twitter_api = TwitterAPI(bearer_token)

    while True:
        print("Starting processing the tweet files")
        twitter_api.process_files()
        print("Entering sleep mode for 5 minutes")
        time.sleep(300)  # Wait for 5 minutes before checking again
