import tweepy
import json
from config import Config

import pytz
from datetime import datetime
import time
import os
import construct_query_string

from datetime import datetime, timedelta


#########################################################################################################

# this part is to collect recent Tweets with Basic API including handles, profiles pictures, tweets   #


#########################################################################################################

class TwitterAPI:

    def __init__(self, bearer_token):
        self.client = tweepy.Client(bearer_token=bearer_token)
        self.last_checked = datetime.utcnow() - timedelta(minutes=20)  # Initialize to 20 minutes ago

    def get_recent_tweets_count(self, query, start_time=None, end_time=None):
        count_response = self.client.get_recent_tweets_count(
            query=query,
            start_time=start_time,
            end_time=end_time,
            granularity='minute'
        )
        return count_response.meta['total_tweet_count']

    def search_recent_tweets(self, query, max_results, start_time=None, end_time=None, next_token=None):
        tweets = self.client.search_recent_tweets(
            query=query,
            max_results=max_results,
            start_time=start_time,
            end_time=end_time,
            next_token=next_token,
            tweet_fields=[
                'attachments', 'author_id', 'context_annotations', 'conversation_id', 'created_at',
                'entities', 'geo', 'id', 'in_reply_to_user_id', 'lang', 'public_metrics',
                'possibly_sensitive', 'referenced_tweets', 'reply_settings', 'source', 'text',
                'withheld'
            ],
            user_fields=[
                'created_at', 'description', 'entities', 'id', 'location', 'name',
                'pinned_tweet_id', 'profile_image_url', 'protected', 'public_metrics',
                'url', 'username', 'verified', 'withheld'
            ],
            place_fields=[
                'contained_within', 'country', 'country_code', 'full_name', 'geo',
                'id', 'name', 'place_type'
            ],
            media_fields=[
                'duration_ms', 'height', 'media_key', 'preview_image_url', 'type', 'url', 'width',
                'public_metrics', 'alt_text'
            ],
            poll_fields=[
                'duration_minutes', 'end_datetime', 'id', 'options', 'voting_status'
            ],
            expansions='author_id'
        )
        return tweets

    def collect_tweet_data(self):
        # query_string = '"do you have paypal"'
        query_string = construct_query_string.Query.construct_query_string()

        end_time = datetime.utcnow() - timedelta(seconds=10)  # Adjust end_time to be 10 seconds before now
        start_time = self.last_checked

        # Check if there are new tweets in the last 15 minutes
        tweet_count = self.get_recent_tweets_count(
            query=query_string,
            start_time=start_time.isoformat("T") + "Z",
            end_time=end_time.isoformat("T") + "Z"
        )
        print(f"Found {tweet_count} tweets for the given query search")
        if tweet_count > 0:
            all_tweets = []
            next_token = None

            # Pagination Handling (there are more than 100 tweets)

            backoff_time = 1  # initial backoff time in seconds

            while True:
                try:
                    tweets_response = self.search_recent_tweets(
                        query=query_string,
                        max_results=100,
                        start_time=start_time.isoformat("T") + "Z",
                        end_time=end_time.isoformat("T") + "Z",
                        next_token=next_token
                    )

                    if tweets_response.data:
                        print(f"Found {len(tweets_response.data)} tweets in the Pagination process")
                        all_tweets.extend(tweets_response.data)
                    else:
                        break

                    next_token = tweets_response.meta.get('next_token')
                    if not next_token:
                        break

                    backoff_time = 1  # reset backoff time on successful request

                except tweepy.TweepyException as e:
                    print(f"Error: {e}")
                    if 'rate limit' in str(e).lower():
                        print(f"Rate limit exceeded, sleeping for {backoff_time} seconds...")
                        time.sleep(backoff_time)
                        backoff_time = min(backoff_time * 2, 300)  # exponential backoff, max 5 minutes
                    else:
                        print("Encountered an error, but continuing...")
                        break
            self.last_checked = end_time  # Update the last checked time to now

            if all_tweets:
                filename = f'files/tweet_data_{start_time.strftime("%Y%m%d_%H%M%S")}_to_{end_time.strftime("%Y%m%d_%H%M%S")}.json'
                self.save_to_json(all_tweets, filename)
                print(f"Tweets saved to {filename}")
            else:
                print("No new tweets found.")
        else:
            print("No new tweets to collect.")

    def save_to_json(self, tweets_response, output_file):
        # Create the directory if it doesn't exist
        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        tweets_data = [tweet.data for tweet in tweets_response]

        with open(output_file, 'w', encoding='utf-8') as json_file:
            json.dump(tweets_data, json_file, indent=4, ensure_ascii=False)

    #########################################################################################################

    # this part is to collect information about an user based on an user_id                                #

    #########################################################################################################

    def get_user_info(self, user_id):
        user = self.api.get_user(user_id)
        return {
            'user_id': user.id,
            'username': user.screen_name,
            'profile_picture': user.profile_image_url_https,
            'description': user.description,
            'followers_count': user.followers_count,
            'friends_count': user.friends_count,
            'statuses_count': user.statuses_count
            # Add more fields as needed
        }

    def collect_user_data(self, user_ids):
        user_data = []
        for user_id in user_ids:
            user_info = self.get_user_info(user_id)
            user_data.append(user_info)
        return user_data

    def get_recent_tweets_by_user(self, user_id, tweet_count=10):
        tweets = self.api.user_timeline(user_id=user_id, count=tweet_count)
        return [{
            'tweet_id': tweet.id,
            'text': tweet.text,
            'created_at': tweet.created_at,
            'retweet_count': tweet.retweet_count,
            'favorite_count': tweet.favorite_count
        } for tweet in tweets]


# Example usage
if __name__ == "__main__":
    api_key = Config.API_KEY
    api_secret_key = Config.API_SECRET_KEY
    access_token = Config.ACCESS_TOKEN
    access_token_secret = Config.ACCESS_TOKEN_SECRET
    bearer_token = Config.BEARER_TOKEN

    twitter_api = TwitterAPI(bearer_token)

    # twitter_api.collect_tweet_data()

    while True:
        print("Starting collecting the tweets")
        twitter_api.collect_tweet_data()
        print("Entering sleep mode for 20 minutes")
        time.sleep(1200)  # Wait for 20 minutes before checking again
