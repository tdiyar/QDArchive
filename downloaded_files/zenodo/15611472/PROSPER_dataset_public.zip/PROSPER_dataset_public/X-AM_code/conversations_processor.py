import os
import json
import shutil
import time
from difflib import SequenceMatcher
from sklearn.cluster import DBSCAN
import numpy as np
import Levenshtein

# this is the main file being run right now

class ConversationProcessor:
    def __init__(self, source_folder, target_folder):
        self.source_folder = source_folder
        self.target_folder = target_folder

    def process_conversations(self):
        while True:
            print("Starting processing cycle...")
            for filename in os.listdir(self.source_folder):
                if filename.endswith('.json'):
                    file_path = os.path.join(self.source_folder, filename)
                    print(f"Processing file: {filename}")
                    try:
                        with open(file_path, 'r') as file:
                            data = json.load(file)
                    except json.JSONDecodeError as e:
                        print(f"Error decoding JSON from file {filename}: {e}")
                        continue

                    if not any(item.get("ignored") == "yes" for item in data):
                        # clusters = self.assign_clusters_dbscan(data)

                        # clusters = self.assign_clusters_heuristic_rules(data)

                        clusters = self.assign_clusters_Levenshtein(data)

                        new_data = self.update_data_with_clusters(data, clusters)
                        self.save_new_data(file_path, new_data)
                        self.mark_as_ignored(file_path, data)
                        print(f"File {filename} processed successfully and saved to {self.target_folder}")
                    else:
                        print(f"File {filename} is already processed")

            print("Processing cycle completed. Waiting for the next cycle...")
            time.sleep(900)  # Wait for 15 minutes (900 seconds)

    def assign_clusters_dbscan(self, data):
        users = [item["user"] for item in data]
        if len(users) < 2:
            return [-1] * len(users)  # No clustering needed for less than 2 users

        similarity_matrix = np.zeros((len(users), len(users)))

        for i in range(len(users)):
            for j in range(i + 1, len(users)):
                similarity = SequenceMatcher(None, users[i], users[j]).ratio()
                similarity_matrix[i][j] = similarity
                similarity_matrix[j][i] = similarity

        clustering = DBSCAN(metric='precomputed', min_samples=1, eps=0.8).fit(1 - similarity_matrix)
        return clustering.labels_.tolist()  # Convert numpy array to list

    def assign_clusters_heuristic_rules(self, data):
        users = [item["user"] for item in data]
        if len(users) < 2:
            return [-1] * len(users)  # No clustering needed for less than 2 users

        threshold = 0.8  # Define similarity threshold
        parent = list(range(len(users)))

        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]

        def union(x, y):
            rootX = find(x)
            rootY = find(y)
            if rootX != rootY:
                parent[rootY] = rootX

        for i in range(len(users)):
            for j in range(i + 1, len(users)):
                similarity = SequenceMatcher(None, users[i], users[j]).ratio()
                if similarity >= threshold:
                    union(i, j)

        clusters = [find(i) for i in range(len(users))]
        cluster_map = {val: idx for idx, val in enumerate(set(clusters))}
        clusters = [cluster_map[val] for val in clusters]
        return clusters


    def assign_clusters_Levenshtein(self, data):
        users = [item["user"] for item in data]
        if len(users) < 2:
            return [-1] * len(users)  # No clustering needed for less than 2 users

        threshold_distance = 3  # Define distance threshold
        parent = list(range(len(users)))

        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]

        def union(x, y):
            rootX = find(x)
            rootY = find(y)
            if rootX != rootY:
                parent[rootY] = rootX

        for i in range(len(users)):
            for j in range(i + 1, len(users)):
                # Compute the Levenshtein distance
                distance = Levenshtein.distance(users[i], users[j])

                if distance <= threshold_distance:
                    union(i, j)

        clusters = [find(i) for i in range(len(users))]
        cluster_map = {val: idx for idx, val in enumerate(set(clusters))}
        clusters = [cluster_map[val] for val in clusters]
        return clusters


    def update_data_with_clusters(self, data, clusters):
        new_data = []
        for i, item in enumerate(data):
            new_item = item.copy()  # Copy the dictionary to avoid altering the original
            new_item["cluster"] = int(clusters[i])  # Ensure the cluster label is an int
            new_data.append(new_item)
        return new_data

    def save_new_data(self, file_path, new_data):
        if not os.path.exists(self.target_folder):
            os.makedirs(self.target_folder)
        new_file_path = os.path.join(self.target_folder, os.path.basename(file_path))
        with open(new_file_path, 'w') as new_file:
            json.dump(new_data, new_file, indent=4)

    def mark_as_ignored(self, file_path, data):
        for item in data:
            item["ignored"] = "yes"
        with open(file_path, 'w') as file:
            json.dump(data, file, indent=4)


if __name__ == "__main__":
    source_folder = "conversations"
    target_folder = "potential_positive"
    processor = ConversationProcessor(source_folder, target_folder)
    processor.process_conversations()
