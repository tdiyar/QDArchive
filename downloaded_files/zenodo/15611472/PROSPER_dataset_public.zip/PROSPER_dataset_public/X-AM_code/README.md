# X-AM_code README

This folder contains the code for **X-AM** (“X-API Maximizer”), a pipeline that:
1. Collects trigger tweets ("Trigger Tweet Hunter")  
2. Monitors replies to those tweets for potential PROSPER attacks  
3. Flags conversations with similar handles (edit distance ≤ 3)  
4. Fetches user profiles and profile pictures for flagged accounts  

Below are instructions to install dependencies, configure API keys, and run each module.

---

## Requirements

Install the following Python packages:

- `tweepy`
- `pytz`
- `scikit-learn` (for `DBSCAN`)
- `numpy`
- `python-Levenshtein`
- `requests`

```bash
pip install tweepy pytz scikit-learn numpy python-Levenshtein requests
```
### Note: This code was developed on Python 3.9+. Standard-library modules (json, datetime, time, os, shutil, difflib) are used but do not require separate installation.

## Configuration

1. Open config.py.
2. Replace each empty string in the Config class with your X API credentials:
3. Save config.py. All modules will use these credentials.


## Module Overview

- **`construct_query_string.py`**  
  - Contains our custom, long-tailored search query used to collect trigger tweets.

- **`tweets_collector.py`**  
  - **Trigger Tweet Hunter**:  
    - Runs every 20 minutes.  
    - Uses the query from `construct_query_string.py` to find candidate trigger tweets.  
    - Saves raw tweet JSONs into the `files/` folder.

- **`replies_collector.py`**  
  - **PROSPER attack activities Monitor**:  
    - Runs every 5 minutes.  
    - Monitors each trigger tweet (from `files/`) for up to 12 hours for new activities.  
    - Saves conversation JSONs into the `conversations/` folder whenever replies are detected.

- **`conversations_processor.py`**  
  - **Potential PROSPER attacks Collector**:  
    - Scans every conversation in `conversations/`.  
    - Computes Levenshtein edit distance between the trigger‐tweet author’s handle and each replier’s handle.  
    - If any handle pair has edit distance ≤ 3, moves that conversation to `potential_positive/` as a potential PROSPER attack.

- **`users_collector.py`** and **`profile_pictures_collector.py`**  
  - **User Info & Profile Picture Collector**:  
    - For each JSON in `potential_positive/`, `users_collector.py` fetches all user profiles (handles, usernames, metadata) and saves them into `users/`.  
    - `profile_pictures_collector.py` downloads each flagged user’s profile picture into `profile_pics/`.

---

## Running X-AM

1. **Install dependencies** (see `Requirements` section in the root README).  
2. **Configure API keys** in `config.py`.  
3. **Launch all modules simultaneously**:  
```bash
# Trigger Tweet Hunter
python tweets_collector.py

# PROSPER attack activities Monitor
python replies_collector.py

# Potential PROSPER attacks Collector
python conversations_processor.py

# User Info Collector
python users_collector.py

# Profile Picture Downloader
python profile_pictures_collector.py
```



---