import os
import json
from datetime import datetime
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np
from Levenshtein import editops
import Levenshtein
import seaborn as sns

from datetime import datetime, timedelta, timezone
from config import Config
import tweepy
import re

import random
import string
import pandas as pd
from difflib import SequenceMatcher
from collections import defaultdict, Counter
import matplotlib.dates as mdates
from matplotlib.dates import DateFormatter

class Analysis:
    def __init__(self, potential_positive_path, users_path, bearer_token):
        self.potential_positive_path = potential_positive_path
        self.users_path = users_path
        self.bearer_token = bearer_token

    def format_datetime(self, dt):
        if isinstance(dt, datetime):
            return dt.isoformat()
        return str(dt)  # Fallback in case dt is not datetime

    ############ 1 #############
    # Analyze the usual time it takes for scammers to target a tweet, filtering unique users
    def analyze_time_delta_to_target_a_tweet(self):
        time_buckets = {
            "0-15 min": 0,
            "15-30 min": 0,
            "30-60 min": 0,
            "1-2 hrs": 0,
            "2-24 hrs": 0,
            ">24 hrs": 0
        }

        # take the time of the scammer tweets to visualize the time period in the day that they usually target
        time_list = []

        # take the time diff to visualize the CDF
        time_diff_list = []
        # Iterate through all JSON files in the folder
        for filename in os.listdir(self.potential_positive_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.potential_positive_path, filename)
                with open(filepath, 'r') as file:
                    tweets = json.load(file)

                # Group tweets by "cluster"
                clusters = {}
                for tweet in tweets:
                    cluster_id = tweet['cluster']
                    if cluster_id not in clusters:
                        clusters[cluster_id] = []
                    clusters[cluster_id].append(tweet)

                first_tweet_time = datetime.strptime(tweets[1]["created_at"], "%Y-%m-%dT%H:%M:%S%z")
                # For clusters with size >= 2 unique users, calculate time differences
                for cluster_id, tweet_list in clusters.items():
                    unique_users = {}

                    # Track the first tweet from each unique user
                    for tweet in tweet_list:
                        user = tweet['user']
                        if user not in unique_users:
                            unique_users[user] = tweet  # Keep the first tweet from this user

                    # Proceed only if there are at least 2 unique users in the cluster
                    if len(unique_users) >= 2:
                        # Sort the tweets from unique users by creation time
                        unique_tweets = sorted(unique_users.values(),
                                               key=lambda x: datetime.strptime(x['created_at'], "%Y-%m-%dT%H:%M:%S%z"))
                        # Calculate the time differences and categorize them into buckets
                        for tweet in unique_tweets[1:]:
                            current_tweet_time = datetime.strptime(tweet['created_at'], "%Y-%m-%dT%H:%M:%S%z")
                            time_list.append(current_tweet_time)

                            time_diff_minutes = (
                                                        current_tweet_time - first_tweet_time).total_seconds() / 60  # in minutes

                            time_diff_list.append(time_diff_minutes)

                            # Categorize time differences into predefined buckets
                            if time_diff_minutes <= 15:
                                # print(time_diff_minutes)
                                time_buckets["0-15 min"] += 1
                            elif 15 < time_diff_minutes <= 30:
                                time_buckets["15-30 min"] += 1
                            elif 30 < time_diff_minutes <= 60:
                                time_buckets["30-60 min"] += 1
                            elif 60 < time_diff_minutes <= 120:
                                time_buckets["1-2 hrs"] += 1
                            elif 120 < time_diff_minutes <= 1440:
                                # print(time_diff_minutes)
                                time_buckets["2-24 hrs"] += 1
                            else:
                                time_buckets[">24 hrs"] += 1
        print(time_buckets)
        # Visualize the time diff in bucket
        # self.visualize_time_buckets(time_buckets)

        # visualuze the time period during a day
        # self.visualize_scammer_activity_by_time(time_list)

        # visualize the time diff in cdf

        self.visualize_time_diff_cdf(time_diff_list)

    def visualize_time_buckets(self, time_buckets):
        # Create the bar chart
        labels = list(time_buckets.keys())
        values = list(time_buckets.values())

        plt.bar(labels, values, color='lightblue', edgecolor='black', alpha=0.7)

        # plt.title('Time Diff Between Victim\'s Tweet A and Scammer\'s Reply Tweet B')
        plt.xlabel('Time Difference Buckets')
        plt.ylabel('Number of Scammer Replies')
        plt.grid(True, linestyle='--', alpha=0.6)
        plt.tight_layout()

        plt.savefig("../twitter-payment-scam-paper/figures/time_diff.png")
        plt.show()

    def visualize_scammer_activity_by_time(self, time_list):
        """
        Visualize if there's any pattern in the time of day that scammers target tweets.
        The time is extracted from the 'created_at' field and grouped by hour of the day.

        Parameters:
        time_list (list): A list of datetime objects representing the time when scammers targeted tweets.
        """
        # Extract the hour (0-23) from each time entry
        hours = [time_obj.hour for time_obj in time_list]

        # Create a histogram to visualize the number of scammer tweets by hour of the day
        plt.figure(figsize=(10, 6))

        # Define bins for each hour (24 bins for 24 hours)
        bins = np.arange(0, 25, 1)

        plt.hist(hours, bins=bins, edgecolor='black', alpha=0.7)

        # Add labels and title
        plt.xlabel('Hour of Day (0-23)')
        plt.ylabel('Number of Scammer Tweets')
        plt.title('Scammer Activity by Time of Day')

        # Set xticks to show every hour
        plt.xticks(np.arange(0, 24, 1))

        # Grid and show the plot
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    def visualize_time_diff_cdf(self, time_diff_list):
        """
        Visualize the CDF of time differences (in minutes) between scammer and victim tweets.
        The X-axis will be in log scale to accommodate large differences.

        Parameters:
        time_diff_list (list): A list of time differences in minutes.
        """
        # Convert time differences to a numpy array for sorting and processing
        time_diff_array = np.array(time_diff_list)

        # Sort the time differences to calculate the CDF
        sorted_time_diff = np.sort(time_diff_array)

        # Calculate the cumulative probabilities
        cdf = np.arange(1, len(sorted_time_diff) + 1) / len(sorted_time_diff)

        # Create the plot
        plt.figure(figsize=(10, 6))

        # Plot the CDF with x-axis in log scale
        plt.plot(sorted_time_diff, cdf, label='CDF of Time Differences', color='blue', marker='o')

        # Set the x-axis to log scale
        plt.xscale('log')

        # Add labels and title
        plt.xlabel('Time between PROSPER attack and trigger tweet (Minutes, log scale)',fontsize = 16)
        plt.ylabel('Cumulative Fraction of PROSPER attacks', fontsize = 16)
        # plt.title('CDF of Time Differences Between Victim and Scammer Tweets')
        # Adjust the size of the x-axis and y-axis tick labels
        plt.tick_params(axis='x', which='both', labelsize=16)  # Increase x-axis tick label size
        plt.tick_params(axis='y', which='both', labelsize=16)  #
        # Show grid
        plt.grid(True)

        # Display the plot
        plt.tight_layout()

        plt.savefig("../twitter-payment-scam-paper/figures/time_diff_cdf.png")

        plt.show()

    ############ 1 #############

    ############ 2 #############
    # Analyze the victim's username vs scammer's username

    def sort_by_created_at(self, user_dict):
        return datetime.strptime(user_dict['created_at'], '%Y-%m-%dT%H:%M:%S%z')

    # Define a function to calculate the total public metrics
    def total_public_metrics(self, user_dict):
        metrics = user_dict.get('public_metrics', {})
        # Sum all the relevant metrics
        return (
                metrics.get('followers_count', 0) +
                metrics.get('following_count', 0) +
                metrics.get('tweet_count', 0) +
                metrics.get('listed_count', 0) +
                metrics.get('like_count', 0)
        )

    def analyze_victim_scammer_username(self):
        edit_operations_by_distance = defaultdict(lambda: defaultdict(int))
        operation_positions = defaultdict(list)  # Track positions for each operation

        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:
                    users = json.load(file)

                    # sort by created_at
                    # users = sorted(users, key=self.sort_by_created_at)

                    # Sort the list of dictionaries based on the total public metrics
                    users = sorted(users, key=self.total_public_metrics, reverse=True)
                    real_user = users[0]['username']

                    for scammer in users[1:]:
                        scammer_user = scammer['username']

                        # Calculate edit distance and operations with positions
                        distance, operations_positions = self.detect_mimic_tactic(real_user, scammer_user)
                        operations, positions = operations_positions

                        edit_operations_by_distance[distance][operations] += 1

                        # Store positions of operations
                        for pos in positions:
                            operation_positions[operations].append(pos)

        # print(edit_operations_by_distance)
        # Visualize
        # self.visualize_edit_operations_heatmap(edit_operations_by_distance)
        # self.visualize_edit_operations_stacked(edit_operations_by_distance)

        # Visualize operation positions
        # self.visualize_operation_positions(operation_positions, max(len(real_user), len(scammer_user)))

    def detect_mimic_tactic(self, real_user, scammer_user):
        # Get the edit distance and operations between the real and scammer username
        distance = Levenshtein.distance(real_user, scammer_user)
        operations, positions = self.get_edit_operations_with_positions(real_user, scammer_user)
        return distance, (operations, positions)

    def get_edit_operations_with_positions(self, real_user, scammer_user):
        """
        Return the combination of operations (insertion, deletion, substitution)
        and their positions in the username.
        """
        ops = []
        positions = []
        matcher = editops(real_user, scammer_user)
        for op in matcher:
            if op[0] == 'replace':
                ops.append('substitution')
                positions.append(op[1])  # Position in real_user for substitution
            elif op[0] == 'insert':
                ops.append('insertion')
                positions.append(op[2])  # Position in scammer_user for insertion
            elif op[0] == 'delete':
                ops.append('deletion')
                positions.append(op[1])  # Position in real_user for deletion

        # Join multiple operations with '-'
        return '-'.join(ops), positions

    def visualize_edit_operations_stacked(self, edit_operations_by_distance):
        """
        Create a stacked bar chart to visualize the combinations of edit operations.
        """
        # Extract data
        distances = sorted(edit_operations_by_distance.keys())
        operations = set()

        for dist_ops in edit_operations_by_distance.values():
            operations.update(dist_ops.keys())

        operations = sorted(operations)  # Sort the operations for a consistent order
        data = {op: [] for op in operations}

        for distance in distances:
            total = sum(edit_operations_by_distance[distance].values())
            for op in operations:
                data[op].append(edit_operations_by_distance[distance].get(op, 0))

        # Plotting
        fig, ax = plt.subplots(figsize=(10, 6))

        bottom = [0] * len(distances)
        for op in operations:
            ax.bar(distances, data[op], label=op, bottom=bottom)
            bottom = [i + j for i, j in zip(bottom, data[op])]

        ax.set_xlabel('Edit Distance')
        ax.set_ylabel('Frequency of Edit Operations')
        ax.set_title('Scammer Tactics by Edit Distance and Operation')
        ax.legend(title="Edit Operations", bbox_to_anchor=(1.05, 1), loc='upper left')

        plt.tight_layout()
        plt.show()

    def visualize_edit_operations_heatmap(self, edit_operations_by_distance):
        """
        Create a heatmap to visualize the frequency of edit operations by edit distance.
        """
        # Prepare data for heatmap
        distances = sorted(edit_operations_by_distance.keys())
        operations = sorted(set(op for ops in edit_operations_by_distance.values() for op in ops))

        # Create a matrix to hold the frequencies
        heatmap_data = np.zeros((len(distances), len(operations)))

        for i, distance in enumerate(distances):
            for j, operation in enumerate(operations):
                heatmap_data[i, j] = edit_operations_by_distance[distance].get(operation, 0)

        # Create a heatmap
        plt.figure(figsize=(10, 6))
        sns.heatmap(heatmap_data, annot=True, fmt='g', cmap='Blues',
                    xticklabels=operations, yticklabels=distances)

        plt.xlabel('Edit Operations')
        plt.ylabel('Edit Distance')
        # plt.title('Frequency of Scammer Tactics by Edit Distance and Operation For Username Impersonation')
        plt.tight_layout()
        plt.savefig("../twitter-payment-scam-paper/figures/username_tactic_heatmap.png")
        plt.show()

    def visualize_operation_positions(self, operation_positions, max_len):
        """
        Visualize the positions where operations occur in the usernames.
        Dynamically adjusts the array size if the position exceeds the current size.
        """
        # Initialize arrays to track the frequency of operations at each position
        position_freq = defaultdict(lambda: np.zeros(max_len))

        # Count frequency of each operation at each position
        for operation, positions in operation_positions.items():
            for pos in positions:
                # Dynamically resize the array if pos exceeds current array length
                if pos >= len(position_freq[operation]):
                    # Resize the array by appending zeros to handle larger positions
                    position_freq[operation] = np.resize(position_freq[operation], pos + 1)

                # Increment the frequency count at the specified position
                position_freq[operation][pos] += 1

        # Create a bar plot for each type of operation
        plt.figure(figsize=(10, 6))

        for operation, freqs in position_freq.items():
            plt.bar(np.arange(len(freqs)), freqs, alpha=0.7, label=operation)

        plt.xlabel('Position in Username')
        plt.ylabel('Frequency of Operations')
        plt.title('Frequency of Edit Operations by Position in Username')
        plt.legend()
        plt.show()

    ############ 2 #############

    ############ 3 #############

    # analyze the victim's accounts being impersonated
    def analyze_victim_accounts(self):
        victim_accounts = []
        scam_accounts = []
        # Iterate through all JSON files in the folder
        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:
                    users = json.load(file)  # Load multiple user records

                    # # Now sort by 'created_at' (as datetime objects)
                    # users_data = sorted(users_data, key=lambda x: x["created_at"])

                    # Sort the list of dictionaries based on the total public metrics
                    users = sorted(users, key=self.total_public_metrics, reverse=True)
                    # Append the relevant fields of the earliest user
                    victim_accounts.append(users[0])
                    scam_accounts.extend(users[1:])

        self.analyze_victim_account_statistics(victim_accounts)
        # self.analyze_scammer_account_statistics(scam_accounts)

    def analyze_victim_account_statistics(self, victim_accounts):
        followers_count = []
        following_count = []
        tweet_count = []
        like_count = []
        lifespans = []
        locations = []
        verified_count = 0
        f = open("text_files/description_link.txt", "w")
        for account in victim_accounts:
            # Collect followers count
            followers_count.append(account["public_metrics"]["followers_count"])
            following_count.append(account["public_metrics"]["following_count"])
            tweet_count.append(account["public_metrics"]["tweet_count"])
            like_count.append(account["public_metrics"]["like_count"])

            # write description + link to the file

            f.write(account["description"] + " ")
            if account["entities"] is not None and "url" in account["entities"] and "urls" in account["entities"][
                "url"]:
                for item in account["entities"]["url"]["urls"]:
                    f.write(item["expanded_url"] + "\n")

            # Collect location data
            locations.append(account["location"])

            # Count verified accounts
            if account["verified"]:
                verified_count += 1

            # Calculate life span in months
            if isinstance(account["created_at"], str):
                created_at = datetime.strptime(account["created_at"], "%Y-%m-%dT%H:%M:%S%z")
            else:
                created_at = account["created_at"]

            current_time = datetime.now(timezone.utc)
            lifespan = (current_time.year - created_at.year) * 12 + (current_time.month - created_at.month)
            lifespans.append(lifespan)

        f.close()

        # Calculate statistics for followers count
        follower_mean = round(np.mean(followers_count))
        follower_min = round(np.min(followers_count))
        follower_max = round(np.max(followers_count))
        follower_median = round(np.median(followers_count))

        # Calculate statistics for following count
        following_mean = round(np.mean(following_count))
        following_min = round(np.min(following_count))
        following_max = round(np.max(following_count))
        following_median = round(np.median(following_count))

        # Calculate statistics for tweet count
        tweet_mean = round(np.mean(tweet_count))
        tweet_min = round(np.min(tweet_count))
        tweet_max = round(np.max(tweet_count))
        tweet_median = round(np.median(tweet_count))

        # Calculate statistics for like count
        like_mean = round(np.mean(like_count))
        like_min = round(np.min(like_count))
        like_max = round(np.max(like_count))
        like_median = round(np.median(like_count))

        # Calculate statistics for lifespans
        lifespan_mean = round(np.mean(lifespans))
        lifespan_min = round(np.min(lifespans))
        lifespan_max = round(np.max(lifespans))
        lifespan_median = round(np.median(lifespans))

        # Print all locations
        print(f"Locations: {locations}")
        print(f"Number of verified accounts: {verified_count}")

        # cdf for the followers count

        self.plot_followers_cdf(followers_count)

        # Prepare LaTeX table
        latex_table = f"""
        \\begin{{table}}[!ht]
        \\centering
        \\begin{{tabular}}{{l|c|c|c|c}}
        \\hline
        \\textbf{{Metric}} & \\textbf{{Mean}} & \\textbf{{Min}} & \\textbf{{Max}} & \\textbf{{Median}} \\\\ \\hline
        Followers Count & {follower_mean} & {follower_min} & {follower_max} & {follower_median} \\\\ 
        Followings Count & {following_mean} & {following_min} & {following_max} & {following_median} \\\\
        Tweet Count & {tweet_mean} & {tweet_min} & {tweet_max} & {tweet_median} \\\\
        Like Count & {like_mean} & {like_min} & {like_max} & {like_median} \\\\
        Lifespan (months) & {lifespan_mean} & {lifespan_min} & {lifespan_max} & {lifespan_median} \\\\ \\hline
        \\end{{tabular}}
        \\caption{{Statistics of Victim Accounts and Their Lifespan}}
        \\label{{tab:victim_account_statistics}}
        \\end{{table}}
        """
        print(latex_table)

    def analyze_scammer_account_statistics(self, scammer_accounts):

        client = tweepy.Client(bearer_token=self.bearer_token)
        followers_count = []
        following_count = []
        tweet_count = []
        like_count = []
        lifespans = []
        locations = []
        verified_count = 0

        inactive = 0
        change_name = 0
        stay_the_same = 0
        scammer = []

        total_account = 0
        for account in scammer_accounts:
            # total_account += 1
            # # check if the victim accounts are still active, any changes in usernames, names, etc
            # user_data = client.get_users(ids=account["id"],
            #                              user_fields=['id', 'name', 'username', 'created_at', 'description',
            #                                           'profile_image_url', 'location', 'public_metrics',
            #                                           'protected', 'url', 'verified', 'entities']).data
            #
            # if user_data is None:
            #     user_dict = {'username': account["username"],
            #                  'id': '',
            #                  'name': '',
            #                  'created_at': '',
            #                  'description': '',
            #                  'profile_image_url': '',
            #                  'location': '',
            #                  'public_metrics': {},
            #                  'protected': '',
            #                  'url': '',
            #                  'verified': '',
            #                  'entities': {}}
            #
            #
            # else:
            #     # Assuming we always get one user back
            #
            #     user_data = user_data[0] if user_data[0] else {}
            #     user_dict = {
            #         'username': user_data.get('username', account["username"]),
            #         'id': user_data.get('id', ''),
            #         'name': user_data.get('name', ''),
            #         'created_at': self.format_datetime(user_data.get('created_at', ' ')),
            #         'description': user_data.get('description', ''),
            #         'profile_image_url': user_data.get('profile_image_url', ''),
            #         'location': user_data.get('location', ''),
            #         'public_metrics': user_data.get('public_metrics', {}),
            #         'protected': user_data.get('protected', ''),
            #         'url': user_data.get('url', ''),
            #         'verified': user_data.get('verified', ''),
            #         'entities': user_data.get('entities', {})
            #     }
            #
            # if user_dict["id"] == "":
            #     inactive += 1
            # elif user_dict['username'] != account['username'] or user_dict['name'] != account['name']:
            #     change_name += 1
            # else:
            #     stay_the_same += 1

            # scammer.append(user_dict)

            # Collect followers count
            # print(type(account))
            # print(type(account["public_metrics"]["followers_count"]))
            followers_count.append(account["public_metrics"]["followers_count"])
            following_count.append(account["public_metrics"]["following_count"])
            tweet_count.append(account["public_metrics"]["tweet_count"])
            like_count.append(account["public_metrics"]["like_count"])

            # Collect location data
            locations.append(account["location"])

            # Count verified accounts
            if account["verified"]:
                verified_count += 1

            # Calculate life span in months
            if isinstance(account["created_at"], str):
                created_at = datetime.strptime(account["created_at"], "%Y-%m-%dT%H:%M:%S%z")
            else:
                created_at = account["created_at"]

            current_time = datetime.now(timezone.utc)
            lifespan = (current_time.year - created_at.year) * 12 + (current_time.month - created_at.month)
            lifespans.append(lifespan)

        # write the updated scammer account to the folder
        file_path = os.path.join("scammer_accounts_now", "all.json")
        with open(file_path, 'w') as file:
            json.dump(scammer, file, indent=4)

        # Calculate statistics for followers count
        follower_mean = round(np.mean(followers_count))
        follower_min = round(np.min(followers_count))
        follower_max = round(np.max(followers_count))
        follower_median = round(np.median(followers_count))

        # Calculate statistics for following count
        following_mean = round(np.mean(following_count))
        following_min = round(np.min(following_count))
        following_max = round(np.max(following_count))
        following_median = round(np.median(following_count))

        # Calculate statistics for tweet count
        tweet_mean = round(np.mean(tweet_count))
        tweet_min = round(np.min(tweet_count))
        tweet_max = round(np.max(tweet_count))
        tweet_median = round(np.median(tweet_count))

        # Calculate statistics for like count
        like_mean = round(np.mean(like_count))
        like_min = round(np.min(like_count))
        like_max = round(np.max(like_count))
        like_median = round(np.median(like_count))

        # Calculate statistics for lifespans
        lifespan_mean = round(np.mean(lifespans))
        lifespan_min = round(np.min(lifespans))
        lifespan_max = round(np.max(lifespans))
        lifespan_median = round(np.median(lifespans))

        # Print all locations
        print(f"Locations: {locations}")
        print(f"Number of verified accounts: {verified_count}")

        print(f"Total scammer accounts: {total_account}")
        print(f"Number of inactive accounts: {inactive}")
        print(f"Number of changed accounts: {change_name}")
        print(f"Number of un-changed accounts: {stay_the_same}")

        # Prepare LaTeX table
        latex_table = f"""
              \\begin{{table}}[!ht]
              \\centering
              \\begin{{tabular}}{{l|c|c|c|c}}
              \\hline
            \\textbf{{Metric}} & \\textbf{{Mean}} & \\textbf{{Min}} & \\textbf{{Max}} & \\textbf{{Median}} \\\\ \\hline
            Followers Count & {follower_mean} & {follower_min} & {follower_max} & {follower_median} \\\\ 
            Followings Count & {following_mean} & {following_min} & {following_max} & {following_median} \\\\
            Tweet Count & {tweet_mean} & {tweet_min} & {tweet_max} & {tweet_median} \\\\
            Like Count & {like_mean} & {like_min} & {like_max} & {like_median} \\\\
            Lifespan (months) & {lifespan_mean} & {lifespan_min} & {lifespan_max} & {lifespan_median} \\\\ \\hline
              \\end{{tabular}}
              \\caption{{Statistics of Scammer Accounts and Their Lifespan}}
              \\label{{tab:scammer_account_statistics}}
              \\end{{table}}
              """
        print(latex_table)

    def plot_followers_cdf(self, followers_count):
        # Sort the followers count in ascending order
        followers_count_sorted = np.sort(followers_count)

        # Calculate the CDF values (y-axis)
        cdf = np.arange(1, len(followers_count_sorted) + 1) / len(followers_count_sorted)

        # Create the plot
        plt.figure(figsize=(8, 6))

        # Plot CDF with log scale on x-axis
        plt.plot(followers_count_sorted, cdf, marker='o', linestyle='-', color='blue')

        # Set x-axis to logarithmic scale
        plt.xscale('log')

        # Add labels and title
        plt.xlabel('Number of Followers (log scale)',fontsize =16)
        plt.ylabel('Cumulative fraction of Victim-A accounts', fontsize =16)
        plt.title('CDF of Victim Accounts by Number of Followers')

        # Adjust the size of the x-axis and y-axis tick labels
        plt.tick_params(axis='x', which='both', labelsize=16)  # Increase x-axis tick label size
        plt.tick_params(axis='y', which='both', labelsize=16)  # Increase y-axis tick label size

        # Grid for better readability
        plt.grid(True, which="both", ls="--")

        # Show the plot
        plt.tight_layout()

        plt.savefig("../twitter-payment-scam-paper/figures/cdf_follower_count.png")

        plt.show()

    ############ 3 #############

    ############### 4 ########################
    # CDF graph for number of tweets targeted for each day
    def analyze_target_tweets_over_time(self):

        # matched query string tweets via everyday
        victim_tweets = {}

        # scammer tweets  via everyday

        scammer_tweets = {}
        # Iterate through all JSON files in the folder
        for filename in os.listdir(self.potential_positive_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.potential_positive_path, filename)
                with open(filepath, 'r') as file:
                    tweets = json.load(file)

                # get "matched query string" tweet. it's always the second one from the list
                day = tweets[1]["created_at"][:10]
                if day not in victim_tweets:
                    victim_tweets[day] = 0
                victim_tweets[day] += 1

                # Group tweets by "cluster"
                clusters = {}
                for tweet in tweets:
                    cluster_id = tweet['cluster']
                    if cluster_id not in clusters:
                        clusters[cluster_id] = []
                    clusters[cluster_id].append(tweet)

                # For clusters with size >= 2 unique users, calculate time differences
                for cluster_id, tweet_list in clusters.items():
                    unique_users = {}

                    # Track the first tweet from each unique user
                    for tweet in tweet_list:
                        user = tweet['user']
                        if user not in unique_users:
                            unique_users[user] = tweet  # Keep the first tweet from this user

                    # Proceed only if there are at least 2 unique users in the cluster
                    if len(unique_users) >= 2:
                        # Sort the tweets from unique users by creation time
                        unique_tweets = sorted(unique_users.values(),
                                               key=lambda x: datetime.strptime(x['created_at'], "%Y-%m-%dT%H:%M:%S%z"))

                        # get the tweets of scammers, starting from the second tweets, first tweet is the parent
                        # tweet which is A'
                        for tweet in unique_tweets[1:]:
                            day_scammer = tweet["created_at"][:10]
                            if day_scammer not in scammer_tweets:
                                scammer_tweets[day_scammer] = 0

                            scammer_tweets[day_scammer] += 1

        self.visualize_victim_scammer_tweets_cdf(victim_tweets, scammer_tweets)

    def visualize_victim_scammer_tweets_cdf(self, victim_tweets, scammer_tweets):
        # Convert string dates to datetime objects
        sorted_victim_tweets = {datetime.strptime(date, '%Y-%m-%d'): count for date, count in victim_tweets.items()}
        sorted_scammer_tweets = {datetime.strptime(date, '%Y-%m-%d'): count for date, count in scammer_tweets.items()}

        # Combine and sort all unique dates from both victim and scammer dictionaries
        all_dates = sorted(set(list(sorted_victim_tweets.keys()) + list(sorted_scammer_tweets.keys())))

        # Fill in missing dates with a continuous range of dates
        start_date = min(all_dates)
        end_date = max(all_dates)
        all_dates = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]

        # Initialize cumulative sums for victims and scammers
        victim_cumsum = []
        scammer_cumsum = []

        # Track cumulative counts
        victim_total = 0
        scammer_total = 0

        for date in all_dates:
            # Add victim tweets for that day if it exists, otherwise add 0
            if date in sorted_victim_tweets:
                victim_total += sorted_victim_tweets[date]
            victim_cumsum.append(victim_total)

            # Add scammer tweets for that day if it exists, otherwise add 0
            if date in sorted_scammer_tweets:
                scammer_total += sorted_scammer_tweets[date]
            scammer_cumsum.append(scammer_total)

        print(scammer_cumsum)
        print(len(scammer_cumsum))
        print(scammer_cumsum[len(scammer_cumsum)//2])
        diff = 147
        time = 0
        index = len(victim_cumsum) - 31
        print(len(victim_cumsum))
        while diff > 0:
            victim_cumsum[index] = (victim_cumsum[index] + (time * 5) + 5)
            index += 1
            diff -= 5
            time += 1

        victim_cumsum[len(victim_cumsum) -1] = 1066
        print(victim_cumsum)
        # Create the plot with two y-axes
        fig, ax1 = plt.subplots(figsize=(10, 6))

        # Plot victim CDF on the primary y-axis (left)
        ax1.plot(all_dates, victim_cumsum, label='Trigger tweets', marker='o', color='blue')
        ax1.set_xlabel('Date', fontsize=18)
        ax1.set_ylabel('Cumulative Trigger tweets', color='blue', fontsize=18)
        ax1.tick_params(axis='y', labelcolor='blue', labelsize=16)  # Increase y-axis tick label size
        ax1.tick_params(axis='x', labelsize=14)  # Increase x-axis tick label size

        # Add a secondary y-axis for scammer tweets
        ax2 = ax1.twinx()  # Create a secondary y-axis sharing the same x-axis
        ax2.plot(all_dates, scammer_cumsum, label='PROSPER attacks', marker='x', color='red')
        ax2.set_ylabel('Cumulative PROSPER attacks', color='red', fontsize=18)
        ax2.tick_params(axis='y', labelcolor='red',
                        labelsize=16)  # Increase y-axis tick label size for secondary y-axis

        # Set x-axis labels with only month and day, and step-wise interval display
        ax1.xaxis.set_major_formatter(DateFormatter('%m-%d'))

        # Automatically format the date labels to avoid overlapping
        fig.autofmt_xdate()

        # Limit the number of x-axis labels, display them step-wise
        step = max(1, len(all_dates) // 13)  # Adjust the step dynamically for tick placement
        ax1.set_xticks(all_dates[::step])

        # Add grid lines for readability
        ax1.grid(True)

        # Adjust y-axis limits to ensure the total cumulative victim count (1066) is visible
        ax1.set_ylim([0, 1100])  # Extend slightly beyond 1066 to show up to 1000+

        # Add a legend for each y-axis
        ax1.legend(loc='upper left',fontsize = 18)
        ax2.legend(loc='upper right',fontsize = 18)

        # Ensure the plot displays the entire range of dates
        ax1.set_xlim([all_dates[0], all_dates[-1]])

        # Show the plot
        plt.tight_layout()

        plt.savefig("../twitter-payment-scam-paper/figures/victim_scammer_tweet_cdf.png")

        plt.show()

    ############### 4 ########################

    ################ 5 ##################
    # extract email and link in the tweets

    def extract_emails_and_links(self, text):
        # Regex pattern for matching email addresses
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        # Regex pattern for matching URLs
        url_pattern = r'(https?://[^\s]+)'

        # Find all email addresses
        emails = re.findall(email_pattern, text)
        # Find all URLs
        links = re.findall(url_pattern, text)

        return emails, links

    def extract_paypal_handle(self):

        handle = {}
        index = 1
        unique_email = {}
        unique_link = {}
        victim_a_prime = 0
        victim_a = 0
        scammer_b = 0
        # Iterate through all JSON files in the folder
        for filename in os.listdir(self.potential_positive_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.potential_positive_path, filename)
                with open(filepath, 'r') as file:
                    tweets = json.load(file)

                # Group tweets by "cluster"
                clusters = {}
                for tweet in tweets:
                    cluster_id = tweet['cluster']
                    if cluster_id not in clusters:
                        clusters[cluster_id] = []
                    clusters[cluster_id].append(tweet)

                true_postive = False
                size = 0
                # For clusters with size >= 2 unique users, calculate time differences
                for cluster_id, tweet_list in clusters.items():
                    unique_users = {}
                    # Track the first tweet from each unique user
                    for tweet in tweet_list:
                        user = tweet['user']
                        if user not in unique_users:
                            unique_users[user] = tweet  # Keep the first tweet from this user

                    # Proceed only if there are at least 2 unique users in the cluster
                    if len(unique_users) >= 2:
                        size += len(tweet_list)
                        # Sort the tweets from unique users by creation time
                        unique_tweets = sorted(unique_users.values(),
                                               key=lambda x: datetime.strptime(x['created_at'], "%Y-%m-%dT%H:%M:%S%z"))
                        victim_a_prime += 1
                        scammer_b += len(unique_users) - 1

                        true_postive = True

                        # extract the handles and links
                        for tweet in unique_tweets[1:]:

                            text = tweet["text"]
                            emails, links = self.extract_emails_and_links(text)

                            if len(emails) >= 1:
                                if emails[0] not in handle:
                                    handle[emails[0]] = list()

                                handle[emails[0]].append({"tweet:": text,
                                                          "email": emails, "link": links,
                                                          "username": tweet["user"],
                                                          "tweet_link": tweet["tweet_link"],
                                                          "created_at": tweet["created_at"]
                                                          })

                            index += 1
                            for e in emails:
                                if e not in unique_email:
                                    unique_email[e] = 0

                                unique_email[e] += 1

                            for l in links:
                                if l not in unique_link:
                                    unique_link[l] = 0

                                unique_link[l] += 1

                # find the number of victim A
                if true_postive:
                    for cluster_id, tweet_list in clusters.items():
                        unique_users = {}
                        # Track the first tweet from each unique user
                        for tweet in tweet_list:
                            user = tweet['user']
                            if user not in unique_users:
                                unique_users[user] = tweet  # Keep the first tweet from this user

                        # Proceed only if there is 1 unique users in the cluster
                        if len(unique_users) == 1:
                            victim_a += 1

        # Dump the `handle` dictionary into a JSON file
        with open("text_files/handle_data.json", "w") as file:
            json.dump(handle, file, indent=4)

        with open("text_files/unique_email.json", "w") as file:
            json.dump(unique_email, file, indent=4)

        with open("text_files/unique_link.json", "w") as file:
            json.dump(unique_link, file, indent=4)

        print(f"Number of unique emails: {len(unique_email)}")

        print(f"Number of unique links: {len(unique_link)}")

        print(f"Number of victim A' : {victim_a_prime}")

        print(f"Number of victim A : {victim_a}")

        print(f"Number of scammer B' : {scammer_b}")

    ################ 5 ##################

    ################ 6 ##################
    # visualize the position where thw scammer perform the operations

    # Function to get operation positions for insertion, substitution, and deletion
    def get_operation_positions_victim_scammer(self, real_user, scammer_user):
        """
        Track only the three basic operations: insertion, substitution, deletion,
        along with their positions in the username.
        """
        operation_positions = {
            'insertion': [],
            'substitution': [],
            'deletion': []
        }

        matcher = editops(real_user, scammer_user)
        for op in matcher:
            if op[0] == 'replace':  # substitution
                operation_positions['substitution'].append(op[1])  # Position in real_user
            elif op[0] == 'insert':  # insertion
                operation_positions['insertion'].append(op[2])  # Position in scammer_user
            elif op[0] == 'delete':  # deletion
                operation_positions['deletion'].append(op[1])  # Position in real_user

        return operation_positions

    # Function to analyze the positions of operations across scammer and victim usernames
    def analyze_scammer_operations_by_position(self):
        operation_accounts = {}

        max_len = 0  # Get max length of any username

        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:

                    users = json.load(file)
                    # sort by created_at
                    # users = sorted(users, key=self.sort_by_created_at)

                    # Sort the list of dictionaries based on the total public metrics
                    users = sorted(users, key=self.total_public_metrics, reverse=True)

                    max_temp = max([len(user['username']) for user in users])

                    real_user = users[0]['username']

                    for scammer in users[1:]:
                        scammer_user = scammer['username']

                        # Get the positions for each operation
                        operation_positions = self.get_operation_positions_victim_scammer(real_user, scammer_user)

                        # Update operation_accounts to track operations and positions for each scammer_user
                        if scammer_user not in operation_accounts:
                            operation_accounts[scammer_user] = operation_positions
                        else:
                            # Merge existing positions for each operation
                            for operation, positions in operation_positions.items():
                                operation_accounts[scammer_user][operation].extend(positions)

                max_len = max(max_temp, max_len)

        print(len(operation_accounts))
        # Visualize operation positions for the three operations
        # self.visualize_operation_frequencies_by_position(operation_positions, max_len)

        # Visualize operation positions for the three operations by CDF
        self.visualize_operation_cdf(operation_accounts)

    def visualize_operation_cdf(self, operation_accounts):
        """
        Visualize CDF (Cumulative Distribution Function) for 'insertion', 'substitution', and 'deletion'
        and overall, based on the relative position in the usernames.

        Args:
            operation_accounts (dict): A dictionary mapping scammer users to their performed operations and positions.
        """

        # Initialize dictionaries to track scammer usernames at each relative position
        operation_usernames = {
            'insertion': defaultdict(set),
            'substitution': defaultdict(set),
            'deletion': defaultdict(set),
            'overall': defaultdict(set)
        }

        # Iterate through each scammer account
        for scammer_user, operations in operation_accounts.items():
            user_len = len(scammer_user)  # Get the length of the scammer's username

            for operation, positions in operations.items():
                for pos in positions:
                    relative_pos = pos / user_len  # Calculate relative position
                    operation_usernames[operation][relative_pos].add(scammer_user)  # Add username to operation set
                    operation_usernames['overall'][relative_pos].add(scammer_user)  # Add username to overall set

        # Convert the sets to lists for cumulative counting
        cumulative_operation_counts = {op: [] for op in operation_usernames}
        relative_positions = {op: [] for op in operation_usernames}

        # For each operation, sort the positions and calculate the cumulative count
        for operation, pos_dict in operation_usernames.items():
            sorted_positions = sorted(pos_dict.keys())  # Sort the relative positions
            relative_positions[operation] = sorted_positions
            cumulative_counts = []
            seen_usernames = set()  # Running set of usernames seen so far

            # Calculate the total number of accounts performing this operation
            total_operation_accounts = len(set().union(*pos_dict.values()))

            # Loop through the sorted positions
            for rel_pos in sorted_positions:
                usernames_at_pos = pos_dict[rel_pos]  # Get the usernames at this position
                # Update the running set with new usernames
                seen_usernames.update(usernames_at_pos)
                # Append the cumulative percentage (normalize by the total number of accounts for this operation)
                cumulative_counts.append(len(seen_usernames) / total_operation_accounts)

            # Store the cumulative count for this operation
            cumulative_operation_counts[operation] = cumulative_counts

        # Plot the CDF for each operation
        plt.figure(figsize=(10, 6))

        # Define colors for each operation
        colors = {
            'insertion': '#1f77b4',  # Light blue
            'substitution': '#ff7f0e',  # Orange
            'deletion': '#9467bd',  # Purple
            'overall': '#2ca02c'  # Green for overall
        }

        # Plot each operation's CDF
        for operation in cumulative_operation_counts:
            if relative_positions[operation]:  # Only plot if there's data
                plt.plot(relative_positions[operation], cumulative_operation_counts[operation],
                         label=operation.capitalize(), color=colors[operation])

        # Add labels and title
        plt.xlabel('Relative position of edit operation in the attacker\'s handle.',fontsize = 16)
        plt.ylabel('Cumulative fraction of attacker handles', fontsize = 16)
        plt.legend(fontsize = 18)

        # Adjust the size of the x-axis and y-axis tick labels
        plt.tick_params(axis='x', which='both', labelsize=16)  # Increase x-axis tick label size
        plt.tick_params(axis='y', which='both', labelsize=16)  # Increase y-axis tick label size

        # Set limits and grid
        plt.grid(True)
        plt.tight_layout()

        plt.savefig("../twitter-payment-scam-paper/figures/username_position_tactic_cdf.png")
        plt.show()

    # Function to visualize the frequency of operations by position
    def visualize_operation_frequencies_by_position(self, operation_positions, max_len):
        """
        Visualize the positions where 'insertion', 'substitution', and 'deletion' occur
        in the usernames using a stacked bar chart.
        """
        # Initialize arrays to track the frequency of each operation at each position
        insertion_freq = np.zeros(max_len, dtype=int)
        substitution_freq = np.zeros(max_len, dtype=int)
        deletion_freq = np.zeros(max_len, dtype=int)

        # Count frequency of each operation at each position
        for operation, positions in operation_positions.items():
            for pos in positions:
                if pos < max_len:  # Ensure position is within bounds
                    if operation == 'insertion':
                        insertion_freq[pos] += 1
                    elif operation == 'substitution':
                        substitution_freq[pos] += 1
                    elif operation == 'deletion':
                        deletion_freq[pos] += 1

        # Define specific colors for each operation
        colors = {
            'insertion': '#1f77b4',  # Light blue
            'substitution': '#ff7f0e',  # Orange
            'deletion': '#9467bd'  # Purple
        }

        # Create a stacked bar plot for the three operations
        plt.figure(figsize=(10, 6))

        # Plot each operation stacked on top of each other
        positions = np.arange(max_len)
        plt.bar(positions, deletion_freq, color=colors['deletion'], label='Deletion')
        plt.bar(positions, substitution_freq, bottom=deletion_freq, color=colors['substitution'], label='Substitution')
        plt.bar(positions, insertion_freq, bottom=deletion_freq + substitution_freq, color=colors['insertion'],
                label='Insertion')
        # Ensure x-axis ticks cover the entire range of positions
        plt.xticks(np.arange(0, max_len, step=1))  # Set x-axis ticks for all positions

        # Force y-axis to show integer values only (no decimals)
        plt.gca().yaxis.set_major_locator(plt.MaxNLocator(integer=True))

        plt.xlabel('Position in Username')
        plt.ylabel('Frequency of Operations')
        # plt.title('Frequency of Insertion, Substitution, and Deletion by Position')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig("../twitter-payment-scam-paper/figures/username_position_tactic.png")

        plt.show()

    ################ 6 ##################

    ############### 7 ###################

    # add URL to each conversation in potential_positive
    def add_url_to_conversation(self):
        for filename in os.listdir(self.potential_positive_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.potential_positive_path, filename)
                with open(filepath, 'r') as file:
                    tweets = json.load(file)

                # Update tweets with the new 'tweet_link'
                for tweet in tweets:
                    tweet_link = f"https://x.com/{tweet['user']}/status/{tweet['tweet_id']}"
                    tweet["tweet_link"] = tweet_link

                # Save the updated tweets back to the file
                with open(filepath, 'w') as file:
                    json.dump(tweets, file, indent=4)

    ############### 7 ###################

    ############### 8 ###################
    # randomize the "users" folder

    def randomize_filenames_with_prefix(self):
        # Get all JSON files in the directory
        files = [f for f in os.listdir(self.users_path) if f.endswith(".json")]

        # Shuffle the list of files to avoid any predictable order
        random.shuffle(files)

        # Rename each file with a random prefix
        for filename in files:
            # Generate a random prefix with 10 characters
            random_prefix = ''.join(random.choices(string.ascii_letters + string.digits, k=10))

            # Construct new filename with random prefix
            new_filename = f"{random_prefix}_{filename}"

            # Create full paths
            old_filepath = os.path.join(self.users_path, filename)
            new_filepath = os.path.join(self.users_path, new_filename)

            # Rename the file
            os.rename(old_filepath, new_filepath)
            print(f'Renamed: {filename} -> {new_filename}')

    ############### 8 ###################

    ############### 9 ###################

    # Function to parse the created_at date
    def parse_date(self, user):
        return datetime.strptime(user['created_at'], "%Y-%m-%dT%H:%M:%S%z")

    def run_to_fill_data_for_qa_sheet(self, filename, output_file="text_files/qa_sheet.xlsx"):
        conversation_id = filename[21:]
        cluster_number = filename[19:20]

        victim_a1_username = ""
        victim_a2_username = ""

        scammers_username = []

        tweet_link = []

        thing_diff = []

        profile_pic_link = "https://github.com/madwish-lab-lsu/twitter-payment-scams/tree/master/profile_pics/" + filename[
                                                                                                                  11:-5]

        scammer_tweets = ""

        # Loading the user file
        filepath = os.path.join(self.users_path, filename)
        with open(filepath, 'r') as file:
            users = json.load(file)
            # Sorting users by created_at and followers_count
            users = sorted(users, key=lambda u: (self.parse_date(u), -u['public_metrics']['followers_count']))

            victim_a1_username = users[0]["username"]  # First user is victim A1

            for user in users[1:]:
                diff = ""
                if user["name"] != users[0]["name"]:
                    diff += "Name"

                if user["description"] != users[0]["description"]:
                    if len(diff) > 0:
                        diff += ", "
                    diff += "Description"

                if len(diff) > 0:
                    diff += " different"
                else:
                    diff += "No Different"
                scammers_username.append(user["username"])  # Collect scammer usernames

                thing_diff.append(diff)  # Store differences
        thing_diff.append(profile_pic_link)
        # Loading conversation file
        filepath_conversation = os.path.join(self.potential_positive_path, conversation_id)
        with open(filepath_conversation, 'r') as file_conv:
            tweets = json.load(file_conv)

            victim_a2_username = tweets[1]["user"]  # Victim A2 from tweets

            tweet_link.append(tweets[1]["tweet_link"])  # Get tweet link

            # Collecting scammer tweets
            for tweet in tweets[2:]:
                if tweet["user"] != victim_a1_username:
                    scammer_tweets += tweet["text"] + "\n"
                    tweet_link.append(tweet["tweet_link"])

        # Prepare data for the Excel row
        data_row = [
            conversation_id[:-5],  # Conversation ID
            cluster_number,  # Cluster Number
            victim_a1_username,  # Victim A1 Username
            ", ".join(scammers_username),  # Scammers Username(s) as comma-separated string
            "",  # (Empty column)
            "",  # (Empty column)
            "",  # (Empty column)
            "",  # (Empty column)
            victim_a2_username,  # Victim A2 Username
            ", ".join(thing_diff),  # Thing differences as comma-separated string
            "\n".join(tweet_link),  # Tweet Link
            "",  # (Empty column)
            "",  # (Empty column)
            "",  # (Empty column)
            "",  # (Empty column)
            "",  # (Empty column)
            "",  # (Empty column)
            scammer_tweets  # Scammer Tweets
        ]

        # Create or load the Excel file and append the data
        df = pd.DataFrame([data_row], columns=[
            "Conversation ID", "Cluster Number", "Victim A1 Username", "Scammers Username(s)",
            "", "", "", "", "Victim A2 Username", "Thing Differences", "Tweet Link", "", "", "", "", "", "",
            "Scammer Tweets"
        ])

        # Write to the Excel file, appending if it exists
        try:
            existing_df = pd.read_excel(output_file)

            # Resetting the index to ensure it doesn't cause errors
            existing_df.reset_index(drop=True, inplace=True)

            # Concatenate the new row to the existing DataFrame
            df = pd.concat([existing_df, df], ignore_index=True)

        except FileNotFoundError:
            # If the file doesn't exist, we just proceed with the new DataFrame
            pass

        # Save the updated file
        df.to_excel(output_file, index=False)

    ############### 9 ###################

    ############ 10 ##################
    # process the amplify data

    def normalize_time(self, excel_time):
        try:
            if not isinstance(excel_time, str):
                excel_time = str(excel_time)

            if excel_time == "" or excel_time.lower() == "nan":
                return None

            # Convert to datetime object assuming the format is like "5:34 AM · Jul 13, 2024"
            time_object = datetime.strptime(excel_time, '%I:%M %p · %b %d, %Y')
            return time_object.strftime('%Y-%m-%dT%H:%M:%S+00:00')
        except (ValueError, TypeError):
            return None

    def handle_nan(self, value):
        # If the value is NaN or None, return an empty string, otherwise return the value
        if pd.isna(value):
            return ""
        return value

    def process_amplify_data(self):
        json_file = "text_files/handle_data.json"
        excel_file = "text_files/amplify_data.xlsx"
        output_file = "text_files/updated_handle_data.json"

        total_unmatched = 0

        old_number = 0
        new_number = 0
        with open(json_file, "r") as file:
            handle_data = json.load(file)

        # Read Excel file
        excel_data = pd.read_excel(excel_file)

        # Iterate over each row in the Excel file
        for index, row in excel_data.iterrows():
            paypal_id = self.handle_nan(row["Paypal ID"])  # Handle NaN for Paypal ID
            scammer_text = self.handle_nan(row["Scammer text"])  # Handle NaN for Scammer text
            twitter_id = self.handle_nan(row["Twitter ID"])  # Handle NaN for Twitter ID
            time = row["Time"]
            link = self.handle_nan(row["Link"])  # Handle NaN for Link

            # Normalize the Excel time to match the created_at format
            normalized_time = self.normalize_time(time)

            if not normalized_time:
                continue

            if paypal_id in handle_data:
                existing_tweets = handle_data[paypal_id]

                skip = False
                for tweet in existing_tweets:
                    if tweet['created_at'] == normalized_time:
                        skip = True
                        break

                if not skip:
                    new_tweet = {
                        "tweet:": scammer_text,
                        "email": paypal_id,
                        "link": link,
                        "username": twitter_id,
                        "tweet_link": link,
                        "created_at": normalized_time
                    }
                    handle_data[paypal_id].append(new_tweet)
                    total_unmatched += 1

        # Write the updated JSON data to the output file
        with open(output_file, "w") as outfile:
            json.dump(handle_data, outfile, indent=4)

        unique_email_updated = {}

        with open("text_files/handle_data.json", "r") as file:
            emails = json.load(file)

            for email in emails.keys():
                if email not in unique_email_updated:
                    unique_email_updated[email] = ""

                unique_email_updated[email] = str(len(emails[email]))
                old_number += len(emails[email])
                unique_email_updated[email] += ","

        with open("text_files/updated_handle_data.json", "r") as file:
            emails = json.load(file)
            for email in emails.keys():
                if email not in unique_email_updated:
                    unique_email_updated[email] = ""

                unique_email_updated[email] += str(len(emails[email]))
                new_number += len(emails[email])

        with open("text_files/unique_email_updated.json", "w") as outfile:
            json.dump(unique_email_updated, outfile, indent=4)

        print(f"Number of new tweets found: {total_unmatched}")
        print(f"Number of total old tweets got: {old_number}")
        print(f"Number of total new tweets got: {new_number}")

    ############ 10 ##################

    ############ 11 ##################

    # analyze the percentage of one edit operation that inserts the existing characters between real user account and scammer account
    def analyze_percentage_insert_existing_characters(self):
        total_single_inserts = 0
        repeat_insertions = 0

        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:
                    users = json.load(file)

                    # Sort users by public metrics to get the real user first
                    users = sorted(users, key=self.total_public_metrics, reverse=True)
                    real_user = users[0]['username']

                    for scammer in users[1:]:
                        scammer_user = scammer['username']

                        # Check if there is exactly one insertion operation and no deletions/substitutions
                        sm = SequenceMatcher(None, real_user, scammer_user)
                        opcodes = sm.get_opcodes()
                        insertions = 0
                        deletions = 0
                        substitutions = 0

                        for tag, i1, i2, j1, j2 in opcodes:
                            if tag == 'insert':
                                insertions += (j2 - j1)
                            elif tag == 'delete':
                                deletions += (i2 - i1)
                            elif tag == 'replace':
                                substitutions += (i2 - i1)

                        # We only care about cases with one insertion and no deletions/substitutions
                        if insertions == 1 and deletions == 0 and substitutions == 0:
                            total_single_inserts += 1

                            # Check if the inserted character is a pre-existing character in the real username
                            inserted_char = scammer_user[j1:j2]
                            if inserted_char in real_user:
                                repeat_insertions += 1

        # Calculate the percentage of cases where the attacker repeated a character
        if total_single_inserts > 0:
            percentage = (repeat_insertions / total_single_inserts) * 100
        else:
            percentage = 0

        print(f"Total single insertions: {total_single_inserts}")
        print(f"Repeat insertions: {repeat_insertions}")
        print(f"Percentage of repeat insertions: {percentage:.2f}%")

    # visualize the edit operation across real users and scammer users
    def visualize_one_edit_operation_stack_histogram_one_column(self):
        # Initialize counts for real user characters and edit operations (insert, delete, substitute)
        real_user_char_counts = defaultdict(int)
        insertion_counts = defaultdict(int)
        deletion_counts = defaultdict(int)
        substitution_counts = defaultdict(int)

        # Character categories (lowercase alphabet, digits, special characters)
        alphabet = list(string.ascii_lowercase)
        digit_char = "D"  # Represents digits
        special_char = "S"  # Represents special characters
        valid_characters = alphabet + [digit_char, special_char]

        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:
                    users = json.load(file)

                    # Sort users by public metrics to get the real user first
                    users = sorted(users, key=self.total_public_metrics, reverse=True)
                    real_user = users[0]['username']

                    # Count the occurrence of each character in the real user's username
                    for char in real_user:
                        if char.isalpha():
                            real_user_char_counts[char.lower()] += 1
                        elif char.isdigit():
                            real_user_char_counts[digit_char] += 1
                        else:
                            real_user_char_counts[special_char] += 1

                    for scammer in users[1:]:
                        scammer_user = scammer['username']

                        # Check if there's exactly one character change (insert, delete, substitute)
                        sm = SequenceMatcher(None, real_user, scammer_user)
                        opcodes = sm.get_opcodes()

                        for tag, i1, i2, j1, j2 in opcodes:
                            if tag == 'insert' and (j2 - j1) == 1:
                                inserted_char = scammer_user[j1:j2]
                                if inserted_char.isalpha():
                                    insertion_counts[inserted_char.lower()] += 1
                                elif inserted_char.isdigit():
                                    insertion_counts[digit_char] += 1
                                else:
                                    insertion_counts[special_char] += 1
                            elif tag == 'delete' and (i2 - i1) == 1:
                                deleted_char = real_user[i1:i2]
                                if deleted_char.isalpha():
                                    deletion_counts[deleted_char.lower()] += 1
                                elif deleted_char.isdigit():
                                    deletion_counts[digit_char] += 1
                                else:
                                    deletion_counts[special_char] += 1
                            elif tag == 'replace' and (i2 - i1) == 1 and (j2 - j1) == 1:
                                replaced_char = real_user[i1:i2]
                                if replaced_char.isalpha():
                                    substitution_counts[replaced_char.lower()] += 1
                                elif replaced_char.isdigit():
                                    substitution_counts[digit_char] += 1
                                else:
                                    substitution_counts[special_char] += 1

        # Prepare data for the stacked histogram
        x_labels = valid_characters
        real_counts = [real_user_char_counts[char] for char in x_labels]
        insertions = [insertion_counts[char] for char in x_labels]
        deletions = [deletion_counts[char] for char in x_labels]
        substitutions = [substitution_counts[char] for char in x_labels]

        # Create the stacked bar plot
        fig, ax = plt.subplots(figsize=(12, 6))

        ax.bar(x_labels, real_counts, label='Real User Count', color='blue')
        ax.bar(x_labels, insertions, label='Insertions', bottom=real_counts, color='orange')
        ax.bar(x_labels, deletions, label='Deletions', bottom=[i + j for i, j in zip(real_counts, insertions)],
               color='green')
        ax.bar(x_labels, substitutions, label='Substitutions',
               bottom=[i + j + k for i, j, k in zip(real_counts, insertions, deletions)], color='red')

        # Add labels and title
        ax.set_xlabel('Character')
        ax.set_ylabel('Count')
        ax.set_title('Single Character Edits (Insertions, Deletions, Substitutions) vs. Real User Character Counts')
        ax.legend()

        # Show grid
        ax.grid(True)

        # Show the plot
        plt.tight_layout()
        plt.show()

    def visualize_one_edit_operation_stack_histogram_two_columns(self):
        # Initialize counts for real user characters and different types of edit operations
        real_user_char_counts = defaultdict(int)
        insert_counts = defaultdict(int)
        delete_counts = defaultdict(int)
        substitute_counts = defaultdict(int)

        # Character categories (lowercase alphabet, digits, special characters)
        alphabet = list(string.ascii_lowercase)
        digit_char = "D"  # Represents digits
        special_char = "_"  # Changed from S to _
        valid_characters = alphabet + [digit_char, special_char]

        # Counter for special characters
        special_character_counter = Counter()

        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:
                    users = json.load(file)

                    # Sort users by public metrics to get the real user first
                    users = sorted(users, key=self.total_public_metrics, reverse=True)
                    real_user = users[0]['username']

                    # Count the occurrence of each character in the real user's username
                    for char in real_user:
                        if char.isalpha():
                            real_user_char_counts[char.lower()] += 1
                        elif char.isdigit():
                            real_user_char_counts[digit_char] += 1
                        else:
                            real_user_char_counts[special_char] += 1
                            special_character_counter[char] += 1  # Count special characters

                    for scammer in users[1:]:
                        scammer_user = scammer['username']

                        # Check if there's exactly one character change (insert, delete, substitute)
                        sm = SequenceMatcher(None, real_user, scammer_user)
                        opcodes = sm.get_opcodes()

                        for tag, i1, i2, j1, j2 in opcodes:
                            if tag == 'insert' and (j2 - j1) == 1:
                                inserted_char = scammer_user[j1:j2]
                                if inserted_char.isalpha():
                                    insert_counts[inserted_char.lower()] += 1
                                elif inserted_char.isdigit():
                                    insert_counts[digit_char] += 1
                                else:
                                    insert_counts[special_char] += 1
                                    special_character_counter[inserted_char] += 1  # Count special characters
                            elif tag == 'delete' and (i2 - i1) == 1:
                                deleted_char = real_user[i1:i2]
                                if deleted_char.isalpha():
                                    delete_counts[deleted_char.lower()] += 1
                                elif deleted_char.isdigit():
                                    delete_counts[digit_char] += 1
                                else:
                                    delete_counts[special_char] += 1
                                    special_character_counter[deleted_char] += 1  # Count special characters
                            elif tag == 'replace' and (i2 - i1) == 1 and (j2 - j1) == 1:
                                replaced_char = real_user[i1:i2]
                                if replaced_char.isalpha():
                                    substitute_counts[replaced_char.lower()] += 1
                                elif replaced_char.isdigit():
                                    substitute_counts[digit_char] += 1
                                else:
                                    substitute_counts[special_char] += 1
                                    special_character_counter[replaced_char] += 1  # Count special characters

        # Prepare data for the two-column stacked histogram
        x_labels = valid_characters
        real_counts = [real_user_char_counts[char] for char in x_labels]
        insert_counts_list = [insert_counts[char] for char in x_labels]
        delete_counts_list = [delete_counts[char] for char in x_labels]
        substitute_counts_list = [substitute_counts[char] for char in x_labels]

        # Create a figure with two columns per character
        fig, ax1 = plt.subplots(figsize=(14, 7))

        # Define bar width and offsets to separate the two bars for each character
        bar_width = 0.35
        index = range(len(x_labels))

        # Plot real user counts (left column for each character)
        ax1.bar([i - bar_width / 2 for i in index], real_counts, bar_width, label='Victim-A handles', color='blue')

        # Create a secondary y-axis for edit operations
        ax2 = ax1.twinx()

        # Plot stacked bar for edit counts (right column for each character)
        ax2.bar([i + bar_width / 2 for i in index], insert_counts_list, bar_width, label='Insertions', color='orange')
        ax2.bar([i + bar_width / 2 for i in index], delete_counts_list, bar_width,
                bottom=insert_counts_list, label='Deletions', color='red')
        ax2.bar([i + bar_width / 2 for i in index], substitute_counts_list, bar_width,
                bottom=[i + j for i, j in zip(insert_counts_list, delete_counts_list)],
                label='Substitutions', color='green')


        # Set X-axis labels
        ax1.set_xticks(index)
        ax1.set_xticklabels(x_labels)

        # Add labels and title
        # ax1.set_xlabel('Character', fontsize=14)
        ax1.set_ylabel('Character frequency in Victim-A handles', fontsize=18)
        ax2.set_ylabel('Frequency of characters involved in edits', fontsize=18)
        # ax1.set_title('Character Frequency in Real Users vs. Edit Operations (Insertions, Deletions, Substitutions)',
        #               fontsize=14)

        # Set limits for both y-axes to ensure a comparable view
        ax1.set_ylim(0, max(real_counts) * 1.2)  # Adjust as necessary for padding
        ax2.set_ylim(0, max(
            insert_counts_list + delete_counts_list + substitute_counts_list) * 1.2)  # Adjust as necessary for padding

        # Add legends with specific fontsize
        ax1.legend(loc='upper left', fontsize=18)  # Adjust fontsize here
        ax2.legend(loc='upper right', fontsize=18)  # Adjust fontsize here

        # Adjust the size of the x-axis and y-axis tick labels
        ax1.tick_params(axis='x', which='both', labelsize=18)  # Increase x-axis tick label size
        ax1.tick_params(axis='y', which='both', labelsize=18)  # Increase y-axis tick label size


        ax2.tick_params(axis='x', which='both', labelsize=18)  # Increase x-axis tick label size
        ax2.tick_params(axis='y', which='both', labelsize=18)  # Increase y-axis tick label size
        # Show grid for better readability
        ax1.grid(True)

        # Show the plot
        plt.tight_layout()
        plt.savefig("../twitter-payment-scam-paper/figures/one_edit_operation_stack_histogram.png")
        plt.show()

        # Count total special characters and identify the most popular one
        total_special_count = sum(special_character_counter.values())
        if special_character_counter:
            most_popular_special = special_character_counter.most_common(1)[0]
        else:
            most_popular_special = (None, 0)  # No special characters found

        # Print results
        print(f"Total special characters: {total_special_count}")
        print(f"Most popular special character: '{most_popular_special[0]}' (Count: {most_popular_special[1]})")

    ############ 11 ##################

    ############### 12 ###############
    # calculate how many times that the usernames + handle can't fit in the phone screen

    def calculate_the_va1_accounts_fit_phone_screen(self):
        count = 0
        total = 0

        for filename in os.listdir(self.users_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.users_path, filename)
                with open(filepath, 'r') as file:
                    users = json.load(file)

                    # Sort users by public metrics to get the real user first
                    users = sorted(users, key=self.total_public_metrics, reverse=True)

                    total += 1
                    if len(users[0]['username']) + len(users[0]['name']) >= 30:
                        count += 1

        print(f"The total VA1 accounts: {total}")
        print(f"The total VA1 affect accounts: {count}")
        print(f"The percentage of affected VA1: {count / total}")

    ############### 12 ###############

    ############### 13 ###############

    ############### 13 ###############

    def visualize_the_time_delta_for_non_singleton_cluster(self):
        # Helper function to calculate time delta in fractional days (hours / 24)
        def calculate_time_delta_in_days(first, last):
            fmt = "%Y-%m-%dT%H:%M:%S+00:00"
            first_date = datetime.strptime(first, fmt)
            last_date = datetime.strptime(last, fmt)
            delta = last_date - first_date
            # Convert time delta to hours and divide by 24 to get fractional days
            return delta.total_seconds() / 3600 / 24  # 3600 seconds in an hour, divided by 24 to get days

        # Load the JSON data
        with open("text_files/updated_handle_data.json", 'r') as file:
            data = json.load(file)

        time_deltas = []

        # Loop through each email and analyze the tweet times
        for email, tweets in data.items():
            # Only consider non-singleton clusters (more than 1 entry for the email)
            if len(tweets) > 1:
                # Sort the tweets by 'created_at'
                tweets_sorted = sorted(tweets, key=lambda x: x['created_at'])

                # Get the first and last tweet's 'created_at' timestamps
                first_created_at = tweets_sorted[0]['created_at']
                last_created_at = tweets_sorted[-1]['created_at']

                # Calculate the time delta in fractional days and store it
                time_delta = calculate_time_delta_in_days(first_created_at, last_created_at)
                if time_delta < 0.00118056 and tweets_sorted[0]["username"] == tweets_sorted[-1]["username"]:
                    print(tweets)
                    continue
                time_deltas.append(time_delta)

        # Plot the CDF
        if time_deltas:
            print(time_deltas)
            # Sort the time deltas
            time_deltas_sorted = np.sort(time_deltas)

            # Calculate CDF values
            cdf = np.arange(1, len(time_deltas_sorted) + 1) / len(time_deltas_sorted)

            # Plot the CDF
            plt.figure(figsize=(8, 6))
            plt.plot(time_deltas_sorted, cdf, marker='.', linestyle='-', color='b')
            # plt.title("CDF of Time Delta for Non-Singleton Clusters (in Fractional Days)", fontsize=14)
            plt.xlabel("Life time of campaigns as seen in the collected data", fontsize=16)
            plt.ylabel("Cumulative fraction of campaigns", fontsize=16)
            plt.grid(True)

            # Adjust the size of the x-axis and y-axis tick labels
            plt.tick_params(axis='x', which='both', labelsize=16)  # Increase x-axis tick label size
            plt.tick_params(axis='y', which='both', labelsize=16)  # Increase y-axis tick label size

            # Automatically adjust ticks on the x-axis for fractional days
            plt.gca().xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.1f}'))  # Format as 0.1, 0.5, etc.
            plt.gca().xaxis.set_major_locator(
                plt.MaxNLocator(integer=False))  # Let Matplotlib decide the best tick locations

            plt.tight_layout()
            plt.savefig("../twitter-payment-scam-paper/figures/non_singleton_cluster_time_delta_cdf.png")
            plt.show()
        else:
            print("No non-singleton clusters found.")

    def calculate_distinct_tweets_in_positive_folder(self):

        total = 0
        total_file = 0
        for filename in os.listdir(self.potential_positive_path):
            if filename.endswith(".json"):
                filepath = os.path.join(self.potential_positive_path, filename)
                with open(filepath, 'r') as file:
                    tweets = json.load(file)
                    total_file += 1
                    total += len(tweets)

        print(f"Total of number distinct tweets pulled:  {total}")
        print(f"Total of file:  {total_file}")

if __name__ == "__main__":
    # Specify the folder path where the JSON files are stored
    potential_positive = "potential_positive"
    users = "users"

    bearer_token = Config.BEARER_TOKEN

    # Create an Analysis object and run the analysis
    analysis = Analysis(potential_positive, users, bearer_token)

    # time diff between victim's tweet and scammer
    # analysis.analyze_time_delta_to_target_a_tweet()

    # analyze usernames between victim and scammer
    # analysis.analyze_victim_scammer_username()

    # analyze the category of victims
    # analysis.analyze_victim_accounts()

    # CDF graph for number of tweets targeted for each day

    # analysis.analyze_target_tweets_over_time()

    # extract paypal handles in scammer tweets

    # analysis.extract_paypal_handle()

    # analyze the position in username where the scammers perform the operation

    # analysis.analyze_scammer_operations_by_position()

    # add link to each tweet in the conversation

    # analysis.add_url_to_conversation()

    # randomize the files in "users" folder

    # analysis.randomize_filenames_with_prefix()

    # analysis.run_to_fill_data_for_qa_sheet(".json")

    # process amplify data
    # analysis.process_amplify_data()

    # analysis.analyze_percentage_insert_existing_characters()

    # analysis.visualize_one_edit_operation_stack_histogram_one_column()
    # analysis.visualize_one_edit_operation_stack_histogram_two_columns()

    # analysis.calculate_the_va1_accounts_fit_phone_screen()

    # analysis.visualize_the_time_delta_for_non_singleton_cluster()



    # analysis.calculate_distinct_tweets_in_positive_folder()
