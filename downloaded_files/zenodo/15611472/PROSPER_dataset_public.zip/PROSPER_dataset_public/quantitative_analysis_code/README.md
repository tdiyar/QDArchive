## Quantitative Analysis Scripts

This folder contains the scripts that use raw data collected by X-AM to produce all the graphs for our quantitative analysis (Section 3). Aggregated data and input files for these graphs are available in [aggregated_dataset/input_data_for_graphs.txt](/aggregated_dataset/input_data_for_graphs.txt).


1. `analyze_target_tweets_over_time()` → Figure 3: Cumulative growth of trigger tweets and PROSPER attacks over time.

2. `analyze_time_delta_to_target_a_tweet()` → Figure 4: Response time distribution of PROSPER attacks

3. `analyze_scammer_operations_by_position()` → Figure 5: CDF of PROSPER attackers’ handles as per the relative position of their edit distance operations.

4. `visualize_one_edit_operation_stack_histogram_two_columns()` → Figure 6: Character frequency in edit operations of attackers (right axis) vs. baseline character frequency from V-A account handles (left axis). D represents all digits.

5. `visualize_the_time_delta_for_non_singleton_cluster()` → Figure 7: CDF for Lifetime (days) of PROSPER campaigns

6. `analyze_victim_account_statistics()` → Figure 8: Figure 9: CDF for follower counts of impersonation targets (V-As)
