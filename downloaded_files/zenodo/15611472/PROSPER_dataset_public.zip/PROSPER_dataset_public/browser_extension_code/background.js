console.log('Response Logger: Background script started.');

const SEARCH_TIMELINE = "SearchTimeline"
const TWEET_DETAIL = "TweetDetail"
const VARIABLES = "variables"
const SERVER_URI = "http://localhost:3000"

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.disable();

  chrome.declarativeContent.onPageChanged.removeRules(undefined, () => {
    let exampleRule = {
      conditions: [
        new chrome.declarativeContent.PageStateMatcher({
          pageUrl: { hostSuffix: '.x.com' },
        })
      ],
      actions: [new chrome.declarativeContent.ShowAction()],
    };

    let rules = [exampleRule];
    chrome.declarativeContent.onPageChanged.addRules(rules);
  });
});

function isDebuggerAttached(array, tabId) {
  for (let i = 0; i < array.length; i++) {
    const item = array[i];
    if (item.tabId === tabId && item.attached === true) {
      return true;
    }
  }
  return false;
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  chrome.debugger.getTargets(
    (result) => {
      if (!isDebuggerAttached(result, tabId)) {
        if (changeInfo.url && changeInfo.url.startsWith('https://x.com')) {
          try {
            chrome.debugger.attach({ tabId: tabId }, '1.2', () => {
              chrome.debugger.sendCommand(
                { tabId: tab.id },
                'Network.enable',
                {},
                () => {
                  if (chrome.runtime.lastError) {
                    console.error(chrome.runtime.lastError);
                  }
                }
              );
            });
          } catch (error) {
            console.log("Debugger already attached!");
          }
        }
      }
    }
  )
});

// chrome.action.onClicked.addListener((tab) => {
//   if (tab.url.startsWith('https://x.com')) {
//     chrome.scripting.executeScript({
//       target: { tabId: tab.id },
//       files: ['content.js']
//     });
//   } else {
//     console.log('Debugger can only be attached to HTTP/HTTPS pages.');
//   }
// });

chrome.debugger.onEvent.addListener((source, method, params) => {
  if (method === 'Network.responseReceived') {
    var responseUrl = params.response.url
    if (responseUrl.startsWith("https://x.com/i/api/graphql") &&
      (responseUrl.includes(SEARCH_TIMELINE) || responseUrl.includes(TWEET_DETAIL))) {
      chrome.debugger.sendCommand(
        { tabId: source.tabId },
        'Network.getResponseBody',
        { requestId: params.requestId },
        (response) => {
          const url = new URL(responseUrl);
          const searchParams = url.searchParams;
          const query = JSON.parse(searchParams.get(VARIABLES));

          if (responseUrl.includes(SEARCH_TIMELINE) && query.rawQuery.includes("until") && query.rawQuery.includes("since")) {
            const body = JSON.parse(response.body);
          } else if (responseUrl.includes(TWEET_DETAIL)) {
            const requestBody = JSON.stringify(response);

            const options = {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: requestBody
            };

            fetch(`${SERVER_URI}/api/tweets/${query.focalTweetId}`, options)
              .then(response => response.text())
              .then(data => {
                console.log('Successfully written to mongodb.')
              })
              .catch(error => {
                console.log('Couldn\'t write to mongodb.')
              });
          }
        }
      )
    }
  }
});
