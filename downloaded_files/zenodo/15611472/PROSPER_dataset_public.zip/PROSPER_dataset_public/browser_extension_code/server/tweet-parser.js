function getEntries(tweets) {
    const data = JSON.parse(tweets);
    var type = data.data.threaded_conversation_with_injections_v2.instructions[0].type;

    if (type === 'TimelineAddToModule') {
        return data.data.threaded_conversation_with_injections_v2.instructions[0].moduleItems;
    } else {
        return data.data.threaded_conversation_with_injections_v2.instructions[0].entries;
    }
}

function addReplyToAndRestIdInRoot(entries) {
    const regex1 = /^tweet-\d{19}$/;
    const regex2 = /^conversationthread-\d{19}$/;
    const regex3 = /^conversationthread-\d{19}-tweet-\d{19}$/;

    entries.forEach(entry => {
        const entryId = entry.entryId;

        if (regex1.test(entryId)) {
            // Case 1: tweet-19-digit-number
            entry.reply_to_id = entry.content?.itemContent?.tweet_results?.result?.legacy?.in_reply_to_status_id_str ?? null;
            entry.rest_id = entry.content?.itemContent?.tweet_results?.result?.rest_id ?? null;
        } else if (regex2.test(entryId)) {
            // Case 2: conversationthread-19-digit-number
            entry.reply_to_id = entry.content?.items?.[0]?.item?.itemContent?.tweet_results?.result?.legacy?.in_reply_to_status_id_str ?? null;
            entry.rest_id = entry.content?.items?.[0]?.item?.itemContent?.tweet_results?.result?.rest_id ?? null;
        } else if (regex3.test(entryId)) {
            // Case 3: conversationthread-19-digit-number-tweet-19-digit-number
            entry.reply_to_id = entry.content?.itemContent?.tweet_results?.result?.legacy?.in_reply_to_status_id_str ?? null;
            entry.rest_id = entry.content?.itemContent?.tweet_results?.result?.rest_id;
        } else {
            // Optional: Handle invalid formats if necessary
            entry.reply_to_id = null;
        }
    });

    return entries;
}

function getAncestorsAndImmediateChildren(entries, focalTweetId) {
    addReplyToAndRestIdInRoot(entries);

    const immediateChildren = new Set();
    const ancestors = new Set();

    const entryMapById = new Map(entries.map(entry => [entry.rest_id, entry]));

    const focalTweet = entryMapById.get(focalTweetId);

    immediateChildren.add(...entries.filter(entry => entry.reply_to_id === focalTweetId));

    function findAncestors(tweetId) {
        var tweet =  entryMapById.get(tweetId);
        if (!tweet) return;

        const parentId = tweet.reply_to_id;
        if (parentId === null) return; // Base case: No more ancestors

        const parentTweet = entryMapById.get(parentId);
        if (parentTweet) {
            ancestors.add(parentTweet);
            findAncestors(parentId); // Recursively find ancestors of the parent
        }
    }

    findAncestors(focalTweetId);

    return [...ancestors,
        focalTweet,
        ...immediateChildren
    ];
}

module.exports = { getEntries, getAncestorsAndImmediateChildren };
