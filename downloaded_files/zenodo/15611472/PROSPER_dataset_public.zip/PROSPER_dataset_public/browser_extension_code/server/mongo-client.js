const { MongoClient, ObjectId } = require('mongodb');
const moment = require('moment');

async function writeToMongoDB(entries, uri, dbName, collectionName) {
  try {
    const client = new MongoClient(uri);
    await client.connect();

    const db = client.db(dbName);

    const collection = db.collection(collectionName);

    const document = {
      tweets: entries
    };

    const result = await collection.insertOne(document);
    console.log(`Document inserted with _id: ${result.insertedId}`);

    await client.close();
  } catch (error) {
    console.error('Error writing to MongoDB:', error);
  }
}

async function readLastMinedDate(uri, dbName, collectionName) {
  const client = new MongoClient(uri);
  await client.connect();

  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  const record = await collection.findOne({});

  await client.close();

  return record;
}

async function updateLastMinedDate(uri, dbName, collectionName) {
  const client = new MongoClient(uri);
  await client.connect();

  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  const record = await collection.findOne({});

  const existingDate = moment(record.date);
  const updatedDate = existingDate.add(1, 'week').toDate();

  console.log(record);
  console.log(updatedDate);

  const result = await collection.updateOne(
    { _id: new ObjectId(record._id) },
    { $set: { date: updatedDate } }
  );

  await client.close();

  return result;
}

module.exports = { writeToMongoDB, readLastMinedDate, updateLastMinedDate};
