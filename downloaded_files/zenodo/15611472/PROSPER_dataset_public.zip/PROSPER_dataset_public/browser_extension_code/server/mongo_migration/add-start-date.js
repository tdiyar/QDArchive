// MongoDB Playground
// Use Ctrl+Space inside a snippet or a string literal to trigger completions.

const centralTimeOffset = -6;

const centralTimeDate = new Date(Date.UTC(2022, 4, 1, 0 - centralTimeOffset, 0, 0));

use('twitter');

db.getCollection('meta').insertOne({
    date: centralTimeDate
});
