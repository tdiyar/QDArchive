const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const moment = require('moment');
const { getEntries, getAncestorsAndImmediateChildren } = require('./tweet-parser.js');
const { writeToMongoDB, readLastMinedDate, updateLastMinedDate} = require('./mongo-client.js');
const dotenv = require('dotenv')

dotenv.config();

const app = express();
const port = 3000;

const mongodbUri = process.env.MONGODB_URI;
const dbName = process.env.DB_NAME;
const collectionName = process.env.COLLECTION_NAME;

app.use(bodyParser.json());
app.use(cors());

app.post('/api/tweets/:focalTweetId', (req, res) => {
    const focalTweetId = req.params.focalTweetId;
    console.log(focalTweetId);

    const tweets = getEntries(req.body.body);

    console.log(tweets);

    const childAndAncestorTweets = getAncestorsAndImmediateChildren(tweets, focalTweetId);

    console.log(childAndAncestorTweets);
    writeToMongoDB(tweets, mongodbUri, dbName, collectionName);

    res.status(200).send('Data received and logged.');
});

app.get('/generate-query', async (req, res) => {
    try {
        const record = await readLastMinedDate(mongodbUri, dbName, "meta");

        const since = moment(record.date);

        const until = since.clone().add(6, 'days').format('YYYY-MM-DD');

        const phrases = `("do you have" OR "can you accept" OR "can I send you" OR "do you take" OR "do you use" OR "is it possible to pay with" OR "do you accept" OR "can you provide" OR "can I donate via" OR "can I pay via" OR "can I send money via" OR "you got a" OR "send me your" OR "share your") and `;

        const response = `${phrases} paypal since:${since.format('YYYY-MM-DD')} until:${until}`;

        res.send(response);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Internal server error.');
    }
});

app.put('/update-date', async (req, res) => {
    try {
        const result = await updateLastMinedDate(mongodbUri, dbName, "meta");

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Operation couldn\'t be performed.' });
        }

        res.json({ message: 'Record updated successfully', result});
    } catch (error) {
        console.error('Error updating record:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
