document.getElementById('gen-query-but').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { generate: true }, (response) => {
            showStatus('success', 'gen');
        });
    });
});

document.getElementById('update-date-but').addEventListener('click', () => {
    updateLastDate();
});

function updateLastDate() {
    var xhr = new XMLHttpRequest();
    var url = 'http://localhost:3000/update-date';

    xhr.open('PUT', url, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = xhr.responseText;
            showStatus('success', 'update'); 
            console.log(response);
        } else if (xhr.readyState === 4) {
            console.error('Failed update date.');
            showStatus('failure', 'update');
        }
    };
    xhr.send();
}

function showStatus(status, buttonType) {
    const checkmark = document.getElementById(buttonType + '-checkmark');
    const failure = document.getElementById(buttonType + '-failure');
    
    if (status === 'success') {
        checkmark.style.display = 'inline';
        failure.style.display = 'none';
    } else if (status === 'failure') {
        checkmark.style.display = 'none';
        failure.style.display = 'inline';
    }

    setTimeout(() => {
        checkmark.style.display = 'none';
        failure.style.display = 'none';
    }, 3000);
}
