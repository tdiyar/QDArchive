function fetchSearchQuery(callback) {
    var xhr = new XMLHttpRequest();
    var url = 'http://localhost:3000/generate-query';

    xhr.open('GET', url, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = xhr.responseText;
            callback(response);
        } else if (xhr.readyState === 4) {
            console.error('Failed to fetch data from API');
        }
    };
    xhr.send();
}

function setSearchQuery(query) {
    var divElements = document.getElementsByTagName('input');

    var attributeName = 'data-testid';
    var attributeValue = 'SearchBox_Search_Input';

    for (let i = 0; i < divElements.length; i++) {

        var element = divElements[i];

        var customAttributeValue = element.getAttribute(attributeName);

        if (customAttributeValue === attributeValue) {
            element.focus();
            element.value = query;
            element.setAttribute('value', query);
            var event = new Event('input', { bubbles: true });
            element.dispatchEvent(event);
            break;
        }
    }
}


console.log("Content script executing.");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Message received.");
    if (message.generate) {

        fetchSearchQuery(function (query) {
            setSearchQuery(query);
        });
        sendResponse({ res: 'Successful' });
    }
});
