# A repo to analyse multiplex arbovirus serological data

## Data

Source data and data-derivatives sufficient to reproduce the analyses and figures of the manuscript are included in this repository.

## Code

All analyses were performed in R (v4.4.3) on macOS (v15.0.1). Bayesian finite mixture models were executed from R on the Stan platform (Stan Development Team. 2024, Stan Modeling Language version 2.35, https://mc-stan.org) using the cmdstanr package (cmdstanr: R Interface to 'CmdStan', version 0.7.1) as the R interface to Stan.

### Setup requirements

Before running any analysis scripts, ensure that Stan’s command-line toolchain (CmdStan) is installed and available through CmdStanR, and that a working C/C++ toolchain is present. Use CmdStanR to verify the toolchain and complete the CmdStan installation; the initial build compiles locally and may take several minutes. Confirm that CmdStanR detects a valid CmdStan version and path prior to execution.

### Execution order and expected runtime

Filenames are prefixed to indicate the intended order of execution. The expected total runtime on a standard desktop computer is approximately 5 minutes.

### Stan code

Stan code for the Bayesian finite mixture models is located in /src

### Related code

Code to run the "cross-reactivity models" is available at https://github.com/nathoze/Mayaro
