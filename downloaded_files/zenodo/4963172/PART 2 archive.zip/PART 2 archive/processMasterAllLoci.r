### file parsing...

### directory of analysis
dir <- "/home/jgb/pele/final/"

### population info file
sampfil <- "AN060814.csv"
sampdirfil <- paste(dir, sampfil ,sep="") 
pop.info   <- read.delim(sampdirfil,sep=",",header=T)

### out files

# nominate a level of analysis
level <- 6

if (level == 1) {samples <- pop.info$struct1}
if (level == 2) {samples <- pop.info$struct2}
if (level == 3) {samples <- pop.info$struct3}
if (level == 4) {samples <- pop.info$struct4}
if (level == 5) {samples <- pop.info$struct5}
if (level == 6) {samples <- pop.info$struct6}

out.ape    <- paste("pel.",level,".allLoci.ape", sep="")
out.struct <- paste("pel.",level,".allLoci.struct", sep="")

thresh.missing <- 0.99

### get sample names for this level of analysis
level.sample.names <- as.matrix(pop.info$sname[ which(samples == 1) ])

### read the genotype file
fil <- "renpelmaster.csv"
dirfil         <- paste(dir, fil,sep="") 
out.dir.ape    <- paste(dir, out.ape, sep="") 
out.dir.struct <- paste(dir, out.struct, sep="") 

### process the in file
gt.fil <- read.csv(dirfil,header=F)
gt.sample.names <- paste("s", as.matrix(gt.fil[2,-1]), as.matrix(gt.fil[4,-1]),sep="_")
gt.locus.names  <- gt.fil[ -c(1,2,3,4),1] 
gt <- t(gt.fil[-c(1,2,3,4),-1])
rownames(gt) <- gt.sample.names

### collect some stats
totloci <- ncol(gt)
totsamp <- nrow(gt) 

### remake the list of sample names
### order and include by level.sample.names 

gt.ord <- gt[match( level.sample.names, rownames(gt) ),]

gt.ape.out <- gt.ord
gt.ape.out[gt.ape.out == "?"] <- "./."
gt.ape.out[gt.ape.out == "0"] <- "1/1"
gt.ape.out[gt.ape.out == "1"] <- "1/2"
gt.ape.out[gt.ape.out == "2"] <- "2/2"



gt.struct.out <- gt.ord
gt.struct.out[gt.struct.out == "-9"] <- "-9 -9"
gt.struct.out[gt.struct.out == "0"] <- "0 0"
gt.struct.out[gt.struct.out == "1"] <- "0 1"
gt.struct.out[gt.struct.out == "2"] <- "1 1"

#write.table(gt.snapp.out, file=out.dir.snapp,sep=",",quote=F, row.names = F, col.names = F)
write.table(gt.ape.out, file=out.dir.ape,sep=",",quote=F, row.names = T, col.names = FALSE)
write.table(gt.struct.out, file=out.dir.struct,sep=" ",quote=F, row.names = T, col.names = FALSE)
