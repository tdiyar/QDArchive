##########################################################
#
#  mat2snapp.pl
#  Spring, 2012
#  Jason Bragg
#  Takes 1. a list of sequence names, 
#        2. a list of taxon names, 
#        3. a directory of sequence alignments
#  writes files formatted for phylogenetic software
#
###########################################################

use warnings;
use strict;
use Bio::SimpleAlign;
use Bio::AlignIO; 
use Bio::LocatableSeq;

# matrix file
my $matfil = "/home/jgb/pele/final/pel.7.snapp";
open MAT, "<$matfil" or die "cannot open matrix file";
my @mat = <MAT>;
close MAT;

my $snappaln = Bio::SimpleAlign->new();
foreach my $t (@mat)
{
     chomp($t);
     my @txn  = split(/,/,$t);
     my $tnnm = $txn[0]; 
     my $loc  = join("", @txn[1..$#txn]);
print $loc;
     my $tloc = new Bio::LocatableSeq(-seq => $loc, -id  => $tnnm, -alphabet => "dna");
     $snappaln->add_seq(-SEQ=>$tloc);

}

   my $snappnex = "/home/jgb/pele/final/snapp/pel.7.nex";
   my $nexout = Bio::AlignIO->new(-file     => ">$snappnex",
                                   -format   => 'nexus',
                                   -idlength => 30);

    $nexout->write_aln($snappaln); 

   my $snappphy = "/home/jgb/pele/final/snapp/pel.7.phy";
   my $phyout = Bio::AlignIO->new(-file     => ">$snappphy",
                                   -format   => 'phylip',
                                   -idlength => 8);

    $phyout->write_aln($snappaln); 


__END__;



