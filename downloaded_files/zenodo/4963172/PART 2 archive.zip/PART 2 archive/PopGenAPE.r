library(adegenet)
library(ape)

### directory of analysis
dir <- "/home/jgb/pele/final/"

### nominate a level of analysis
level <- 1

### open APE file
fil <- paste("pel.",level,".allLoci.ape", sep="")
dirfil <- paste(dir, fil,sep="") 
gtfil   <- read.delim(dirfil,sep=",", header=FALSE, row.names=1)

# call NAs
is.na(gtfil[gtfil == "-9"]) <- TRUE

# hmm
gt.pel  <- gtfil

### remake the list of sample names
sampfil <- "AN060814.csv"
sampdirfil <- paste(dir, sampfil ,sep="") 
pop.info   <- read.delim(sampdirfil,sep=",",header=T)

pop.group.abbr  <- as.matrix(pop.info$abbr)[match(row.names(gt.pel), pop.info$sname)]
pop.group.names <- as.matrix(pop.info$finalnames)[match(row.names(gt.pel), pop.info$sname)]
pop.col.vec     <- as.matrix(pop.info$plotcol)[match(row.names(gt.pel), pop.info$sname)]
pop.shape.vec   <- as.matrix(pop.info$plotshape)[match(row.names(gt.pel), pop.info$sname)]

##################
## Do the DAPCs ##
##################

gt.gi <- df2genind(gt.pel,sep="/",missing=NA)

dapc.pre <- dapc(gt.gi, pop=pop.group.abbr) 
# Level 1: Choose the number PCs to retain (>=1): 9
# Level 1: Choose the number discriminant functions to retain (>=1): 4
# Level 1: tmp <- optim.a.score(dapc.pre)
# Level 1: optimal number of PCs: 8

# Level 2: Choose the number PCs to retain (>=1): 9
# Level 2: Choose the number discriminant functions to retain (>=1): 4
# Level 2: tmp <- optim.a.score(dapc.pre)
# Level 2: optimal number of PCs: 6

# Level 3: Choose the number PCs to retain (>=1): 7
# Level 3: Choose the number discriminant functions to retain (>=1): 3
# Level 3: tmp <- optim.a.score(dapc.pre)
# Level 3: optimal number of PCs: 4


###       Level   1  2  3  
selected.PCs <- c(8, 6, 4)
selected.DFs <- c(4, 4, 3)

dapc.param <- dapc(gt.gi, pop=pop.group.abbr, n.pca=selected.PCs[level], n.da=selected.DFs[level])

dapc.x <- dapc.param$ind.coord[,1]
dapc.y <- dapc.param$ind.coord[,2]

plotfile <- paste("dapc.",level,".png",sep="")
png(filename = plotfile, width = 480, height = 480)
   plot(dapc.x, dapc.y, col=pop.col.vec, pch=pop.shape.vec, cex=2, xlab ="", ylab = "",axes=F ); box()
   
   if (level == 1) {
      ind.legend <- c(1, 10, 28, 41, 64, 75, 88, 96, 100, 130, 142, 149)
      legend("topright", pop.group.names[ind.legend], col=pop.col.vec[ind.legend], pch=pop.shape.vec[ind.legend])
   }
dev.off()

image.name <- paste("dapc.",level,".RData",sep="")
save.image(image.name)


### DAPC diagnostics

### Level 1
# Level 1: summary(dapc.param)$assign.per.pop       # real groups -- really good discrimintation
#     Pamc     Pamll     Pamsl      PaTc      PaTi        Pd        Ph        Pi 
#0.6363636 0.7826087 0.5384615 0.7777778 0.3333333 1.0000000 0.8125000 0.6250000 
#       Pl        Pr   PspStri 
#1.0000000 1.0000000 1.0000000 
# Level 1: dapc.param.rand <- dapc(gt.gi, pop=sample(pop.group.abbr), n.pca=selected.PCs[level], n.da=selected.DFs[level])
# Level 1: summary(dapc.param.rand)$assign.per.pop  # random groups -- really poor discrimination
#     Pamc     Pamll     Pamsl      PaTc      PaTi        Pd        Ph        Pi 
#0.0000000 0.2173913 0.1538462 0.4444444 0.0000000 0.3076923 0.0000000 0.0000000 
#       Pl        Pr   PspStri 
#0.4333333 0.1764706 0.0000000 

### Level 2
# Level 2: summary(dapc.param)$assign.per.pop       # real groups -- really good discrimintation
#     Pamc     Pamll     Pamsl      PaTc      PaTi        Pd        Ph        Pi 
#0.7272727 0.8695652 0.9230769 0.8888889 0.8888889 1.0000000 1.0000000 1.0000000
# Level 2: dapc.param.rand <- dapc(gt.gi, pop=sample(pop.group.abbr), n.pca=selected.PCs[level], n.da=selected.DFs[level])
# Level 2: summary(dapc.param.rand)$assign.per.pop  # random groups -- really poor discrimination
#      Pamc      Pamll      Pamsl       PaTc       PaTi         Pd         Ph 
#0.18181818 0.73913043 0.07692308 0.27777778 0.11111111 0.00000000 0.00000000 
#        Pi 
#0.00000000

### Level 3
# Level 3: summary(dapc.param)$assign.per.pop       # real groups -- really good discrimintation
#     Pamc     Pamll     Pamsl      PaTc      PaTi 
#0.7272727 0.7391304 1.0000000 0.8333333 0.8888889 
# Level 3: dapc.param.rand <- dapc(gt.gi, pop=sample(pop.group.abbr), n.pca=selected.PCs[level], n.da=selected.DFs[level])
# Level 3: summary(dapc.param.rand)$assign.per.pop  # random groups -- really poor discrimination
#      Pamc      Pamll      Pamsl       PaTc       PaTi 
#0.18181818 0.86956522 0.00000000 0.05555556 0.00000000 


