# Installation

**At the moment, installation instructions are provided in Finnsh.**

*Ohjeet päivitetty 12.1.2022*

## Taustapalvelun asennus linux-ympäristöön

```bash
cd ~
sudo apt-get install python3-venv
git clone https://gitlab.tuni.fi/fsd/aasa_backend
python3 -m venv aasa-env
source aasa-env/bin/activate
pip install -r aasa_backend/requirements.txt
pip install -e aasa_backend
```

## Tietokannan luonti:

Asenna `postgresql`

```bash
sudo apt-get -y install postgresql-12
```
Luo tietokanta ja käyttäjä. Käytä salasanassa vain numeroja ja kirjaimia.
Muuta kohdat tietokannan_nimi, käyttäjän_nimi ja salasana haluamiksesi.

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE tietokannan_nimi
    WITH OWNER = postgres
    ENCODING = "UTF8"
    TABLESPACE = pg_default
    TEMPLATE = template0
    LC_COLLATE = "fi_FI.UTF-8"
    LC_CTYPE = "fi_FI.UTF-8;
CREATE USER käyttäjän_nimi WITH ENCRYPTED PASSWORD 'salasana';
GRANT ALL PRIVILEGES ON DATABASE tietokannan_nimi TO käyttäjän_nimi;
\q
```

## Taustapalvelun konfigurointi

Tee `db_config.dist` tiedostosta `db_config`-niminen kopio ja täytä `db_config`-tiedostoon yllä luomasi tietokannan tiedot (tietokannan nimi, käyttäjän nimi sekä salasana). Muuta halutessasi taustapalvelun käyttämä osoite sekä portti.

```bash
cp aasa_backend/aasa_backend/db_config.dist aasa_backend/aasa_backend/db_config
nano aasa_backend/aasa_backend/db_config
```

## Tietokantamigraation ajaminen

Tee `alembic.ini.dist` tiedostosta `alembic.ini`-niminen kopio ja täytä `alembic.ini`-tiedostoon tietokannan yhdistämiseen käytettävä url muuttujaan `sqlalchemy.url`.

```bash
cp aasa_backend/database/alembic_db/alembic.ini.dist aasa_backend/database/alembic_db/alembic.ini
nano aasa_backend/database/alembic_db/alembic.ini
```

Aja tietokantamigraatio. Alembic luo tarvittavat taulut tai tekee nykyiseen taustapalvelun versioon tarvittavat muutokset olemassa olevaan tietokantaan. Jos olemassa oleva tietokanta on luotu ennen Aasan versiota 0.3.0, tulee vanha tietokanta poistaa ennen alembic-migraation ajoa.

```bash
cd ~/aasa_backend/database/alembic_db
alembic upgrade head
```

## Taustapalvelun käynnistys

```bash
cd ~
source aasa-env/bin/activate
python aasa_backend/aasa_backend/server.py -c aasa_backend/aasa_backend/db_config
```