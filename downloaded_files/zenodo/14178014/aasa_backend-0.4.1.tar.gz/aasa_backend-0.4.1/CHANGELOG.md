# Aasa Backend Changelog

## 0.4.1 (2024-11-20)

This release removed an unwanted file and tested the trunk-based development model at the new repository platform.

### Removed

- Removed superfluous file CHANGES.rst (implements issue [#1](https://gitlab.tuni.fi/fsd/aasa_backend/-/issues/1))


## 0.4.0 (2024-11-20)

This is the first public release. At this point, the repository was moved to a new repository host. Issues, merge requests and other branches than master were not moved. This was intentional to smoothline the transition and move to trunk-based development. Finalizing the release was done pushing directly to master. After this, the master was protects again against direct pushes. As a side effect, the releases 0.2.0 and 0.3.0 had to be retagged.

### Added

- Added licensing information
- Added citation information

### Changed

- Rename CHANGES.rst to CHANGELOG.md, switch file format to Markdown; fixed error in changelog for 0.3.0
- Moved installation instructions from README to INSTALLATION, reviewed and fixed formatting
- Updated README.md

## 0.3.0 - 2022/01/12

- New version 0.3.0 of Aasa API - server functionality updated accordingly
- Changes to database structure. Old alembic migrations deleted and replaced with a single initial version.
- Dedicated endpoints for Aasa datapump

## 0.2.0 - 2021/07/26

- Backend server functionality as described in Aasa API documentation v. 0.3.0
- Alembic database migration
