#!/usr/bin/env python3
# Author(s): Saara Saaninkoski and Jukka Lipsanen
# Copyright 2020 Finnish Social Science Data Archive FSD / University of Tampere

from setuptools import (
    setup,
    find_packages
)

with open('VERSION', 'r') as fileobj:
    version = fileobj.readline().strip()

setup(
    name='aasa_backend',
    version=version,
    url='',
    description='A backend service for a study and variable keywording tool',
    author='Jukka Lipsanen and Saara Saaninkoski',
    packages=find_packages(),
    install_requires=[
        'alembic',
        'configargparse',
        'SQLAlchemy',
        'tornado'
        ],
    tests_require=['pytest'],
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'aasa_backend_start = aasa_backend.server:run_server'
        ]
    }
)
