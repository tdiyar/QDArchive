import datetime
import os
import json
import unittest
from collections import namedtuple
from unittest import mock
import datetime
import aasa_backend.database
from aasa_backend.database import AasaDatabase
from aasa_backend import models
from sqlalchemy.orm import joinedload


def query_args(filters, sort_by, limit, skip):
    query_args = namedtuple('args', 'filters, sort_by, limit, skip')
    return query_args(filters, sort_by, limit, skip)


class TestEmptyDatabase(unittest.TestCase):

    @classmethod
    def setUpClass(self):
        self.db = AasaDatabase('sqlite:///:memory:')
        self.db.metadata.create_all(self.db.engine)
        with self.db.make_session() as session:
            session.execute('PRAGMA foreign_keys = ON')

    @classmethod
    def tearDownClass(self):
        self.db.metadata.drop_all(self.db.engine)

    def get_all_empty_database(self, table):
        result = self.db.query(table, query_args([], [], 9000, 0))
        self.assertEqual({'count': 0, 'data': []}, result)

    def test_get_all_studies_empty_returns_empty_list(self):
        self.get_all_empty_database(models.Study)

    def test_get_all_variables_empty_returns_empty_list(self):
        self.get_all_empty_database(models.Variable)

    def test_get_all_terms_empty_returns_empty_list(self):
        self.get_all_empty_database(models.Term)

    def test_get_all_study_terms_empty_returns_empty_list(self):
        result = self.db.query(models.StudyTerm, query_args([], [], 9000, 0))
        self.assertEqual([], result)

    def test_get_all_variable_terms_empty_returns_empty_list(self):
        result = self.db.query(models.VariableTerm, query_args([], [], 9000, 0))
        self.assertEqual([], result)

    def test_get_all_category_values_empty_returns_empty_list(self):
        result = self.db.query(models.CategoryValue, query_args([], [], 9000, 0))
        self.assertEqual([], result)

class TestPopulatedDatabase(unittest.TestCase):
    studies = {}
    variables = {}
    terms = {}
    vocabs = {}

    def setUp(self):
        self.db = AasaDatabase('sqlite:///:memory:')
        self.db.metadata.create_all(self.db.engine)
        self.prep_db()

    def tearDown(self):
        self.db.metadata.drop_all(self.db.engine)

    def prep_db(self):
        with self.db.make_session() as session:
            lang_table = models.Language
            lang_object = lang_table(
                id='fi',
                name='finnish'
            )
            session.add(lang_object)
            session.commit()

        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data.json'), 'r') as jsonf:
            data = json.loads(jsonf.read())
            self.studies = data.get('studies')
            self.variables = data.get('variables')
            self.terms = data.get('terms')
            self.vocabs = data.get('vocabularies')
        for name, study in self.studies.items():
            study_table = models.Study
            study_object = study_table(**study['db'])
            session.add(study_object)
            session.commit()
            study['db']['id'] = study_object.id
            study['exp']['id'] = study_object.id

            study['exp']['date_added'] = datetime.datetime.utcnow().date()
            study['exp']['date_modified'] = None

    def test_get_all_studies(self):
        result = self.db.query(models.Study, query_args([], [], 9000, 0))
        expected_result = []
        for study in self.studies.values():
            study = study['exp']
            expected_result.append(study)
        self.assertEqual({'count': 4, 'data': expected_result}, result)

    def test_get_study_by_idno(self):
        result = self.db.query(models.Study, query_args([getattr(models.Study, 'idno') == 'study_001'], [], 9000, 0))
        study = self.studies['study_001']['exp']
        study['date_added'] = datetime.datetime.utcnow().date()
        study['date_modified'] = None
        self.assertEqual({'count': 1, 'data': [study]}, result)

    def test_not_found_returns_empty_list(self):
        result = self.db.query(models.Study, query_args([getattr(models.Study, 'idno') == 'unvlb'], [], 9000, 0))
        self.assertEqual({'count': 0, 'data': []}, result)

    def test_get_all_studies_sorted_by_title(self):
        result = self.db.query(models.Study, query_args([], [getattr(models.Study, 'title').asc()], 9000, 0))
        expected = {'count': 4, 'data': [self.studies['study_003']['exp']]}
        expected['data'].append(self.studies.get('study_001').get('exp'))
        expected['data'].append(self.studies.get('study_002').get('exp'))
        expected['data'].append(self.studies.get('study_004').get('exp'))
        self.assertEqual(expected, result)
