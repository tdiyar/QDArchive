import unittest
from unittest import mock
import sys
from aasa_backend import (
    server
)


class TestServer(unittest.TestCase):

    def test_parse_args(self):
        sys.argv[1:] = ['--port', '0000', '--username', 'user', '--password', 'pass', '--host', 'host', '--database', 'db']
        args = server.parse_args()
        self.assertEqual(args.port, '0000')
        self.assertEqual(args.username, 'user')
        self.assertEqual(args.password, 'pass')
        self.assertEqual(args.host, 'host')
        self.assertEqual(args.database, 'db')

    @mock.patch('aasa_backend.server.make_app')
    @mock.patch('tornado.ioloop.IOLoop.current')
    def test_run_server(self, mock_ioloop, mock_app):
        sys.argv[1:] = ['--db_url', 'sqlite:///:memory:']
        server.run_server()
        mock_app.assert_called()
        mock_ioloop.assert_called()
