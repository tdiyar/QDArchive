import asyncio
import copy
import json
import os
import sys
from tornado import testing
from aasa_backend import server
from aasa_backend import models
from aasa_backend.database import AasaDatabase


class HandlerTestBase(testing.AsyncHTTPTestCase):
    studies = {}
    variables = {}
    terms = {}
    vocabs = {}

    def setUp(self):
        self.db = AasaDatabase('sqlite:///:memory:')
        self.db.metadata.create_all(self.db.engine)

        with self.db.make_session() as session:
            session.execute('PRAGMA foreign_keys = ON')

        if sys.platform == 'win32':
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        super().setUp()
        self.prep_db()

    def tearDown(self):
        self.db.metadata.drop_all(self.db.engine)

    def get_app(self):
        return server.make_app(self.db)

    def prep_db(self):
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data.json'), 'r') as jsonf:
            data = json.loads(jsonf.read())
            self.studies = data.get('studies')
            self.variables = data.get('variables')
            self.terms = data.get('terms')
            self.vocabs = data.get('vocabularies')
        with self.db.make_session() as session:
            lang_table = models.Language
            lang_object = lang_table(
                id='fi',
                name='finnish'
            )
            session.add(lang_object)
            session.commit()

            lang_table = models.Language
            lang_object = lang_table(
                id='en',
                name='english'
            )
            session.add(lang_object)
            session.commit()

            for v_id, vocab in self.vocabs.items():
                voc_t = models.Vocabulary
                voc_o = voc_t(**vocab)
                session.add(voc_o)
                session.commit()

            for study_idno, study_tuple in self.studies.items():
                study_table = models.Study
                study_object = study_table(**study_tuple['db'])
                session.add(study_object)
                session.commit()
                study_tuple['db']['id'] = study_object.id
                study_tuple['exp']['id'] = study_object.id

            for var_name, var_tuple in self.variables.items():
                var_table = models.Variable
                var_data = var_tuple['db']
                var_study_tuple = self.studies[var_data.pop('study')]
                var_data['study_id'] = var_study_tuple['db']['id']

                var_object = var_table(**var_data)
                session.add(var_object)
                session.commit()
                
                var_tuple['db']['id'] = var_object.id
                var_tuple['exp']['id'] = var_object.id
                var_tuple['exp']['study_id'] = var_data['study_id']
                var_tuple['exp']['study_idno'] = var_study_tuple['db']['idno']
                var_tuple['exp']['language_id'] = var_study_tuple['db']['language_id']
                

            for t_val, term in self.terms.items():
                term_t = models.Term
                term_obj = term_t(**term)
                
                session.add(term_obj)
                session.commit()
                term['id'] = term_obj.id
                
    
    def remove_date(self, records):
        for rec in records['data']:
            if rec.get('date_added', None):
                rec.pop('date_added')
                rec.pop('date_modified')
        return records
    
    def test_invalid_path_returns_404(self):
        response = self.fetch('/nonono?embed_terms=true')
        self.assertEqual(response.code, 404)

def with_count(count, data):
    return{'count': count, 'data': data}

class TestStudyHandler(HandlerTestBase):
    def test_GET_studies_returns_200_for_no_path_args(self):
        response = self.fetch('/studies?embed_terms=true')
        count = len(self.studies)
        expected_resbody = with_count(count, [val['exp'] for val in self.studies.values()])
        loaded_res = json.loads(response.body.decode('utf-8'))
        self.assertEqual(response.code, 200)

        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_studies_sorted_by_id_desc(self):
        res = self.fetch('/studies?sort_by=idno-desc&embed_terms=true')

        expected_resbody = with_count(4, [self.studies['study_004']['exp'],
                            self.studies['study_003']['exp'],
                            self.studies['study_002']['exp'],
                            self.studies['study_001']['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_studies_sorted_by_id_asc(self):
        res = self.fetch('/studies?sort_by=idno&embed_terms=true')

        expected_resbody = with_count(4, [self.studies['study_001']['exp'],
                            self.studies['study_002']['exp'],
                            self.studies['study_003']['exp'],
                            self.studies['study_004']['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_studies_invalid_sort(self):
        res = self.fetch('/studies?sort_by=name')
        self.assertEqual(res.code, 400)

    def test_GET_study_by_idno(self):
        res = self.fetch('/studies?idno=study_001&embed_terms=true')

        expected_resbody = with_count(1, [self.studies.get('study_001')['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_study_by_title_case_insensitive(self):
        res = self.fetch('/studies?title=STUDY_001%&embed_terms=true')
        expected_resbody = with_count(1, [self.studies.get('study_001')['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_study_by_idno_not_exist_200_with_empty_body(self):
        res = self.fetch('/studies?idno=study_007')

        expected_resbody = with_count(0, [])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_study_by_invalid_filter_returns_400(self):
        res = self.fetch('/studies?justno=no')
        self.assertEqual(res.code, 400)

    def test_GET_study_by_idno_OR(self):
        res = self.fetch('/studies?idno=study_001|study_002&embed_terms=true')
        expected_resbody = with_count(2, [
            self.studies.get('study_001')['exp'],
            self.studies.get('study_002')['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_study_by_id_OR(self):
        res = self.fetch('/studies?id=1|2&embed_terms=true')
        expected_resbody = with_count(2, [
            self.studies.get('study_001')['exp'],
            self.studies.get('study_002')['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_GET_study_with_embed_terms_and_not_true_or_false_raises_400(self):
        res = self.fetch('/studies?embed_terms=dong')
        self.assertEqual(res.code, 400)

    def test_PATCH_study_keyworded(self):
        res = self.fetch('/studies?idno=study_003')
        self.assertEqual(res.code, 200)
        study = json.loads(res.body.decode('utf-8'))['data'][0]
        self.assertTrue(study['keyworded'])

        res = self.fetch('/studies/{}'.format(study['id']), method='PATCH', body=json.dumps({'keyworded': False}), headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 200)

        res = self.fetch('/studies?idno=study_003')
        study = json.loads(res.body.decode('utf-8'))['data'][0]
        self.assertEqual(res.code, 200)
        self.assertFalse(study['keyworded'])

    def test_PATCH_study_keyworded_without_id_raises_405(self):
        res = self.fetch('/studies', method='PATCH', body=json.dumps({'keyworded': False}), headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 405)

    def test_PATCH_study_keyworded_study_not_found_raises_405(self):
        res = self.fetch('/studies/666', method='PATCH', body=json.dumps({'keyworded': False}), headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 404)

    def test_GET_study_by_term_id(self):
        res = self.fetch('/terms?value=term_001')
        term_001 = json.loads(res.body.decode('utf-8'))['data'][0]

        study_005 = {
            'db': {
                'idno': 'study_005',
                'language_id':  'fi',
                'title': 'Study 005 title',
                'abstract': 'Study 005 abstract',
                'keyworded': False,
                'variables': []
            },
            'exp': {
                'idno': 'study_005',
                'language_id':  'fi',
                'title': 'Study 005 title',
                'abstract': 'Study 005 abstract',
                'keyworded': False
            }
        }
        body = json.dumps(study_005.get('db'))
        res = self.fetch('/studies', method='POST', body=body, headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res = self.fetch('/studies?idno=study_005')
        study_id = json.loads(res.body.decode('utf-8'))['data'][0]['id']

        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST', 
                         body=json.dumps({'term_id': term_001['id']}),
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res = self.fetch('/studies?terms_include={}&embed_terms=false'.format(term_001['id']))
        self.assertEqual(res.code, 200)
        loaded_body = json.loads(res.body.decode('utf-8'))
        for st in loaded_body['data']:
            st.pop('id')
        self.assertEqual(self.remove_date(loaded_body), with_count(1, [study_005.get('exp')]))

    def test_POST_study_raises_400_with_empty_body(self):
        res = self.fetch('/studies', method='POST', allow_nonstandard_methods=True)
        self.assertEqual(res.code, 400)

    def test_GET_study_with_nonexisting_id_raises_404(self):
        res = self.fetch('/studies/666')
        self.assertEqual(res.code, 404)

    def test_POST_study_with_nonjson_raises_415(self):
        new_body = {
            'idno': 'study_008',
            'language_id':  'fi',
            'title': 'Study 008 title',
            'abstract': 'Study 008 abstract',
            'keyworded': False,
        }

        body = json.dumps(new_body)
        res = self.fetch('/studies', method='POST', body=body,
                         headers={'Content-Type': 'text/html'})
        self.assertEqual(res.code, 415)

    def test_POST_study(self):
        new_body = {
            'idno': 'study_008',
            'language_id':  'fi',
            'title': 'Study 008 title',
            'abstract': 'Study 008 abstract',
            'keyworded': False
        }

        body = json.dumps(new_body)
        res = self.fetch('/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        get_res = self.fetch('/studies/?idno=study_008&embed_terms=false')
        res_body = json.loads(get_res.body.decode('utf-8'))
        if res_body:
            res_body['data'][0].pop('id')

        self.assertEqual(self.remove_date(res_body), with_count(1, [new_body]))

    def test_POST_study_with_same_idno_and_language_raises_409(self):
        new_body = {
            'idno': 'study_001',
            'language_id':  'fi',
            'title': 'Study 008 title',
            'abstract': 'Study 008 abstract',
            'keyworded': False
        }

        body = json.dumps(new_body)
        res = self.fetch('/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 409)

    def test_unsuccessful_POST_study_rolls_back(self):
        new_body = [
            {
            'idno': 'study_009',
            'language_id':  'fi',
            'title': 'Study 008 title',
            'abstract': 'Study 008 abstract',
            'keyworded': False
            }, {
            'language_id':  'en',
            'title': 'Study 008 en title',
            'abstract': 'Study 008 en abstract',
            'keyworded': False
            }
        ]

        body = json.dumps(new_body)
        res = self.fetch('/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 400)

        get_res = self.fetch('/studies?idno=study_009&embed_terms=false')

        expected_resbody = []
        loaded_res = json.loads(get_res.body.decode('utf-8'))

        self.assertEqual(get_res.code, 200)
        self.assertEqual(loaded_res, with_count(0, expected_resbody))

    def test_DELETE_study(self):
        res = self.fetch('/studies?idno=study_004', method='DELETE')
        self.assertEqual(res.code, 204)

        res = self.fetch('/studies?idno=study_004')

        expected_resbody = with_count(0, [])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(loaded_res, expected_resbody)

    def test_GET_with_term_filter(self):
        term = self.fetch('/terms')
        term = json.loads(term.body.decode('utf-8'))['data'][0]

        body = {
            'idno': 'study_009',
            'language_id':  'fi',
            'title': 'Study 009 title',
            'abstract': 'Study 009 abstract',
            'keyworded': False
        }

        body = json.dumps(body)

        res = self.fetch('/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res = self.fetch('/studies?idno=study_009')
        self.assertEqual(res.code, 200)
        study_id = json.loads(res.body.decode('utf-8'))['data'][0]['id']

        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST',
        body=json.dumps({'term_id': term['id']}),
        headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/studies?terms_include={}&embed_terms=false'.format(term['id']))
        self.assertEqual(res.code, 200)
        response_json = json.loads(res.body.decode('utf-8'))
        self.assertEqual(response_json['count'], 1)
        self.assertEqual(response_json['data'][0]['id'], study_id)

    def test_GET_with_term_value_filter_case_insensitive(self):
        term = self.fetch('/terms')
        term = json.loads(term.body.decode('utf-8'))['data'][0]

        body = {
            'idno': 'study_009',
            'language_id':  'fi',
            'title': 'Study 009 title',
            'abstract': 'Study 009 abstract',
            'keyworded': False
        }

        body = json.dumps(body)

        res = self.fetch('/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res = self.fetch('/studies?idno=study_009')
        self.assertEqual(res.code, 200)
        study_id = json.loads(res.body.decode('utf-8'))['data'][0]['id']

        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST',
        body=json.dumps({'study_id': study_id, 'term_id': term['id']}),
        headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/studies?terms_value_include={}'.format(term['value'].upper()))
        self.assertEqual(res.code, 200)
        response_json = json.loads(res.body.decode('utf-8'))
        self.assertEqual(response_json['count'], 1)
        self.assertEqual(response_json['data'][0]['idno'], 'study_009')

    def test_GET_with_nonexistent_term(self):
        res = self.fetch('/studies?terms_include=666')
        self.assertEqual(res.code, 200)
        response_json = json.loads(res.body.decode('utf-8'))
        self.assertEqual(response_json['count'], 0)

    def test_query_study_with_multiple_filters(self):
        body = json.dumps([{'idno': 'study_001'}, {'idno': 'study_003'}])
        res = self.fetch('/studies/pick', method='POST', body=body, headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(len(res_body), 2)
        self.assertTrue(res_body[0]['idno'] in ('study_001', 'study_003'))
        self.assertTrue(res_body[1]['idno'] in ('study_001', 'study_003'))


class TestVariableHandler(HandlerTestBase):
    def test_GET_variables_returns_200_for_no_path_args(self):
        res = self.fetch('/variables?embed_terms=true')
        self.assertEqual(res.code, 200)
        loaded_res = json.loads(res.body.decode('utf-8'))
        expected_resbody = [val['exp'] for val in self.variables.values()]
        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), with_count(6, expected_resbody))

    def test_GET_variable_by_name(self):
        res = self.fetch('/variables?name=variable_001a&embed_terms=true')

        expected_resbody = self.variables.get('variable_001a').get('exp')
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), with_count(1, [expected_resbody]))

    def test_GET_variable_by_term_value_case_insensitive(self):
        res = self.fetch('/studies?idno=study_004')
        self.assertEqual(res.code, 200)
        study = json.loads(res.body.decode('utf-8'))['data'][0]

        res = self.fetch('/terms?value=term_001')
        self.assertEqual(res.code, 200)
        term = json.loads(res.body.decode('utf-8'))['data'][0]

        body = {
            'name': 'variable_004',
            'study_id': study['id'],
            'is_translated': False,
            'is_fielded': False,
            'varGrp': '',
            'labl': 'var_004 labl',
            'preQTxt': 'var_004 preqtxt',
            'qstnLit': 'var_004 lit',
            'postQTxt': 'var_004 postqtxt',
            'ivuInstr': 'var_004 ivuinstr',
            'catValues': [],
            'notes': '',
            'var_cluster': None,
            'keyworded': False,
            'index': 0
        }

        body = json.dumps(body)
        res = self.fetch('/variables', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res = self.fetch('/variables?name=variable_004')
        self.assertEqual(res.code, 200)
        var_id = json.loads(res.body.decode('utf-8'))['data'][0]['id']

        res = self.fetch('/variables/{}/terms'.format(var_id), method='POST',
        body=json.dumps({'term_id': term['id']}),
        headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/variables?terms_value_include=TERM_001')
        self.assertEqual(res.code, 200)
        response_json = json.loads(res.body.decode('utf-8'))
        self.assertEqual(response_json['count'], 1)
        self.assertEqual(response_json['data'][0]['name'], 'variable_004')

    def test_GET_variable_by_name_not_exist_200_with_empty_body(self):
        res = self.fetch('/variables?name=variable_100&embed_terms=true')

        expected_resbody = []
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(loaded_res, with_count(0, expected_resbody))

    def test_GET_variable_by_study_id(self):
        study_id = self.studies['study_001']['db']['id']
        res = self.fetch('/variables?study_id={}'.format(study_id))
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertGreater(loaded_res['count'], 0)

    def test_GET_variable_invalid_value_for_limit(self):
        res = self.fetch('/variables?limit=ding')
        self.assertEqual(res.code, 400)

    def test_GET_variables_sort_by_study_idno(self):
        res = self.fetch('/variables?sort_by=study_idno&embed_terms=true')

        expected_resbody = with_count(6, [
            self.variables['variable_001a']['exp'],
            self.variables['variable_001b']['exp'],
            self.variables['variable_004a']['exp'],
            self.variables['variable_002a']['exp'],
            self.variables['variable_003a']['exp'],
            self.variables['variable_003b']['exp']])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(self.remove_date(loaded_res), expected_resbody)

    def test_POST_variable(self):
        study = self.fetch('/studies?idno=study_004')
        study = json.loads(study.body.decode('utf-8'))['data'][0]

        new_body = {
            'name': 'variable_004',
            'study_id': study['id'],
            'is_translated': False,
            'is_fielded': False,
            'varGrp': '',
            'labl': 'var_004 labl',
            'preQTxt': 'var_004 preqtxt',
            'qstnLit': 'var_004 lit',
            'postQTxt': 'var_004 postqtxt',
            'ivuInstr': 'var_004 ivuinstr',
            'catValues': [],
            'notes': '',
            'var_cluster': None,
            'keyworded': False,
            'index': 0
        }

        body = json.dumps(new_body)
        res = self.fetch('/variables', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/variables/?name=variable_004&embed_terms=false')
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        if res_body:
            res_body['data'][0].pop('id')
            res_body['data'][0].pop('language_id')
            res_body['data'][0].pop('study_idno')
        self.assertEqual(self.remove_date(res_body), with_count(1, [new_body]))

    def test_POST_variable_with_catValues(self):
        res = self.fetch('/studies?idno=study_004')
        self.assertEqual(res.code, 200)
        study = json.loads(res.body.decode('utf-8'))['data'][0]

        new_body = {
            'name': 'variable_005',
            'study_id': study['id'],
            'is_translated': False,
            'is_fielded': False,
            'varGrp': '',
            'labl': 'var_005 labl',
            'preQTxt': 'var_005 preqtxt',
            'qstnLit': 'var_005 lit',
            'postQTxt': 'var_005 postqtxt',
            'ivuInstr': 'var_005 ivuinstr',
            'catValues': [{'catvalue_index': 1, 'catValu': 'test_catvalu','catLabl': 'test_catval_labl', 'catStat': None}],
            'notes': '',
            'var_cluster': None,
            'keyworded': False,
            'index': 0
        }
        body = json.dumps(new_body)
        res = self.fetch('/variables', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        get_res = self.fetch('/variables/?name=variable_005&embed_terms=false')
        res_body = json.loads(get_res.body.decode('utf-8'))

        res_body['data'][0].pop('id')
        res_body['data'][0].pop('language_id')
        res_body['data'][0].pop('study_idno')

        self.assertEqual(self.remove_date(res_body), with_count(1, [new_body]))

    def test_DELETE_variable(self):
        res = self.fetch('/variables?name=variable_003b')
        loaded_res = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertGreater(loaded_res['count'], 0)

        res = self.fetch('/variables?name=variable_003b', method='DELETE')
        self.assertEqual(res.code, 204)

        res = self.fetch('/variables?name=variable_003b')
        loaded_res = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        expected_resbody = with_count(0, [])
        self.assertEqual(loaded_res, expected_resbody)

    def test_GET_with_term_filter(self):
        res = self.fetch('/studies?idno=study_004')
        self.assertEqual(res.code, 200)
        study = json.loads(res.body.decode('utf-8'))['data'][0]

        res = self.fetch('/terms?value=term_001')
        self.assertEqual(res.code, 200)
        term = json.loads(res.body.decode('utf-8'))['data'][0]

        body = {
            'name': 'variable_004',
            'study_id': study['id'],
            'is_translated': False,
            'is_fielded': False,
            'varGrp': '',
            'labl': 'var_004 labl',
            'preQTxt': 'var_004 preqtxt',
            'qstnLit': 'var_004 lit',
            'postQTxt': 'var_004 postqtxt',
            'ivuInstr': 'var_004 ivuinstr',
            'catValues': [],
            'notes': '',
            'var_cluster': None,
            'keyworded': False,
            'index': 0
        }

        body = json.dumps(body)
        res = self.fetch('/variables', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res = self.fetch('/variables?name=variable_004')
        var_id = json.loads(res.body.decode('utf-8'))['data'][0]['id']

        res = self.fetch('/variables/{}/terms'.format(var_id), method='POST',
        body=json.dumps({'variable_id': var_id, 'term_id': term['id']}),
        headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/variables?terms_include={}'.format(term['id']))
        self.assertEqual(res.code, 200)
        response_json = json.loads(res.body.decode('utf-8'))
        self.assertEqual(response_json['count'], 1)
        self.assertEqual(response_json['data'][0]['name'], 'variable_004')

    def test_GET_with_nonexistent_term(self):
        res = self.fetch('/variables?terms_include=666')
        self.assertEqual(res.code, 200)
        response_json = json.loads(res.body.decode('utf-8'))
        self.assertEqual(response_json['count'], 0)

class TestTermHandler(HandlerTestBase):
    def test_GET_terms_returns_200_for_no_path_args(self):
        response = self.fetch('/terms')

        loaded_res = json.loads(response.body.decode('utf-8'))
        expected_resbody = [val for val in self.terms.values()]
        self.assertEqual(response.code, 200)
        self.assertEqual(loaded_res, with_count(6, expected_resbody))

    def test_GET_term_by_value(self):
        res = self.fetch('/terms?value=term_001')

        expected_resbody = self.terms.get('term_001')
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(loaded_res, with_count(1, [expected_resbody]))

    def test_GET_term_by_value_partial(self):
        res = self.fetch('/terms?value=term_00%')

        expected_resbody = [t for k, t in self.terms.items() if k != "term_123"]
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(loaded_res, with_count(5, expected_resbody))

    def test_GET_term_by_value_not_exist_200_with_empty_body(self):
        res = self.fetch('/terms?value=term_100')

        expected_resbody = with_count(0, [])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(loaded_res, expected_resbody)

    def test_GET_term_with_embed_terms_raises_400(self):
        res = self.fetch('/terms?embed_terms=true')
        self.assertEqual(res.code, 400)

    def test_POST_term(self):
        res = self.fetch('/terms/?value=term_006%20value')  
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 0)

        new_body = {
            'vocab': self.vocabs['vocab_1']['vocab'],
            'value': 'term_006 value',
            'language_id': 'fi',
            'uri': None,
            'removed': False,
            'deprecated': False
        }

        body = json.dumps(new_body)
        res = self.fetch('/terms', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/terms/?value=term_006%20value')
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        res_body['data'][0].pop('id')
        self.assertEqual(res_body, with_count(1, [new_body]))

    def test_DELETE_term(self):
        res = self.fetch('/terms?value=term_004')
        self.assertEqual(res.code, 200)
        loaded_res = json.loads(res.body.decode('utf-8'))
        self.assertEqual(loaded_res['count'], 1)

        res = self.fetch('/terms?value=term_004', method='DELETE')
        self.assertEqual(res.code, 204)

        res = self.fetch('/terms?value=term_004')
        self.assertEqual(res.code, 200)

        expected_resbody = with_count(0, [])
        loaded_res = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res.code, 200)
        self.assertEqual(loaded_res, expected_resbody)


class TestVariableTermHandler(HandlerTestBase):
    def test_GET_variable_terms_returns_404_for_no_id(self):
        response = self.fetch('/variables/terms')
        self.assertEqual(response.code, 404)

    def test_POST_variable_term(self):
        variable_id = self.variables['variable_001a']['exp']['id']
        term_id = self.terms['term_001']['id']
        new_body = {
            'source': 'user',
            'annotator_name': 'unknown_user',
            'term_id': term_id
        }
        res = self.fetch('/variables?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 0)

        body = json.dumps(new_body)
        res = self.fetch('/variables/{}/terms'.format(variable_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res_body = json.loads(res.body.decode('utf-8'))
        new_body.pop('term_id')
        new_body['variable_id'] = variable_id
        new_body['term'] = self.terms['term_001']

        self.assertEqual(res_body, new_body)

        res = self.fetch('/variables?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 1)

    def test_POST_custom_variable_term(self):
        variable_id = self.variables['variable_001a']['exp']['id']
        term_id = self.terms['term_001']['id']
        new_body = {
            'value': 'magic',
            'annotator_name': 'vip'
        }

        body = json.dumps(new_body)
        res = self.fetch('/variables/{}/terms/custom'.format(variable_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res_body = json.loads(res.body.decode('utf-8'))
        expected_result = {"variable_id": variable_id, "source": "user", "annotator_name": "vip",
            "term": {"id": res_body['term']['id'], "vocab": "Custom", "language_id": "fi", "value": "magic", "uri": None, "removed": False, "deprecated": False}}

        self.assertEqual(res_body, expected_result)

        res = self.fetch('/variables?terms_include={}'.format(res_body['term']['id']))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 1)

    def test_POST_custom_variable_term_missing_value_raises_400(self):
        variable_id = self.variables['variable_001a']['exp']['id']
        new_body = {'annotator_name': 'vip'}

        body = json.dumps(new_body)
        res = self.fetch('/variables/{}/terms/custom'.format(variable_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 400)

    def test_POST_finto_variable_term(self):
        term = {'vocab': 'YSO', 'language_id': 'fi', 'value': 'wild term',
            'uri': 'uri-of-wildness', 'removed': False, 'deprecated': False}
        res = self.fetch('/terms', method='POST', body=json.dumps(term),
                    headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        term['id'] = json.loads(res.body.decode('utf-8'))['id']

        variable_id = self.variables['variable_001a']['exp']['id']
        new_body = {
            'uri': 'uri-of-wildness',
            'annotator_name': 'vip'
        }

        res = self.fetch('/variables?terms_uri_include=uri-of-wildness')
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 0)

        body = json.dumps(new_body)
        res = self.fetch('/variables/{}/terms/finto-ai'.format(variable_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res_body = json.loads(res.body.decode('utf-8'))
        expected_result = {"variable_id": variable_id, "source": "user", "annotator_name": "vip",
            "term": term}

        self.assertEqual(res_body, expected_result)

        res = self.fetch('/variables?terms_uri_include=uri-of-wildness')
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 1)

    def test_POST_finto_variable_term_missing_uri_raises_400(self):
        variable_id = self.variables['variable_001a']['exp']['id']
        new_body = {
            'annotator_name': 'vip'
        }
        body = json.dumps(new_body)
        res = self.fetch('/variables/{}/terms/finto-ai'.format(variable_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 400)


    def test_DELETE_variable_term(self):
        variable_id = self.variables['variable_001a']['exp']['id']
        term_id = self.terms['term_001']['id']
        new_body = {
            'source': 'user',
            'annotator_name': 'unknown_user',
            'term_id': term_id
        }

        res = self.fetch('/variables/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 0)

        body = json.dumps(new_body)
        res = self.fetch('/variables/{}/terms'.format(variable_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/variables/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 1)

        res = self.fetch('/variables/{}/terms/user/{}'.format(variable_id, term_id), method='DELETE')
        self.assertEqual(res.code, 204)

        res = self.fetch('/variables/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 0)


class TestStudyTermHandler(HandlerTestBase):
    def test_GET_study_terms_returns_200_for_no_path_args(self):
        response = self.fetch('/studies/terms')
        self.assertEqual(response.code, 404)

    def test_POST_study_term(self):
        study_id = self.studies['study_001']['exp']['id']
        term_id = self.terms['term_001']['id']
        new_body = {
            'source': 'user',
            'annotator_name': 'unknown_user',
            'term_id': term_id
        }
        res = self.fetch('/studies?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 0)

        body = json.dumps(new_body)
        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res_body = json.loads(res.body.decode('utf-8'))

        new_body.pop('term_id')
        new_body['term'] = self.terms['term_001']
        new_body['study_id'] = study_id

        self.assertEqual(res_body, new_body)

        res = self.fetch('/studies?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 1)

    def test_POST_study_term_doesnt_exist_returns_409(self):
        study_id = self.studies['study_001']['exp']['id']
        new_body = {
            'annotator_name': 'user1',
            'source': 'user',
            'term_id': 666
        }

        body = json.dumps(new_body)
        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 409)

    def test_POST_study_term_study_doesnt_exist_returns_404(self):
        new_body = {
            'annotator_name': 'user1',
            'source': 'user',
            'term_id': 666
        }
        res = self.fetch('/studies/666/terms', method='POST', body=json.dumps(new_body),
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 404)


    def test_DELETE_study_term(self):
        study_id = self.studies['study_001']['exp']['id']
        term_id = self.terms['term_001']['id']
        new_body = {
            'source': 'user',
            'annotator_name': 'unknown_user',
            'term_id': term_id
        }

        res = self.fetch('/studies/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 0)

        body = json.dumps(new_body)
        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        res = self.fetch('/studies/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 1)

        res = self.fetch('/studies/{}/terms/user/{}'.format(study_id, term_id), method='DELETE')
        self.assertEqual(res.code, 204)

        res = self.fetch('/studies/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        self.assertEqual(res_body['count'], 0)


class TestVocabularyHandler(HandlerTestBase):
    def test_GET_vocabulary_returns_200_for_no_path_args(self):
        response = self.fetch('/vocabularies')
        self.assertEqual(response.code, 200)

    def test_POST_vocabulary(self):
        new_body = {
            'vocab': 'test_voc_post',
            'vocabURI': 'test_voc_post.uri'
        }

        body = json.dumps(new_body)
        res = self.fetch('/vocabularies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        get_res = self.fetch('/vocabularies/?vocab=test_voc_post')
        res_body = json.loads(get_res.body.decode('utf-8'))

        self.assertEqual(res_body, [new_body])

    def test_DELETE_vocabulary(self):
        new_body = {
            'vocab': 'test_voc_del',
            'vocabURI': 'test_voc_del.uri'
        }
        body = json.dumps(new_body)
        res = self.fetch('/vocabularies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        get_res = self.fetch('/vocabularies?vocab=test_voc_del')
        res_body = json.loads(get_res.body.decode('utf-8'))
        self.assertEqual(get_res.code, 200)
        self.assertGreater(len(res_body), 0)

        res = self.fetch('/vocabularies?vocab=test_voc_del', method='DELETE')
        self.assertEqual(res.code, 204)

        get_res = self.fetch('/vocabularies?vocab=test_voc_del')
        res_body = json.loads(get_res.body.decode('utf-8'))

        self.assertEqual([], res_body)


class TestStudyBatchHandler(HandlerTestBase):
    def test_POST_returns_created(self):
        new_body = [
            {
                'idno': 'batchstudy',
                'language_id': 'fi',
                'title': 'batchstudy title',
                'abstract': 'batchstudy abstract'
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertGreater(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 0)

    def test_POST_returns_modified(self):
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'title': 'new title',
                'abstract': 'new abstract'
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertGreater(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 0)

        self.assertEqual(self.studies['study_001']['exp']['id'], res_body['modified'].pop()['id'])

    def test_POST_returns_failed_missing_attribute(self):
        new_body = [
            {
                'idno': 'study_001'
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertGreater(len(res_body['failed']), 0)

        self.assertEqual(res_body['failed'][0]['req_object'], new_body[0])
        self.assertEqual(res_body['failed'][0]['reason'], 'Missing study idno or language_id')

    def test_POST_returns_failed_invalid_attribute(self):
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'doesnotexist': None
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertGreater(len(res_body['failed']), 0)

        self.assertEqual(res_body['failed'][0]['req_object'], new_body[0])
        self.assertEqual(res_body['failed'][0]['reason'], 'Invalid attribute for Study: doesnotexist')

    def test_POST_new_with_false_terms_doesnt_add_study(self):
        new_body = [
            {
                'idno': 'study_666',
                'language_id': 'fi',
                'title': 'test title',
                'abstract': 'new abstract',
                'terms': [
                    {'vocabulary_id': 'vocab_1', 'language_id': 'fi', 'value': 'new1'},
                    {'language_id': 'fi', 'value': 'new2'}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 1)
        
        res = self.fetch('/studies?idno=study_666')
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body, with_count(0, []))

    def test_POST_existing_with_new_terms(self):
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'terms': [
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new1'},
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new2'}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertGreater(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 0)

        res = self.fetch('/studies/{}'.format(self.studies['study_001']['db']['id']))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        term = [study_term['term'] for study_term in res_body['terms'] if study_term['term']['value'] == 'new1'][0]
        self.assertTrue(term['removed'])

    def test_POST_existing_with_terms_false_term_attributes_returns_failed(self):
        # Add studyterm
        study_id = self.studies['study_001']['exp']['id']
        term_id = self.terms['term_001']['id']
        st_body = {
            'source': 'user',
            'annotator_name': 'unknown_user',
            'term_id': term_id
        }

        res = self.fetch('/studies/{}/terms'.format(study_id), method='POST', body=json.dumps(st_body),
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)
        res_body = json.loads(res.body.decode('utf-8'))

        st_body.pop('term_id')
        st_body['term'] = self.terms['term_001']
        st_body['study_id'] = study_id

        self.assertEqual(res_body, st_body)

        res = self.fetch('/studies?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(res_body['count'], 1)

        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'terms': [
                    {'vocab': 'vocab_1', 'language_id': 'fi'},
                    {'vocab': 'vocab_1', 'language_id': 'fi'}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 1)
        self.assertEqual(res_body['failed'][0]['req_object'], new_body[0])
        
        # Assert studyterms were not deleted
        res = self.fetch('/studies/?terms_include={}'.format(term_id))
        self.assertEqual(res.code, 200)
        self.assertEqual(json.loads(res.body.decode('utf-8'))['count'], 1)

    def test_POST_existing_with_variables(self):
        catvalues =[[
            {'catvalue_index': 0, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''},
            {'catvalue_index': 1, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''},
            {'catvalue_index': 2, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''}
            ],[
            {'catvalue_index': 0, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''},
            {'catvalue_index': 1, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''},
            {'catvalue_index': 2, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''},
            {'catvalue_index': 3, 'catValu': 'one', 'catLabl': 'one', 'catStat': ''}
            ]]
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'variables': [
                    {'name': 'new1', 'labl': 'new1', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 666, 'catValues': catvalues[0]},
                    {'name': 'new2', 'labl': 'new2', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 667, 'catValues': catvalues[1]}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertGreater(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 0)

        res = self.fetch('/variables?study_id={}'.format(self.studies['study_001']['db']['id']))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res_body['count'], 2)
        var_names = [v['name'] for v in res_body['data']]
        self.assertTrue('new2' in var_names)
        self.assertTrue('new1' in var_names)

    def test_POST_existing_with_variables_invalid_var_attrs(self):
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'variables': [
                    {'invalid': 'new1', 'labl': 'new1', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 666},
                    {'name': 'new2', 'labl': 'new2', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 667}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertGreater(len(res_body['failed']), 0)
        
        res = self.fetch('/variables?study_id={}'.format(self.studies['study_001']['db']['id']))
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertFalse('new1' in [var['labl'] for var in res_body['data']])
        self.assertFalse('new2' in [var['labl'] for var in res_body['data']])

    def test_POST_existing_with_variables_and_variable_terms(self):
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'variables': [
                    {'name': 'new1', 'labl': 'new1', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 666,
                    'terms': [
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new1'},
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new2'}
                ]},
                    {'name': 'new2', 'labl': 'new2', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 667,
                    'terms': [
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new11'},
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new22'}
                ]}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertGreater(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 0)
        
        res = self.fetch('/variables?study_id={}&embed_terms=true'.format(self.studies['study_001']['db']['id']))
        self.assertEqual(res.code, 200)
        res_body = json.loads(res.body.decode('utf-8'))

        term_vals = [term['term']['value'] for var in res_body['data'] for term in var['terms']]
        self.assertTrue('new2' in term_vals and 'new2' in term_vals and 'new11' in term_vals and 'new22' in term_vals)

    def test_POST_existing_with_variables_and_variable_terms_wrong_attributes(self):
        new_body = [
            {
                'idno': 'study_001',
                'language_id': 'fi',
                'variables': [
                    {'name': 'new1', 'labl': 'new1', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 666,
                    'terms': [
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new1'},
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new2'}
                ]},
                    {'name': 'new2', 'labl': 'new2', 'preQTxt': '', 'postQTxt': '', 'qstnLit': '', 'ivuInstr': '', 'index': 667,
                    'terms': [
                    {'nohave': 'vocab_1', 'language_id': 'fi', 'value': 'new11'},
                    {'vocab': 'vocab_1', 'language_id': 'fi', 'value': 'new22'}
                ]}
                ]
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/studies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertGreater(len(res_body['failed']), 0)
        self.assertTrue(res_body['failed'][0]['reason'].startswith('Missing one or more required'))

class TestVocabularyBatchHandler(HandlerTestBase):
    def test_POST_returns_created_and_modified(self):
        new_body = {
            'vocab': 'batch',
            'vocabURI': 'batch.uri'
        }

        body = json.dumps(new_body)
        res = self.fetch('/vocabularies', method='POST', body=body,
                         headers={'Content-Type': 'application/json'})
        self.assertEqual(res.code, 201)

        new_body = [
            {
                'language_id': 'fi',
                'value': '1000',
                'uri': '1000-uri'
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/vocabularies/batch', method='POST', body=body,
                            headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertGreater(len(res_body['created']), 0)
        self.assertEqual(len(res_body['modified']), 0)
        self.assertEqual(len(res_body['failed']), 0)
        new_body = [
            {
                'language_id': 'fi',
                'value': '100q',
                'uri': '1000-uri'
            },
            {
                'language_id': 'fi',
                'value': '5000',
                'uri': '5000-uri'
            }
        ]
        body = json.dumps(new_body)
        res = self.fetch('/batch-update/vocabularies/batch', method='POST', body=body,
                            headers={'Content-Type': 'application/json'})
        res_body = json.loads(res.body.decode('utf-8'))
        self.assertEqual(res.code, 200)
        self.assertEqual(len(res_body['created']), 1)
        self.assertEqual(len(res_body['modified']), 1)
        self.assertEqual(len(res_body['failed']), 0)


class TestVariableTermBatchHandler(HandlerTestBase):
    def test_POST_variable_term_batch(self):
        content = [{
            "variable_id": self.variables.get('variable_001a').get('exp').get('id'), "terms": [{"id": self.terms.get('term_001').get('id')}, {"id": self.terms.get('term_002').get('id')}]
        }]
        res = self.fetch('/batch-update/variable-terms/annif', body=json.dumps(content), headers={'Content-Type': 'application/json'}, method='POST')
        self.assertEqual(res.code, 200)

    def test_POST_variable_term_batch_invalid_key_raises_400(self):
        content = [{
            "variable": self.variables.get('variable_001a').get('exp').get('id'), "terms": [{"id": self.terms.get('term_001').get('id')}, {"id": self.terms.get('term_002').get('id')}]
        }]
        res = self.fetch('/batch-update/variable-terms/annif', body=json.dumps(content), headers={'Content-Type': 'application/json'}, method='POST')
        self.assertEqual(res.code, 400)

class TestStudyTermBatchHandler(HandlerTestBase):
    def test_POST_study_term_batch(self):
        content = [{
            "study_id": self.studies.get('study_001').get('exp').get('id'), "terms": [{"id": self.terms.get('term_001').get('id')}, {"id": self.terms.get('term_002').get('id')}]
        }]
        res = self.fetch('/batch-update/study-terms/annif', body=json.dumps(content), headers={'Content-Type': 'application/json'}, method='POST')
        self.assertEqual(res.code, 200)

    def test_POST_variable_term_batch_invalid_key_raises_400(self):
        content = [{
            "variable": self.variables.get('variable_001a').get('exp').get('id'), "terms": [{"id": self.terms.get('term_001').get('id')}, {"id": self.terms.get('term_002').get('id')}]
        }]
        res = self.fetch('/batch-update/variable-terms/annif', body=json.dumps(content), headers={'Content-Type': 'application/json'}, method='POST')
        self.assertEqual(res.code, 400)