"""Main entry point for starting Aasa backend server.
"""
import getpass
import logging
import os
import sys
import tempfile
from tornado.web import Application
from tornado.ioloop import IOLoop
import configargparse

from aasa_backend.database import AasaDatabase
from aasa_backend.handlers import (
    StudyHandler,
    VariableHandler,
    TermHandler,
    KeywordSuggestionHandler,
    StudyTermHandler,
    StudyTermDeleteHandler,
    VariableTermHandler,
    VariableTermDeleteHandler,
    VocabularyHandler,
    InvalidPathHandler,
    StudyBatchHandler,
    StudyTermBatchHandler,
    VariableTermBatchHandler,
    VocabularyUpdateHandler
)

ROOT_LOGGER = logging.getLogger()
LOGGER = logging.getLogger("aasa_backend.server")


def make_app(database, debug=False):
    """ Setup routes and return initialized Tornado web application.

    :returns: Tornado web application.
    :rType: :obj:`tornado.web.Application`
    """
    routes = [
        (r"/studies/?(?P<study_id>[^\/]+)?/?", StudyHandler),
        (r"/studies/(?P<study_id>[^\/]+)/terms/?(?P<custom_method_key>[^\/]+)?/?", StudyTermHandler),
        (r"/studies/?(?P<study_id>[^\/]+)/terms/?(?P<source>[^\/]+)/(?P<term_id>[^\/]+)", StudyTermDeleteHandler),
        (r"/variables/?(?P<variable_id>[^\/]+)?/?", VariableHandler),
        (r"/variables/?(?P<variable_id>[^\/]+)/terms/?(?P<custom_method_key>[^\/]+)?/?", VariableTermHandler),
        (r"/variables/?(?P<variable_id>[^\/]+)/terms/?(?P<source>[^\/]+)/(?P<term_id>[^\/]+)/?",
            VariableTermDeleteHandler),
        (r"/terms/?(?P<term_id>[^\/]+)?", TermHandler),
        (r"/vocabularies/?", VocabularyHandler),
        (r"/batch-update/studies/?", StudyBatchHandler),
        (r"/batch-update/study-terms/(?P<source>[^\/]+)/?", StudyTermBatchHandler),
        (r"/batch-update/variable-terms/(?P<source>[^\/]+)/?", VariableTermBatchHandler),
        (r"/batch-update/vocabularies/(?P<vocabulary_id>[^\/]+)", VocabularyUpdateHandler),
        (r"/(?P<collection_name>[^\/]+)?/?(?P<item_id>[^\/]+)?/finto-suggestions/?", KeywordSuggestionHandler)
    ]
    return Application(
        routes,
        debug=debug,
        db=database,
        default_handler_class=InvalidPathHandler
    )

def parse_args():
    """ Parse arguments from config file or command line.
    """
    no_db_url = '--db_url' not in sys.argv
    parser = configargparse.ArgParser()
    parser.add('-c', '--config-file', is_config_file=True, help='config file path')
    parser.add('--dbms', default='postgresql')
    parser.add('--port', required=no_db_url)
    parser.add('--username', required=no_db_url)
    parser.add('--password', required=no_db_url)
    parser.add('--host', required=no_db_url)
    parser.add('--database', required=no_db_url)
    parser.add('--loglevel', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], default='DEBUG')
    parser.add('--dont-serve-traceback', action='store_true',
        help='Include traceback in HTTP response in case of an error')
    parser.add('--echo', type=bool, default=False, help='Should SQLAlchemy echo generated SQL to stdout?')
    parser.add('--db_url')
    return parser.parse_args()


def configure_logs(loglevel):
    """ Configure loggers.
    """
    # Get available temp directory
    os_temp_dir = tempfile.gettempdir()

    # Create a user specific directory for log files if it doesn't exist
    aasa_log_dir = os.path.join(os_temp_dir, f'aasa_backend_log_{getpass.getuser()}')
    if not os.path.exists(aasa_log_dir):
        os.mkdir(aasa_log_dir)

    log_file = os.path.join(aasa_log_dir, 'aasa_backend.log')

    # Configure handler that saves logs to file
    log_file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=10000, backupCount=10)
    log_file_formatter = logging.Formatter('%(asctime)s %(name)-12s: %(levelname)-8s %(message)s')
    log_file_handler.setLevel(getattr(logging, loglevel))
    log_file_handler.setFormatter(log_file_formatter)

    # Configure handler that prints to console
    log_console = logging.StreamHandler()
    log_console_formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
    log_console.setLevel(logging.INFO)
    log_console.setFormatter(log_console_formatter)

    # Set handlers to root logger
    ROOT_LOGGER.setLevel(getattr(logging, loglevel))
    ROOT_LOGGER.addHandler(log_file_handler)
    ROOT_LOGGER.addHandler(log_console)

    # Silence asyncio info messages
    logging.getLogger("asyncio").setLevel(logging.WARN)

def run_server():
    """ Run Aasa backend service.
    """
    args = parse_args()

    db_url = (
        f'{args.dbms}://{args.username}:{args.password}@{args.host}/{args.database}'
        if not args.db_url else args.db_url)

    configure_logs(args.loglevel)

    try:
        database = AasaDatabase(url=db_url, echo=args.echo)
        serve_traceback = not args.dont_serve_traceback
        app = make_app(database=database, debug=serve_traceback)
        app.listen(args.port)
        print('Server listening at', args.port)
        LOGGER.info('aasa_backend server listening at %s', args.port)
        IOLoop.current().start()
    except KeyboardInterrupt:
        print('Server stopped.')
        LOGGER.info("Exiting aasa_backend")


if __name__ == "__main__":
    run_server()
