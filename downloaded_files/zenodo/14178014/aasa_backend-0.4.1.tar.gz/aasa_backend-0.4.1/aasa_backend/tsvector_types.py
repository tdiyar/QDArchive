from sqlalchemy import func
from sqlalchemy.types import UserDefinedType


class EnglishTSVector(UserDefinedType):
    """English TSVector column"""
    def get_col_spec(self):
        return "TSVECTOR"

    class comparator_factory(UserDefinedType.Comparator):
        """Comparison type for English TSVectors
        """
        def __eq__(self, other):
            return self.op('@@')(func.to_tsquery('pg_catalog.english', other))


class FinnishTSVector(UserDefinedType):
    """Finnish TSVector column"""
    def get_col_spec(self):
        return "TSVECTOR"

    class comparator_factory(UserDefinedType.Comparator):
        """Comparison type for English TSVectors
        """
        def __eq__(self, other):
            return self.op('@@')(func.to_tsquery('pg_catalog.finnish', other))
