"""Module for defining sqlalchemy declarative base classes."""
import datetime
from sqlalchemy import (
    Boolean,
    Column,
    Date,
    ForeignKey,
    Index,
    Integer,
    String,
    PrimaryKeyConstraint,
    UniqueConstraint
    )
from sqlalchemy.orm import (
    relationship,
    synonym
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.associationproxy import association_proxy

from aasa_backend import tsvector_types

Base = declarative_base()
# pylint: disable=too-few-public-methods


class Study(Base):
    """Base class for the table containing study records."""
    __tablename__ = 'study'

    # Unique record id, auto-incrementing by default and creates serial type on postgres
    id = Column(Integer, primary_key=True)

    # Agency level study identifier (DDI element: <IDNo>)
    idno = Column(String, nullable=False)

    # Language id of the study description (DDI element: <codeBook xml:lang>)
    language_id = Column(ForeignKey('language.id'), nullable=False)

    __table_args__ = (
        UniqueConstraint(idno, language_id),
        Index('english_study_idx', 'search_en', postgresql_using='gin'),
        Index('finnish_study_idx', 'search_fi', postgresql_using='gin')
    )

    # Title of the study (DDI element: <titl>)
    title = Column(String, nullable=False)

    # Abstract of the study (DDI element: <abstract>)
    abstract = Column(String, nullable=False)

    # Date and time the study was added to database
    date_added = Column(Date, default=datetime.datetime.utcnow, nullable=False)

    # Date and time the study was last edited
    date_modified = Column(Date)

    # Variables of the study. Needed for cascade on delete.
    variables = relationship('Variable', back_populates='study')

    # Terms linked to the study
    terms = relationship('StudyTerm', lazy='select')

    # Is the study keyworded (ready)?
    keyworded = Column(Boolean, default=False, nullable=False)

    # TSVector for english words
    search_en = Column(tsvector_types.EnglishTSVector)

    # TSVector for finnish words
    search_fi = Column(tsvector_types.FinnishTSVector)

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'id': self.id,
            'idno': self.idno,
            'language_id': self.language_id,
            'title': self.title,
            'abstract': self.abstract,
            'date_added': self.date_added,
            'date_modified': self.date_modified,
            'keyworded': self.keyworded,
            'terms': [term.serialize for term in self.terms]
        }


class Variable(Base):
    """Base class for the table containing variable records."""
    __tablename__ = 'variable'

    # Unique record id, auto-incrementing by default and creates serial type on postgres
    id = Column(Integer, primary_key=True)

    # Study level unique variable name (DDI element: <var name>)
    name = Column(String, nullable=False)

    # Id of the parent study
    study_id = Column(ForeignKey('study.id', ondelete='CASCADE'), nullable=False)

    study = relationship('Study', back_populates='variables')

    __table_args__ = (
        UniqueConstraint(name, study_id),
        Index('english_variable_idx', 'search_en', postgresql_using='gin'),
        Index('finnish_variable_idx', 'search_fi', postgresql_using='gin')
    )

    # Is the variable (QstnLit?) translated? TODO: How to get this info?
    is_translated = Column(Boolean, default=False)

    # Is the question open-ended? TODO: How to get this info?
    is_fielded = Column(Boolean, default=False)

    # The id of a varGrp the variable belongs to, if any. TODO: format: '{study_id}:{varGrp.txt}'?
    varGrp = Column(String, nullable=True)

    # The label of the variable TODO: format: '[{id}] {varGrp.txt} {qstnLit}'?
    labl = Column(String, nullable=False)

    # Pre-question text that provides more information about the question. Can be an empty string.
    preQTxt = Column(String, nullable=False)

    # The variable question text
    qstnLit = Column(String, nullable=False)

    # Text given after the question. Usually a transition to the next question. Can be an empty.
    postQTxt = Column(String, nullable=False)

    # Instructions for the interviewer. Can be an empty string.
    ivuInstr = Column(String, nullable=False)

    # The cluster the variable belongs to
    var_cluster = Column(String, nullable=True)

    # Date and time the variable was added to database TODO: Is this needed?
    date_added = Column(Date, default=datetime.datetime.utcnow, nullable=False)

    # Date and time the variable was last edited TODO: Is this needed?
    date_modified = Column(Date)

    # Notes about the variable
    notes = Column(String, nullable=True)

    # Is the variable keyworded (ready)?
    keyworded = Column(Boolean, default=False, nullable=False)

    # The index of the variable in the DDI
    index = Column(Integer, nullable=False)

    # Terms assigned to the variable
    terms = relationship('VariableTerm', lazy='select')

    # Answer options for multiple choice select one types of questions
    catValues = relationship('CategoryValue', lazy='select')

    # TSVector for english words
    search_en = Column(tsvector_types.EnglishTSVector)

    # TSVector for finnish words
    search_fi = Column(tsvector_types.FinnishTSVector)

    study_idno = association_proxy('study', 'idno')
    language_id = association_proxy('study', 'language_id')
    study_title = association_proxy('study', 'title')

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'id': self.id,
            'name': self.name,
            'study_id': self.study_id,
            'study_idno': self.study.idno,
            'language_id': self.study.language_id,
            'is_translated': self.is_translated,
            'is_fielded': self.is_fielded,
            'varGrp': self.varGrp,
            'labl': self.labl,
            'preQTxt': self.preQTxt,
            'qstnLit': self.qstnLit,
            'postQTxt': self.postQTxt,
            'ivuInstr': self.ivuInstr,
            'var_cluster': self.var_cluster,
            'date_added': self.date_added,
            'date_modified': self.date_modified,
            'notes': self.notes,
            'keyworded': self.keyworded,
            'index': self.index,
            'catValues': [val.serialize for val in self.catValues],
            'terms': [val.serialize for val in self.terms]
        }


class CategoryValue(Base):
    """Base class for the table containing a variable's category value records"""
    __tablename__ = 'category_value'
    variable_id = Column(ForeignKey('variable.id', ondelete="CASCADE"), nullable=False)
    catvalue_index = Column(Integer)
    catValu = Column(String)
    catLabl = Column(String)
    catStat = Column(Integer)
    __table_args__ = (
        PrimaryKeyConstraint(variable_id, catvalue_index),
        {}
    )

    @property
    def serialize(self):
        """Serializes table keys to dict"""
        return {
            'catvalue_index': self.catvalue_index,
            'catValu': self.catValu,
            'catLabl': self.catLabl,
            'catStat': self.catStat
        }


class Language(Base):
    """Base class for the table containing language records."""
    __tablename__ = 'language'

    # Unique language id (ISO-639 two-letter language code)
    id = Column(String(2), primary_key=True)

    # Language name TODO: in English?
    name = Column(String(50), nullable=False, unique=True)

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'id': self.id,
            'name': self.name
        }


class Vocabulary(Base):
    """Base class for the table containing vocabulary records."""
    __tablename__ = 'vocabulary'

    # Vocabulary name (DDI element <keyword:vocab>) is unique,
    # it will be used as the primary key
    vocab = Column(String, primary_key=True)
    id = synonym('vocab')

    # Vocabulary uri (DDI element <keyword:vocabURI>)
    vocabURI = Column(String, unique=True, nullable=False)

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'vocab': self.vocab,
            'vocabURI': self.vocabURI
        }


# A term that belongs to a vocabulary
class Term(Base):
    """Base class for the table containing term records."""
    __tablename__ = 'term'

    # Unique record id, auto-incrementing by default and creates serial type on postgres
    id = Column(Integer, primary_key=True)

    # Vocabulary the term belongs to
    vocab = Column(ForeignKey('vocabulary.vocab', ondelete="CASCADE"), nullable=False)

    # Term language
    language_id = Column(String, ForeignKey('language.id'), nullable=False)

    # The string value of the term
    value = Column(String, nullable=False)

    # Uri of the term, nullable.
    # If no valid uri is available (eg when fetching term data from study ddi description),
    # store value?
    uri = Column(String, nullable=True)

    # True if the term no longer is in the vocabulary
    removed = Column(Boolean, default=False)

    # True if term is in the vocabulary but tagged with "deprecated"
    deprecated = Column(Boolean, default=False)

    vocabulary = relationship("Vocabulary")

    __table_args__ = (
        UniqueConstraint(vocab, language_id, uri),
    )

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'id': self.id,
            'vocab': self.vocab,
            'language_id': self.language_id,
            'value': self.value,
            'uri': self.uri,
            'removed': self.removed,
            'deprecated': self.deprecated
        }


class StudyTerm(Base):
    """Base class for the association table between study and term."""
    __tablename__ = 'study_term'

    # Id of the study the term is linked to
    study_id = Column(ForeignKey('study.id', ondelete="CASCADE"))

    # Id of the term
    term_id = Column(ForeignKey('term.id', ondelete="CASCADE"))

    # Source of the term (i.e user or machine)
    source = Column(String, default='user')

    # Name of the annotator
    annotator_name = Column(String, default='unknown_user')

    term = relationship('Term')

    __table_args__ = (
        PrimaryKeyConstraint(study_id, term_id, source),
    )

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'study_id': self.study_id,
            'source': self.source,
            'annotator_name': self.annotator_name,
            'term': self.term.serialize
        }


class VariableTerm(Base):
    """Base class for the association table between variable and term."""
    __tablename__ = 'variable_term'

    # Id of the variable the term is linked to
    variable_id = Column(ForeignKey('variable.id', ondelete="CASCADE"))

    # Id of the term
    term_id = Column(ForeignKey('term.id', ondelete="CASCADE"))

    # Source of the term (i.e user or machine)
    source = Column(String, default='user')

    # Name of the annotator
    annotator_name = Column(String, default='unknown_user')

    term = relationship('Term')

    __table_args__ = (
        PrimaryKeyConstraint(variable_id, term_id, source),
    )

    @property
    def serialize(self):
        """"Serializes table keys to dict"""
        return {
            'variable_id': self.variable_id,
            'source': self.source,
            'annotator_name': self.annotator_name,
            'term': self.term.serialize
        }
