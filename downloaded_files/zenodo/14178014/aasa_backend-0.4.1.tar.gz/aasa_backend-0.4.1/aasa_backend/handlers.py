"""Module that defines handlers for responding to HTTP-requests."""
import json
import logging
import traceback
from collections import namedtuple

from psycopg2.errors import UniqueViolation
from tornado.web import (
    RequestHandler,
    Finish,
    MissingArgumentError
)
from sqlalchemy import (
    asc,
    desc,
    and_,
    or_
)
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from aasa_backend import models


# Disabling abstract-method warning, not implemented currently.
# pylint: disable=W0223

LOGGER = logging.getLogger(__name__)
ACCEPTED_QUERY_PARAMS = ['sort_by', 'skip', 'limit', 'embed_terms']


def exact_match_filter(table, attr, value_list):
    """Creates filters to compare attribute values precisely, case-sensitive.
    """
    filters = []
    for value in value_list:
        val_or = value.split('|')
        if len(val_or) == 1:
            filters.append(getattr(table, attr) == value)
        else:
            or_filters = [getattr(table, attr) == val for val in val_or]
            filters.append(or_(*or_filters))
    return filters


def ilike_filter(table, attr, value_list):
    """Creates filters to compare attribute values with a pattern, case-insensitive.
    """
    filters = []
    for value in value_list:
        val_or = value.split('|')
        if len(val_or) == 1:
            filters.append(getattr(table, attr).ilike(value))
        else:
            or_filters = [getattr(table, attr).ilike(val) for val in val_or]
            filters.append(or_(*or_filters))
    return filters


class BaseHandler(RequestHandler):
    """Base request handler. Provides methods for subclasses.
    """
    def initialize(self):
        """Extends tornado.web.Requesthandler method initialize"""
        self.database = self.application.settings['db']

    def prepare(self):
        """Prepare for each request. Set output content type.
        """
        self.set_header('Content-Type', 'application/json; charset=UTF-8')

    def assert_body_not_empty(self):
        """Assert that request body contains data.
        """
        if not self.request.body:
            msg = 'Empty request body'
            self._send_error(400, msg)

    def assert_request_content_type_json(self):
        """Assert that request content type is application/json.
        """
        req_ct = self.request.headers.get('Content-Type')
        if req_ct != 'application/json':
            msg = f'Unexpected request content type ({req_ct})'
            self._send_error(415, msg)

    def get_filters(self):
        """Return a list of sqlalchemy binary expressions for filtering the database query.
        """
        # pylint: disable=no-member
        filters = []
        for attr in self.request.arguments.keys():
            if attr in self.accepted_filters:
                values = [val.replace(' ', '+') for val in self.get_arguments(attr)]\
                     if attr in ['search_en', 'search_fi'] else self.get_arguments(attr)
                filter_func = self.accepted_filters[attr]
                filters.extend(filter_func(self.table, attr, values))

            elif attr not in ACCEPTED_QUERY_PARAMS:
                msg = f'Unaccepted filter parameter: {attr}'
                self._send_error(400, msg)

        return filters
        # pylint: enable=no-member

    def get_sort_arguments(self):
        """Return a list of sqlalchemy unary expressions for sorting the database query.
        """
        # pylint: disable=no-member
        sorts = []
        if len(self.get_query_arguments('sort_by')) == 0:
            sorts.append(asc(getattr(self.table, 'id')))
        for sort_arg in self.get_query_arguments('sort_by'):
            # if the sort argument contains a hyphen, split the value in two:
            # the name of the attribute to sort by and the sort order.
            if '-' in sort_arg:
                sort_by, sort_order = sort_arg.split('-')
            else:
                sort_by = sort_arg
                sort_order = 'asc'

            # Send 400 error if the sort argument is not accepted
            if sort_by not in self.accepted_sorts:
                msg = f'Unaccepted sort parameter: {sort_arg}'
                self._send_error(400, msg)

            if self.table == models.Variable and sort_by == 'study_idno':
                column = models.Study.idno
            else:
                column = getattr(self.table, sort_by)
            sort_func = desc(column) if sort_order == 'desc' else asc(column)
            sorts.append(sort_func)
        return sorts
        # pylint: enable=no-member


    def parse_query_args(self):
        """Get the arguments for the database query from the request.
        """
        try:
            # Store the args in a named tuple for easy access
            query_args = namedtuple('query_args', 'filters, skip, sort_by, limit')

            # Collect the arg values from the query
            query_filters = self.get_filters()
            skip = int(self.get_query_argument('skip', 0))
            sorts = self.get_sort_arguments()
            limit = int(self.get_query_argument('limit', 9007199254740991))

            # Return the named tuple with collected values
            return query_args(query_filters, skip, sorts, limit)
        except ValueError as exc:
            raise SQLAlchemyError(exc) from exc

    def parse_and_query(self):
        """Call the database query for all items with the filters in self.args.
        """
        # pylint: disable=no-member
        try:
            # Get embed_terms parameter from the query, False if not found
            embed_terms_value = self.get_query_argument('embed_terms', None)

            if embed_terms_value:
                # If embed_terms param found, send 400 error if table is not study or variable
                if self.table not in (models.Variable, models.Study):
                    self._send_error(400, 'Unaccepted filter parameter: embed_terms')

                # Send 400 error if the value of embed_terms_value not 'true' or 'false'
                if embed_terms_value.lower() not in ('true', 'false', None):
                    msg = f'Unaccepted value for parameter embed_terms: {embed_terms_value}'
                    self._send_error(400, msg)

                embed_terms_value = embed_terms_value == 'true'

            query_args = self.parse_query_args()
            result = self.database.query(self.table, query_args, embed_terms_value in (True, None))
            self._write_and_flush(result)

        except SQLAlchemyError as err:
            LOGGER.error(err)
            # If the error is related to db integrity (e.g. unique violations), send 409
            if isinstance(err, IntegrityError):
                self._send_error(409)
            # Send 400 in other cases of db related errors
            self._send_error(400)
        # pylint: enable=no-member

    def query_by_id(self, obj_id):
        """Query a single record by id.
        :param: obj_id: The id of the object
        :type obj_id: int
        """
        # pylint: disable=no-member
        # Sends 404 if obj_id is not integer (not allowed)
        try:
            int(obj_id)
        except ValueError as exp:
            LOGGER.warning(exp)
            self._send_error(404)
        result = self.database.query_one(self.table, obj_id)
        if not result:
            self._send_error(404)
        self._write_and_flush(result)
        raise Finish()
        # pylint: enable=no-member

    def delete_objects(self, obj_id=None):
        """Delete all records in a table or a single record by id.
        :param: obj_id: The id of the object
        """
        # pylint: disable=no-member
        result = self.database.delete(self.table, obj_id)
        if not result and obj_id:
            self._send_error(404)
        self.set_status(204)
        raise Finish()
        # pylint: enable=no-member

    def patch_keyworded(self, obj_id):
        """HTTP-PATCH endpoint.
        Update the keyworded property for a single entry.
        :param: obj_id: The id of the object
        """
        # Object id required
        if not obj_id:
            self._send_error(405, 'Method not allowed')
        self.assert_body_not_empty()
        self.assert_request_content_type_json()

        request_body = json.loads(self.request.body.decode('utf-8'))
        # Allow update only for keyworded property
        if 'keyworded' not in request_body.keys():
            self._send_error(400, 'Missing keyworded attribute')
        if len(request_body.keys()) > 1:
            LOGGER.warning('Allow update only for keyworded property')
            self._send_error(400)
        try:
            # pylint: disable=no-member
            result = self.database.update_property(
                self.table, obj_id, 'keyworded', request_body['keyworded'])
            # pylint: enable=no-member
            if not result:
                self._send_error(404)
            self._write_and_flush(result)
        except SQLAlchemyError as err:
            LOGGER.error(err)
            self._send_error(400)

    def create_term_relation(self, table, parent_table, parent_id, custom_method_key):
        """Creates an entry in the study_terms or variable_terms table.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()

        term_obj = json.loads(self.request.body.decode('utf-8'))
        try:
            result = self.database.create_term_relation(
                table, parent_table, parent_id, term_obj, custom_method_key
            )
            if not result:
                self._send_error(404)
            # Set headers and write the result
            json_result = json.dumps(result, default=str, ensure_ascii=False)
            self.set_status(201)
            self.write(json_result)
            self.flush()
        except SQLAlchemyError as err:
            LOGGER.error(err)

            if isinstance(err, IntegrityError):
                # pylint: disable=no-member
                # If integrityerror is caused by unique restriction violation, send 403
                if isinstance(err.orig, UniqueViolation):
                    self._send_error(403, 'Duplicate')
                # pylint: enable=no-member

                # If the error is related to db integrity in another way, send 409
                self._send_error(409)
            # Send 400 in other cases of db related errors
            self._send_error(400)

    def create_one(self, url):
        """Add the object in the request body to the database.
        :param: url: The endpoint where the new object can be found
        :type url: str
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()
        # Parse json request body to dict and replace dashes with underscores in keys
        req_body = json.loads(self.request.body.decode('utf-8'))
        try:
            # pylint: disable=no-member
            result = self.database.create_one(self.table, req_body)
            # pylint: enable=no-member

            # Set headers and write the result
            json_result = json.dumps(result, default=str, ensure_ascii=False)
            self.set_status(201)
            self.set_header('Location', f'{url}{result["id"]}')
            self.write(json_result)
            self.flush()
        except SQLAlchemyError as err:
            LOGGER.error(err)
            # If the error is related to db integrity (e.g. unique violations), send 409
            if isinstance(err, IntegrityError):
                self._send_error(409)
            # Send 400 in other cases of db related errors
            self._send_error(400)

    def write_error(self, status_code, **kwargs):
        """Overwrites the default tornado.web.RequestHandler method write_error.
        All uncaught errors will be handled here.
        The default tornado.web.RequestHandler.log_exception method is used
        for logging the exception. The log_exception method can be overwritten if needed.
        """
        # If --serve-traceback argument is given at server start, include traceback in the response.
        if self.settings.get('serve_traceback') and 'exc_info' in kwargs:
            self.set_header("Content-Type", "text/plain")
            for line in traceback.format_exception(*kwargs['exc_info']):
                self.write(line)
            self.finish()
        else:
            self.finish({
                'code': status_code,
                'message': self._reason
            })

    def _send_error(self, status_code=500, msg=None):
        """ Send error status code with a custom message and finish.
        """
        if not msg:
            self.send_error(status_code)
        LOGGER.warning('%s error: %s', status_code, msg)
        self.set_status(status_code)
        raise Finish({
            'code': status_code,
            'message': msg
            })

    def _write_and_flush(self, result, error_code=None, error_msg=None):
        """Send error if error_code is provided.
        Else serialize result to a JSON formatted string.
        Write the JSON chunk to the output buffer.
        """
        if error_code:
            self._send_error(status_code=error_code, msg=error_msg)
        else:
            json_chunk = json.dumps(result, default=str, ensure_ascii=False)
            self.write(json_chunk)
            self.finish()

    def query_multiple_by_individual_filters(self):
        """Query items one by one with the individual filters in the request body.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()
        req_body = json.loads(self.request.body.decode('utf-8')) # Should be a list
        filter_lists = []
        # pylint: disable=no-member
        try:
            for obj in req_body:
                single_obj_filter = []
                for key, val in obj.items():
                    if not hasattr(self.table, key):
                        self._send_error(400, f'Invalid object in request: {obj}')
                    single_obj_filter.append(getattr(self.table, key) == val)
                filter_lists.append(single_obj_filter)
            result = self.database.query_multiple_by_individual_filters(self.table, filter_lists)
            self._write_and_flush(result)
        # pylint: enable=no-member
        except SQLAlchemyError as err:
            LOGGER.error(err)
            # If the error is related to db integrity (e.g. unique violations), send 409
            if isinstance(err, IntegrityError):
                self._send_error(409)
            # Send 400 in other cases of db related errors
            self._send_error(400)


def studyterm_filter(table, _attr, values):
    """Creates a filter that compares study items by the id of the terms associated to the studies.
    """
    filters = []
    for value in values:
        filters.append(
            getattr(table, 'terms')\
                .any(
                    and_(models.StudyTerm.term_id == value,
                        or_(models.StudyTerm.source == 'user', models.StudyTerm.source == 'DDI'))
            ))
    return filters


def studyterm_ilike_filter(table, attr, values):
    """Creates a filter that compare study items by the value of the terms associated to the studies.
    """
    filters = []
    for value in values:
        filters.append(
            getattr(table, 'terms')\
                .any(
                    and_(models.StudyTerm.term.has(getattr(models.Term, attr).ilike(value)),
                        or_(models.StudyTerm.source == 'user', models.StudyTerm.source == 'DDI'))
            ))
    return filters


def variableterm_filter(table, _attr, values):
    """Creates a filter that compares variable items by the id of the terms associated to the variables.
    """
    filters = []
    for value in values:
        filters.append(
            getattr(table, 'terms')\
                .any(and_(models.VariableTerm.term_id == value,
                    or_(models.VariableTerm.source == 'user', models.VariableTerm.source == 'DDI'))
            ))
    return filters


def variableterm_ilike_filter(table, attr, values):
    """Creates a filter that compares variable items by the value of the terms associated to the variables.
    """
    filters = []
    for value in values:
        filters.append(
            getattr(table, 'terms')\
                .any(
                    and_(models.VariableTerm.term.has(getattr(models.Term, attr).ilike(value)),
                        or_(models.VariableTerm.source == 'user', models.VariableTerm.source == 'DDI')
                    )
            ))
    return filters


class StudyHandler(BaseHandler):
    """Handle requests to /studies."""
    table = models.Study
    accepted_filters = {'id': exact_match_filter,
                        'idno': ilike_filter,
                        'title': ilike_filter,
                        'language_id': exact_match_filter,
                        'search_fi': exact_match_filter,
                        'search_en': exact_match_filter,
                        'abstract': ilike_filter,
                        'terms_include': studyterm_filter,
                        'terms_value_include': lambda x, y, z: \
                            studyterm_ilike_filter(models.Study, 'value', z),
                        'terms_uri_include': lambda x, y, z: \
                            studyterm_ilike_filter(models.Study, 'uri', [f'%{i}%' for i in z]),
                        'keyworded': exact_match_filter}

    accepted_sorts = ['idno', 'title', 'language_id', 'abstract', 'date_added', 'date_modified']

    def get(self, study_id):
        """HTTP-GET endpoint.
        Respond with a single or multiple study records, depending
        on the request arguments.
        """
        # If study_id in path, return single object, raises Finish
        if study_id:
            self.query_by_id(study_id)

        self.parse_and_query()

    def post(self, study_id):
        """HTTP-POST endpoint.
        Add the object in the request body to database.
        """
        # Handle study_id attribute as a trigger for pick action
        if study_id == 'pick':
            self.query_multiple_by_individual_filters()
        else:
            self.create_one('/studies/')

    def delete(self, study_id):
        """HTTP-DELETE endpoint.
        Delete all studies that match the query parameters."""
        self.delete_objects(study_id)

    def patch(self, study_id):
        """HTTP-PATCH endpoint.
        Update the keyworded property for a single study.
        """
        self.patch_keyworded(study_id)


class VariableHandler(BaseHandler):
    """Handle requests to /variables"""
    table = models.Variable
    accepted_filters = {'id': exact_match_filter,
                        'name': ilike_filter,
                        'study_id': exact_match_filter,
                        'language_id': exact_match_filter,
                        'study_idno': ilike_filter,
                        'study_title': ilike_filter,
                        'search_fi': exact_match_filter,
                        'search_en': exact_match_filter,
                        'is_translated': exact_match_filter,
                        'is_fielded': exact_match_filter,
                        'varGrp': ilike_filter,
                        'labl': ilike_filter,
                        'preQTxt': ilike_filter,
                        'qstnLit': ilike_filter,
                        'postQTxt': ilike_filter,
                        'ivuInstr': ilike_filter,
                        'notes': ilike_filter,
                        'var_cluster': exact_match_filter,
                        'catLabl': lambda x, y, z: \
                            [models.Variable.catValues.any(models.CategoryValue.catLabl.ilike(z[0]))],
                        'terms_include': variableterm_filter,
                        'terms_value_include': lambda x, y, z: \
                            variableterm_ilike_filter(models.Variable, 'value', z),
                        'terms_uri_include': lambda x, y, z: \
                            variableterm_ilike_filter(models.Variable, 'uri', [f'%{i}%' for i in z]),
                        'keyworded': exact_match_filter,
                        'index': exact_match_filter}

    accepted_sorts = ['id', 'name', 'study_idno', 'varGrp', 'labl', 'preQTxt', 'qstnLit',
        'postQTxt', 'ivuInstr', 'date_added', 'date_modified', 'index']


    def get(self, variable_id):
        """HTTP-GET endpoint.
        Respond with a single or multiple variable records, depending
        on the request arguments.
        """
        # If variable_id in path, return single object, raises Finish
        if variable_id:
            self.query_by_id(variable_id)

        self.parse_and_query()

    def post(self, variable_id):
        """HTTP-POST endpoint.
        Add the object in the request body to database.
        """
        # Handle variable_id attribute as a trigger for pick action
        if variable_id == 'pick':
            self.query_multiple_by_individual_filters()
        else:
            self.create_one('/variables/')

    def delete(self, variable_id):
        """HTTP-DELETE endpoint.
        Delete all variables that match the query parameters."""
        self.delete_objects(variable_id)

    def patch(self, variable_id):
        """HTTP-PATCH endpoint.
        Update the keyworded property for a single variable.
        """
        self.patch_keyworded(variable_id)


class TermHandler(BaseHandler):
    """Handle requests to /terms"""
    table = models.Term
    accepted_filters = {
        'id': exact_match_filter,
        'vocab': ilike_filter,
        'language_id': exact_match_filter,
        'removed': exact_match_filter,
        'deprecated': exact_match_filter,
        'value': ilike_filter,
        'uri': lambda x, y, z: [models.Term.uri.ilike(f'%{i}%') for i in z]
    }

    accepted_sorts = ['id', 'value', 'vocab', 'language_id']

    def get(self, term_id):
        """HTTP-GET endpoint.
        Respond with a single or multiple term records, depending
        on the request arguments.
        """
        # If term_id in path, return single object, raises Finish
        if term_id:
            self.query_by_id(term_id)

        self.parse_and_query()

# pylint: disable=W0613
    def post(self, term_id):
        """"HTTP-POST endpoint.
        Create new term from data submitted in request body.
        """
        self.create_one('/terms/')
# pylint: enable=W0223

    def delete(self, term_id):
        """HTTP-DELETE endpoint.
        Delete all terms that match the query parameters."""
        self.delete_objects(term_id)


class VariableTermHandler(BaseHandler):
    """Handle requests to /variable_terms."""
    def post(self, variable_id, custom_method_key):
        """"HTTP-POST endpoint.
        Create new variable term from data submitted in request body.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()
        if not variable_id or custom_method_key not in (None, 'custom', 'finto-ai'):
            self._send_error(400)
        self.create_term_relation(models.VariableTerm, models.Variable, variable_id, custom_method_key)

class VariableTermDeleteHandler(BaseHandler):
    """Handle Delete requests to /variables/{variable_id}/terms/{source}/{term_id}."""
    def delete(self, variable_id, source, term_id):
        """"HTTP-DELETE endpoint.
        Delete a single variable term.
        """
        if not (variable_id and source and term_id):
            self._send_error(400)
        filters = [
            and_(
                models.VariableTerm.variable_id == variable_id,
                models.VariableTerm.source == source,
                models.VariableTerm.term_id == term_id)
            ]

        result = self.database.delete_term_relation(models.VariableTerm, filters)
        if not result:
            self._send_error(404)
        self.set_status(204)
        raise Finish()

class StudyTermHandler(BaseHandler):
    """Handle POST requests to /studies/{study_id}/terms."""
    def post(self, study_id, custom_method_key):
        """"HTTP-POST endpoint.
        Create new study term from data submitted in request body.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()
        if not study_id or custom_method_key not in (None, 'custom', 'finto-ai'):
            self._send_error(400)
        self.create_term_relation(models.StudyTerm, models.Study, study_id, custom_method_key)

class StudyTermDeleteHandler(BaseHandler):
    """Handle Delete requests to /studies/{study_id}/terms/{source}/{term_id}."""
    def delete(self, study_id, source, term_id):
        """"HTTP-DELETE endpoint.
        Delete a single study term.
        """
        if not (study_id and source and term_id):
            self._send_error(400)
        filters = [
            and_(
                models.StudyTerm.study_id == study_id,
                models.StudyTerm.source == source,
                models.StudyTerm.term_id == term_id)
            ]

        result = self.database.delete_term_relation(models.StudyTerm, filters)
        if not result:
            self._send_error(404)
        self.set_status(204)
        raise Finish()


class VocabularyHandler(BaseHandler):
    """Handle requests to /vocabularies."""
    table = models.Vocabulary
    accepted_filters = {'vocab': ilike_filter, 'id': exact_match_filter}
    accepted_sorts = ['vocab']

    def get(self):
        """HTTP-GET endpoint.
        Respond with a list of vocabulary records.
        """
        self.parse_and_query()

    def post(self):
        """HTTP-POST endpoint.
        Create a new vocabulary from data submitted in request body.
        """
        self.create_one('/vocabularies/?id=')

    def delete(self):
        """HTTP-DELETE endpoint.
        Delete all vocabulary entries that match the query parameters.
        """
        # Catch missing argument error to avoid accidentally deleting all (require vocab)
        try:
            voc_id = self.get_argument('vocab')
        except MissingArgumentError:
            LOGGER.error('Missing required arg: vocab')
            self._send_error(400)
        self.delete_objects(voc_id)

class KeywordSuggestionHandler(BaseHandler):
    """Handle requests to /studies/{id}/finto-suggestions and
    /variables/{id}/finto-suggestions.
    """
    def get(self, collection_name, item_id):
        """HTTP-GET endpoint.
        """
        if collection_name not in ('studies', 'variables') or not item_id:
            self._send_error(404, 'Invalid resource path.')
        try:
            item_id = int(item_id)
            self.database.get_finto_suggestions(collection_name, item_id, self._write_and_flush)
        except ValueError:
            self._send_error(404)

class StudyBatchHandler(BaseHandler):
    """Handle requests to /batch-update/studies"""

    def post(self):
        """HTTP-POST endpoint.
        Create or update study entries.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()

        study_objects = json.loads(self.request.body.decode('utf-8'))
        self.database.batch_create_or_update_studies(study_objects, self._write_and_flush)


class StudyTermBatchHandler(BaseHandler):
    """Handle requests to /batch-update/study-terms/{source}"""

    def post(self, source):
        """HTTP-POST endpoint.
        Create or update study entries.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()

        objects = json.loads(self.request.body.decode('utf-8'))
        self.database.batch_create_or_update_study_terms(objects, source, self._write_and_flush)


class VariableTermBatchHandler(BaseHandler):
    """Handle requests to /batch-update/variable-terms/{source}"""

    def post(self, source):
        """HTTP-POST endpoint.
        Create or update study entries.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()

        objects = json.loads(self.request.body.decode('utf-8'))
        self.database.batch_create_or_update_variable_terms(objects, source, self._write_and_flush)


class VocabularyUpdateHandler(BaseHandler):
    """Handle requests to /batch-update/vocabularies/{id}"""

    def post(self, vocabulary_id):
        """HTTP-POST endpoint.
        Create or update study entries.
        """
        self.assert_body_not_empty()
        self.assert_request_content_type_json()

        req_body = json.loads(self.request.body.decode('utf-8'))

        self.database.create_or_update_vocabulary_terms(req_body, vocabulary_id, self._write_and_flush)

class InvalidPathHandler(BaseHandler):
    """Handle requests to invalid paths.
    """
    def prepare(self):
        self._send_error(404, 'Invalid resource path.')
