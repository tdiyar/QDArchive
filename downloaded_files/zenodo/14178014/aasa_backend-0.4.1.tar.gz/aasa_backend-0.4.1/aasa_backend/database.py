"""Database module that provides access to PostgreSQL database."""
from contextlib import ExitStack, contextmanager
import logging
from typing import Iterator

import requests
from sqlalchemy import (
    create_engine,
    or_
)
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm.session import Session
from sqlalchemy.orm import (
    noload,
    sessionmaker
)
from aasa_backend import models


LOGGER = logging.getLogger(__name__)

class InvalidAttributeError(Exception):
    """Error raised when attributes not in the table are found or
    non-nullable attributes are missing
    """


def assert_valid_attributes(model, obj):
    """Check that the model has attributes that match the obj keys.
    """
    for attr in obj.keys():
        if not hasattr(model, attr):
            raise InvalidAttributeError(f'Invalid attribute for {model.__name__}: {attr}')


def get_variable_text(variable):
    """Get values from a variable instance and combine and return them as a single string.
    """
    # Get catvalue texts and labels from variable's category values
    catvalue_texts = [f'{cv.catValu} {cv.catLabl}' for cv in variable.catValues]
    # Append catvalue texts with variable catGrp text and qstnLit and remove None values
    return (
        f'{variable.varGrp} {variable.qstnLit} {" ".join(catvalue_texts)}'.replace('None', '')
    )


class AasaDatabase:
    """A class for accessing the database.
    """
    def __init__(self, url, echo=False):
        self.url = url
        self.engine = create_engine(self.url, echo=echo)
        self.metadata = models.Base.metadata

    def query_one(self, table, obj_id, delete=False):
        """Query a single record by id. Use with delete parameter to delete the object
        :param: table: The SqlAlchemy model of the table to query.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: obj_id: The id of the object
        :param: delete: If true, deletes the object if found.
        :type delete: bool
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            query = session.query(table).filter(getattr(table, 'id') == obj_id)
            result = query.one_or_none()
            if delete:
                query.delete()
            return None if not result else result.serialize

    def delete(self, table, obj_id=None):
        """Delete all records in a table or a single record by id.
        :param: table: The SqlAlchemy model of the table to query.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: obj_id: The id of the object
        """
        if obj_id:
            return self.query_one(table, obj_id, True)
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            session.query(table).delete()
            return None

    def query(self, table, query_args, embed_terms=True):
        """Query multiple database records with query condition parameters and callback.
        :param: table: The SqlAlchemy model of the table to query.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: query_args: A collection of query args including filters, sort_by, limit and skip.
        :type query_args: namedtuple
        :param: noload_terms: Noload options for study_terms
        :type noload_terms: list
        :param: embed_terms: True if should include terms related to each result (study and variable tables only)
        :type embed_terms: bool
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())

            noload_terms = [noload(getattr(table, 'terms'))] if not embed_terms else []

            # Include count in the response if table is study, term or variable
            include_count = table in [models.Term, models.Study, models.Variable]
            count = session.query(table).filter(*query_args.filters).count() if include_count else 0

            # Handle variables separately because of the join to parent study
            if table == models.Variable:
                query = (
                    session.query(models.Variable).
                    join(models.Variable.study).
                    options(*noload_terms).
                    filter(*query_args.filters).
                    order_by(*query_args.sort_by).
                    limit(query_args.limit).
                    offset(query_args.skip)
            )
            else:
                query = (
                    session.query(table).
                    options(*noload_terms).
                    filter(*query_args.filters).
                    order_by(*query_args.sort_by).
                    limit(query_args.limit).
                    offset(query_args.skip)
                )
            # Prevent serializing a large amount of data
            if count > 10000 and query_args.limit > 10000:
                return {'count': count, 'data': []}
            data = []
            for obj in query.all():
                serialized_object = obj.serialize if hasattr(obj, 'serialize') else obj
                if not embed_terms:
                    serialized_object.pop('terms')
                data.append(serialized_object)
            result = {'count': count, 'data': data} if include_count else data
            return result

    def query_multiple_by_individual_filters(self, table, filter_lists):
        """Query a batch of items one by one by individual filters.
        :param: table: The SqlAlchemy model of the table to query.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: filter_lists: List of lists of BinaryExpressions to filter the result by
        :type filter_lists: list
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            results = []
            for filters in filter_lists:
                query = session\
                    .query(table)\
                    .filter(*filters)
                result = query.one_or_none()
                if result:
                    results.append(result.serialize)
            return results

    def get_finto_suggestions(self, collection_name, item_id, write_and_flush):
        """Fetch keyword suggestions for a study or a variable from fintoAI API.
        :param: collection_name: The name of the collection (study or variable)
        :type collection_name: str
        :param: item_id: The id of the item to fetch the keyword suggestions for
        :type item_id: int
        :param: write_and_flush: The function to call on finish
        :type table: func
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            table = models.Variable if collection_name == 'variables' else models.Study

            # Query the item to get the keyword suggestions for
            target = session.query(table).filter_by(id=item_id).one_or_none()

            # Return and send 404 if not found
            if not target:
                write_and_flush([], 404)

            text = ''
            language_id = ''

            if collection_name == 'studies':
                # Query all variables of the study
                study_variables = session\
                    .query(models.Variable)\
                    .filter(models.Variable.study == target)\
                    .all()

                # Collect relevant text from the study's variables
                variable_texts = [get_variable_text(var) for var in study_variables]

                # Concat study title, study abstract and the text obtained from variables
                text = f'{target.title} {target.abstract} {" ".join(variable_texts)}'
                language_id = target.language_id

            else:
                text = get_variable_text(target)
                language_id = target.study.language_id
            # Get keyword suggestions from finto for the specified text
            response = requests.post(
                f'https://ai.finto.fi/v1/projects/yso-{language_id}/suggest',
                data={'text': text, 'view': 20 if collection_name == 'studies' else 10}
            )
            if response.ok:
                write_and_flush(response.json()['results'])
            else:
                write_and_flush([], 500, 'Fetching keyword suggestions from Finto fails')

    def create_one(self, table, obj_dict):
        """Adds a new object to database.
        :param: table: The SqlAlchemy model of the table to add to.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: obj_dict: The description of the object to add to the database.
        :type obj_dict: dict
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            cat_values = [] if table != models.Variable else obj_dict.pop('catValues')
            try:
                # Constructs an SQLAlchemy model object
                new_instance = table(**obj_dict)
                # Places the object in the session and flushes
                session.add(new_instance)
                session.flush()
                if table == models.Variable:
                    cat_values = [dict(item, **{'variable_id': new_instance.id}) for item in cat_values]
                    for cat_val in cat_values:
                        new_cat_val = models.CategoryValue(**cat_val)
                        session.add(new_cat_val)
            except TypeError as err:
                raise SQLAlchemyError(err) from err

            return {'id': new_instance.id}

    def update_property(self, table, obj_id, property_, new_value):
        """Find an object in a table by id and update the value of a property.
        :param: table: The SqlAlchemy model of the table to query.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: obj_id: The id of the object
        :param: property_: The name of the property to update
        :type property_: string
        :param: new_value: The new value to set for the property
        :type new_value: string
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            result = session.query(table).filter(getattr(table, 'id') == obj_id).one_or_none()
            if not result:
                return None
            setattr(result, property_, new_value)
            session.flush()
            return result.serialize

    def create_term_relation(self, table, parent_table, parent_id, term_relation, custom_method_key):
        """Adds a new term relation to database.
        :param: table: The SqlAlchemy model class of the relation table. (StudyTerm or VariableTerm)
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: parent_table: The SQLAlchemy model class of the parent table. (Study or Variable)
        :type parent_table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: parent_id: Id of the parent record
        :type parent_id: int
        :param: term_relation: The description of the term relation to add to the database.
        :type term_relation: dict
        :param: custom_method_key: Indicates which custom method to perform
        :type custom_method_key: str
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())

            parent = session.query(parent_table).get(parent_id)
            if not parent:
                return None
            try:
                # When using a custom method, the term needs to be queried from database
                if custom_method_key:
                    # Get the language of the term from the language of the parent
                    language_id = parent.language_id if hasattr(parent, 'language_id') else parent.study.language_id
                    vocab = 'YSO' if custom_method_key == 'finto-ai' else 'Custom'
                    custom_filter = None

                    # Set the identifying filter according to the custom method
                    if custom_method_key == 'finto-ai':
                        # Raise error if term uri not in req body
                        term_uri = term_relation.pop('uri', None)
                        if not term_uri:
                            raise SQLAlchemyError('missing term uri')
                        custom_filter = models.Term.uri == term_uri
                    else:
                        # Raise error if term value not in req body
                        term_value = term_relation.pop('value', None)
                        if not term_value:
                            raise SQLAlchemyError('missing term value')
                        custom_filter = models.Term.value == term_value

                    # Query by custom filter
                    term = session.query(models.Term)\
                        .filter(models.Term.vocab == vocab)\
                        .filter(models.Term.language_id == language_id)\
                        .filter(custom_filter)\
                        .one_or_none()
                    if not term:
                        # Sends 404 if term not found with uri and custom_method_key is 'finto-ai'
                        if custom_method_key == 'finto-ai':
                            return None
                        # Constructs a new Term model if term not found with value and custom_method_key is 'custom'
                        term = models.Term(vocab='Custom', value=term_value, language_id=language_id)
                        session.add(term)
                        session.flush()
                term_id = term.id if custom_method_key else term_relation['term_id']
                new_term_relation = \
                    table(
                        term_id=term_id,
                        # Default source to user if not specified
                        source=term_relation.get('source', 'user'),
                        # Default annotator_name to unknown_user if not specified
                        annotator_name=term_relation.get('annotator_name', 'unknown_user')
                    )
                parent.terms.append(new_term_relation)

            except TypeError as err:
                raise SQLAlchemyError(err) from err

            session.commit()
            return new_term_relation.serialize

    def delete_term_relation(self, table, filters):
        """Delete an item from study_term or variable_term table.
        :param: table: The SqlAlchemy model of the table to query.
        :type table: :obj:`sqlalchemy.ext.declarative.api.DeclarativeMeta`
        :param: filters: List of BinaryExpressions to filter the result by
        :type filters: list
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())

            query = session.query(table).filter(*filters)
            if not query.one_or_none():
                return False
            query.delete()
            return True

    def find_term_records_for_batch_op(self, term_descriptions, session):
        """Queries terms matching the identifiers in term_descriptions
        """
        # Expect term in terms to contain at least vocabulary_id, language_id, and value
        term_records = []

        # Collect as much information as possible from the term entries.
        # Term details in the DDI may lack information to unambiguously
        # identify them in the vocabulary.
        for term_d in term_descriptions:
            vocab = term_d.get('vocab', None)
            lang = term_d.get('language_id', None)
            value = term_d.get('value', None)

            # Raise exception if not enough information is provided for the term
            if not (vocab and lang and value):
                raise InvalidAttributeError(
                    'Missing one or more required attributes for term: '\
                    'vocab, language_id, value'
                    )

            term_value_filter = (
                getattr(models.Term, 'value').ilike(value.lower())
                if vocab == 'ELSST' else
                getattr(models.Term, 'value') == value
            )
            # Find if the term already exists in database
            matching_terms = session.query(models.Term)\
                .filter(getattr(models.Term, 'vocab') == vocab)\
                .filter(term_value_filter)\
                .filter(getattr(models.Term, 'language_id') == lang)\
                .all()

            # If only one found, create a relationship to the model
            if len(matching_terms) == 1:
                term_records.append(matching_terms[0])

            # If term not found, create the term and tag as removed
            elif len(matching_terms) == 0:
                new_term = models.Term(
                    vocab=vocab, value=value, language_id=lang, removed=True
                )
                session.add(new_term)
                session.flush()
                term_records.append(new_term)

            # If multiple terms found, pick the most suitable
            else:
                best_match = None
                for term in matching_terms:
                    # Best candidate not deprecated or removed
                    if not (term.deprecated or term.removed):
                        best_match = term
                        break
                    # Next best candidate deprecated and not removed
                    if not term.removed:
                        best_match = term
                    elif not best_match:
                        best_match = term
                term_records.append(best_match)
        return term_records

    def create_or_update_vocabulary_terms(self, terms, vocabulary_id, write_and_flush):
        """Processes a batch of objects with term information.
        Creates new terms or updates existing ones and returns
        information about the performed actions.
        """
        # term in terms must contain at least uri, language_id and value
        # May additionally contain deprecated
        # Used for creating or updating terms from vocabulary api.
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            res_body = {'created': [], 'modified': [], 'failed': []}

            # Find vocabulary by id
            vocabulary = session.query(models.Vocabulary)\
                .filter(models.Vocabulary.vocab == vocabulary_id)\
                .one_or_none()

            # Write error if vocabulary not found
            if not vocabulary:
                write_and_flush([], 404, f'No vocabulary found for id {vocabulary_id}')

            for term in terms:
                term_uri = term.get('uri', None)
                term_lang = term.get('language_id', None)
                term_val = term.get('value', None)

                # Write error if term has no uri, language_id or value
                if not (term_uri and term_lang and term_val):
                    res_body['failed'].append(
                        {'req_object': term,
                        'reason': 'Missing one or more required attributes: uri, language_id, value'})
                    continue

                # Find terms in the vocabulary by uri and language_id.
                # There should be no null values for uri in terms that
                # belong to a vocabulary that is updated via this endpoint.
                # Term uri and language id should not be changed.
                term_query = session.query(models.Term)\
                    .filter(models.Term.vocabulary == vocabulary)\
                    .filter(models.Term.uri == term_uri)\
                    .filter(models.Term.language_id == term_lang)\
                    .filter(models.Term.uri.isnot(None))

                # If term not found, create a new term instance
                if len(term_query.all()) == 0:
                    new_term = models.Term(**term, vocabulary=vocabulary)
                    session.add(new_term)
                    session.flush()
                    res_body['created'].append({'id': new_term.id})

                # Else should only find one term, update it
                else:
                    # Keep track of changed attributes
                    upd = {}
                    for attr, value in term.items():
                        if getattr(term_query.one(), attr) != value:
                            upd[attr] = value
                    # Update all changed attributes. If the same uri-language_id
                    # combination is in terms multiple times, only the latest update
                    # will be reported. For the vocabulary update use case, it is expected
                    # that the same term instance would not be included in the request
                    # body multiple times.
                    if len(upd) > 0:
                        term_query.update(upd, synchronize_session=False)
                        res_body['modified'].append({'id': term_query.one().id})

                session.flush()

            # Commit and send information about the changes
            write_and_flush(res_body)

    def create_or_update_study(self, study, session):
        """Creates or updates a single study for the batch operation.
        """
        # Create or update Study
        study_idno = study.get('idno', None)
        study_language_id = study.get('language_id', None)

        # Raise exception if not enough information is provided for the study
        if not study_idno or not study_language_id:
            # Send error if vocab or language_id not in request body
            raise InvalidAttributeError('Missing study idno or language_id')

        # Find if the study already exists
        study_instance_query = session.query(models.Study)\
            .filter(getattr(models.Study, 'language_id') == study_language_id)\
            .filter(getattr(models.Study, 'idno') == study_idno)

        # Construct an SQLAlchemy model object with the study attributes if study not found
        if not study_instance_query.one_or_none():
            study_instance = models.Study(**study)
            # Place the object in the session and flushes
            session.add(study_instance)
            session.flush()
            return ('created', study_instance.id)

        # Update if exists
        study_instance_query.update(study, synchronize_session=False)
        return ('modified', study_instance_query.one().id)

    def create_or_update_study_terms(self, study_id, source, terms, session):
        """Creates or updates terms of a single study for the batch operation.
        """
        # Delete existing study terms for this study to replace them with objs in terms
        session.query(models.StudyTerm)\
            .filter(getattr(models.StudyTerm, 'study_id') == study_id)\
            .filter(getattr(models.StudyTerm, 'source') == source)\
            .delete(synchronize_session=False)

        # Find existing term records for the study terms. May raise InvalidAttributeError.
        existing_terms = self.find_term_records_for_batch_op(terms, session)

        # Create StudyTerm records
        def match(attr, val):
            return getattr(models.StudyTerm, attr) == val
        for term in existing_terms:
            # Check if study-term relation exists
            study_terms = session.query(models.StudyTerm)\
                .filter(match('study_id', study_id))\
                .filter(match('term_id', term.id))\
                .filter(match('source', source))\
                .all()

            # If not found, add a new study-term relation
            if len(study_terms) == 0:
                study_term = models.StudyTerm(study_id=study_id, term=term, source=source)
                session.add(study_term)
                session.flush()

    def create_or_update_study_variables(self, study_id, source, variables, session):
        """Creates or updates variables of a single study for the batch operation.
        """
        for var in variables:
            # Check that the attributes exist
            assert_valid_attributes(models.Variable, var)

        # Delete all variables that do not match the objects in variables list
        session.query(models.Variable)\
            .filter(getattr(models.Variable, 'study_id') == study_id)\
            .filter(or_(*[models.Variable.name != var['name'] for var in variables]))\
            .delete(synchronize_session=False)

        # Append study id to variable objects
        variables = [dict(item, **{'study_id': study_id}) for item in variables]

        # Create or update variables.
        for var in variables:
            # Remove inner objects¨
            terms = var.pop('terms', None)
            cat_values = var.pop('catValues', None)

            # Find if object exists
            instance_query = session.query(models.Variable)\
                .filter(models.Variable.study_id == study_id)\
                .filter(models.Variable.name == var['name'])

            # Update record if found
            if instance_query.one_or_none():
                # Update record
                instance_query.update(**var, synchronize_session=False)
                variable_id = instance_query.one().id

            # Create new
            else:
                new_instance = models.Variable(**var)
                session.add(new_instance)
                session.flush()
                variable_id = new_instance.id

            # Create or update catValues
            if cat_values:
                session.query(models.CategoryValue).filter(models.CategoryValue.variable_id == variable_id)\
                    .delete(synchronize_session=False)
                cat_values = [dict(item, **{'variable_id': variable_id}) for item in cat_values]
                for cat_val in cat_values:
                    assert_valid_attributes(models.CategoryValue, cat_val)
                    new_cat_val = models.CategoryValue(**cat_val)
                    session.add(new_cat_val)

            # Create or update variable terms
            def match(attr, val):
                return getattr(models.VariableTerm, attr) == val
            if terms:
                # Delete existing variable terms for this variable and source to replace them with objs in terms
                session.query(models.VariableTerm)\
                    .filter(match('variable_id', variable_id))\
                    .filter(match('source', source))\
                    .delete(synchronize_session=False)

                # Find existing term records for the variable terms
                existing_terms = self.find_term_records_for_batch_op(terms, session)

                # Create VariableTerm records
                for term in existing_terms:
                    variable_term = models.VariableTerm(variable_id=variable_id, term=term, source=source)
                    session.add(variable_term)
                    session.flush()

    def batch_create_or_update_studies(self, studies, write_and_flush, source='user'):
        """Processes a batch of objects with study information.
        Creates new studies or updates existing ones and returns
        information about the performed actions.
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            res_body = {'created': [], 'modified': [], 'failed': []}
            for study in studies:
                try:
                    # Create a savepoint to enable commiting or rolling back a single record
                    # Always flushes the session
                    savepoint = session.begin_nested()

                    # Copy the study object
                    study_obj = {**study}

                    # Check that the provided attributes are valid
                    assert_valid_attributes(models.Study, study)

                    # Pop lists to add later
                    terms = study.pop('terms', None)
                    variables = study.pop('variables', None)

                    # Create or update the study, save status (created or updated)
                    status, study_id = self.create_or_update_study(study, session)

                    # Add terms for the study if found
                    if terms is not None:
                        self.create_or_update_study_terms(study_id, source, terms, session)

                    # Add variables for the study if found
                    if variables is not None:
                        self.create_or_update_study_variables(study_id, source, variables, session)

                    # Store the action (created or updated) performed for this study
                    res_body[status].append({'id': study_id})
                    # Release savepoint
                    savepoint.commit()

                except InvalidAttributeError as exc:
                    # Store the failure details
                    res_body['failed'].append({'req_object': study_obj, 'reason': str(exc)})
                    # Rollback to savepoint
                    savepoint.rollback()
                    continue

            # Write response and flush the output buffer
            write_and_flush(res_body)

    def batch_create_or_update_study_terms(self, objects, source, write_and_flush):
        """Processes a batch of objects with study or variable ids linked to a list of term ids.
        Replaces existing study_terms/variable_terms with the given source with the terms
        identified by their ids.
        Returns information about the succeeded and failed actions.
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            res_body = {'replaced': [], 'failed': []}
            try:
                for obj in objects:
                    study_id = obj['study_id']
                    term_ids = [term_id_obj['id'] for term_id_obj in obj['terms']]
                    try:
                        # Create a savepoint to enable commiting or rolling back a single record
                        # Always flushes the session
                        savepoint = session.begin_nested()

                        # Delete parent terms with the given source
                        session.query(models.StudyTerm)\
                            .filter(models.StudyTerm.study_id == study_id, models.StudyTerm.source == source)\
                            .delete()

                        for term_id in term_ids:
                            new_term = models.StudyTerm(study_id=study_id, term_id=term_id, source=source)
                            session.add(new_term)
                            # session.flush()

                        # Store the action (created or updated) performed for this study
                        res_body['replaced'].append(obj)
                        # Release savepoint
                        savepoint.commit()

                    except InvalidAttributeError as exc:
                        # Store the failure details
                        res_body['failed'].append({'req_object': obj, 'reason': str(exc)})
                        # Rollback to savepoint
                        savepoint.rollback()
                        continue
            except KeyError as exc:
                LOGGER.error(exc)
                write_and_flush(None, 400, 'Invalid key')
            # Write response and flush the output buffer
            write_and_flush(res_body)


    def batch_create_or_update_variable_terms(self, objects, source, write_and_flush):
        """Processes a batch of objects with study or variable ids linked to a list of term ids.
        Replaces existing study_terms/variable_terms with the given source with the terms
        identified by their ids.
        Returns information about the succeeded and failed actions.
        """
        with ExitStack() as stack:
            session = stack.enter_context(self.make_session())
            res_body = {'replaced': [], 'failed': []}
            try:
                for obj in objects:
                    variable_id = obj['variable_id']
                    term_ids = [term_id_obj['id'] for term_id_obj in obj['terms']]
                    try:
                        # Create a savepoint to enable commiting or rolling back a single record
                        # Always flushes the session
                        savepoint = session.begin_nested()

                        # Delete parent terms with the given source
                        session.query(models.VariableTerm)\
                            .filter(models.VariableTerm.variable_id == variable_id,
                                models.VariableTerm.source == source)\
                            .delete()

                        for term_id in term_ids:
                            new_term = models.VariableTerm(variable_id=variable_id, term_id=term_id, source=source)
                            session.add(new_term)
                            # session.flush()

                        # Store the action (created or updated) performed for this study
                        res_body['replaced'].append(obj)
                        # Release savepoint
                        savepoint.commit()

                    except InvalidAttributeError as exc:
                        # Store the failure details
                        res_body['failed'].append({'req_object': obj, 'reason': str(exc)})
                        # Rollback to savepoint
                        savepoint.rollback()
                        continue
            except KeyError as exc:
                LOGGER.error(exc)
                write_and_flush(None, 400, 'Invalid key')

            # Write response and flush the output buffer
            write_and_flush(res_body)

    @contextmanager
    def make_session(self) -> Iterator[Session]:
        """Context manager to make a database session.
        :rtype: Session
        """
        session = None
        try:
            session = sessionmaker(self.engine)()
            yield session
        except Exception:
            if session:
                session.rollback()
            raise
        else:
            session.commit()
        finally:
            if session:
                session.close()
