Environmental Education during the COVID-19 Pandemic
Collected by Margaret Janz, June 2021 in support of her masters thesis for Hamline University
Hamline University Institutional Review Board deemed this study not to be human subject research requiring approval.
Contact: margaret.janz@gmail.com

Files:
data-Raw-Shared.xls: resonses to the survey created with Qualtrics software. Responses have been deidentified as much as possible.
codedValues-Raw-Shared.csv: codes applied to responses using dedoose software. 0=not present, 1=present.

License:
CC-BY-NC-SA
Please cite data used in future publications. 
Please do not use data to identify respondents or their organizations.
