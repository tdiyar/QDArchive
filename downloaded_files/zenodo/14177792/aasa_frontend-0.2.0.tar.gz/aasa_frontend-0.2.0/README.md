# Aasa Backend

Aasa is a prototype system for semi-automatic keyword assingment (*subject indexing*) for studies and variables. With Aasa user can automatically generate keywords based on other descriptive metadata and then accept for or discard from inclusion in the metadata. There are three algoritms/services for keyword generation, namely Annif[4], Finto[4] and TTY. Annif and Finto are external services while TTY is built into Aasa. Keywords can be picked from YSO[2] and ELSST[1] thesaurii. Language choices are Finnish and English. Users may also directly add custom keywords. Keywords can be assigned to one or many studies or variables with single action.

The system consists of two components: backend (database, business logic) and front end (user interface). In addition, you need a data pump to upload metadata for keywording and download keyworded metadata for inclusion in your metadata production pipeline. This release does not contain data pump as it is highly context dependent.

Aasa was produced as part of Academy of Finland (ROR: https://ror.org/05k73zm37) grant project FIRI2018 Crossing Boundaries with Tools and Services (C-BoTS) 319319. In addition of the Aasa software, this part of the project also produced a research paper[3].

## Installation

See INSTALLATION.md for installation instructions

## Usage

See file USAGE.md for usage instructions. The instructions are in Finnish at the moment. However, the user interface is localized in English and Finnish.

## License

This software is licensed under The 3-Clause BSD License. See LICENSE for full license text. For dependecies and their license, see DEPENDENCIES.txt.

## Citing Aasa

See CITATION.cff for full citation metadata. Here's an example loosely following AAS guidelines if you're citing Aasa Frontend :

> Finnish Social Science Data Archive (2024), *Aasa*, doi:10.5281/zenodo.14177791, as developed in https://gitlab.tuni.fi/fsd/aasa_frontend

## References

[1] CESSDA and Service Providers (2024). *The European Language Social Science Thesaurus (ELSST) (Version 5)*. https://elsst.cessda.eu. doi:10.5281/zenodo.13843400

[2] Kansilliskirjasto. *Yleinen suomalainen ontologia*. Available at https://finto.fi/yso/fi/

[3] Skenderi, Erjon, Jukka Huhtamäki, and Kostas Stefanidis (2021). *Multi-Keyword Classification: A Case Study in Finnish Social Sciences Data Archive*. Information 12, no. 12: 491. https://doi.org/10.3390/info12120491

[4] Suominen, Osma, and Inkinen Juho, and Lehtinen Mona (2022), *Annif and Finto AI: Developing and Implementing Automated Subject Indexing*. Italian Journal of Library, Archives, and Information Science. Vol. 13, issue 1. doi:10.4403/jlis.it-12740
