const faker = require('faker');

export function createMockStudy(skip, limit, language) {
  const mockReturnObject = { count: 90 };
  const mockStudyArray = [];

  for (let i = 0; i < limit; i++) {
    const studyIdno = `FSD${skip}${i}`;
    const studyId = faker.datatype.number(6000);

    mockStudyArray.push({
      "id": `${skip}${i}`,
      "idno": studyIdno,
      "language_id": language,
      "title": faker.lorem.sentence(),
      "abstract": faker.lorem.sentence(),
      "date_added": faker.date.recent(),
      "date_modified": faker.date.recent(),
      "keyworded": false,
      "terms": generateTerms(studyId, 1, language)
    });
  }

  mockReturnObject['data'] = mockStudyArray;

  return mockReturnObject;
}

function generateTerms(studyId, amount, language) {
  const terms = [];

  for (let i = 0; i < amount; i++) {
    const content = faker.lorem.word();

    terms.push({
      "study_id": studyId,
      "source": "user",
      "annotator_name": "unknown_user",
      "term": {
        "id": faker.datatype.number(6000),
        "vocab": "YSA",
        "vocabulary_id": language,
        "value": `YSA_fi-${content}`,
        "uri": null,
        "removed": false,
        "deprecated": false
      }
    });
  }

  return terms;
}
