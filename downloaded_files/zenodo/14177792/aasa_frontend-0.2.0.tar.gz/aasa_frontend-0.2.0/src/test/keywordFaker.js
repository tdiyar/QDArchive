const faker = require('faker');

export function createMockKeyword(skip, limit) {
  const mockResponseObject = { count: 90 };
  const mockKeywordArray = [];

  for (let i = 0; i < limit; i++) {
    const value = `${skip}-${i}`;

    mockKeywordArray.push({
      "id": value,
      "vocab": "YSO",
      "language_id": "fi",
      "value": value,
      "uri": faker.internet.url(),
      "removed": false,
      "deprecated": false
    });
  }

  mockResponseObject['data'] = mockKeywordArray;

  return mockResponseObject;
}
