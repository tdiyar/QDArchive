export const fintoMockResponse = [
    {
      "label": "Suomi",
      "notation": null,
      "score": 0.04560157656669617,
      "uri": "http://www.yso.fi/onto/yso/p94426"
    }
]
