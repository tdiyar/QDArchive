export const tableHeaders = [
  {'key': 'index', 'name': '#', 'width': 1},
  {'key': 'qstnLit', 'name': `Kysymysliteraali`, 'width': 8},
  {'key': 'name', 'name': 'ID', 'width': 2},
  {'key': 'study_idno', 'name': `Aineiston ID`, 'width': 3}
];

export const inspectionHeaders = [
  {'key': 'id', 'name': `Muuttujan ID`},
  {'key': 'study_id', 'name': `Aineiston ID`},
  {'key': 'is_fielded', 'name': 'Fielded'},
  {'key': 'varGrp', 'name': `Muuttujaryhmän teksti`},
  {'key': 'labl', 'name': `Nimike`},
  {'key': 'preQTxt', 'name':  `Esikysymys`},
  {'key': 'qstnLit', 'name':  `Kysymysliteraali`},
  {'key': 'postQTxt', 'name': `Jälkikysymys`},
  {'key': 'ivuInstr', 'name': `Haastattelijan ohjeet`},
  {'key': 'catValuesList', 'name': `Vastausvaihtoehdot`},
  {'key': 'notes', 'name':  `Muistiinpanot`},
  {'key': 'keyworded', 'name': `Asiasanoitettu`},
  {'key': 'user_terms', 'name': `Asiasanat`}
];
