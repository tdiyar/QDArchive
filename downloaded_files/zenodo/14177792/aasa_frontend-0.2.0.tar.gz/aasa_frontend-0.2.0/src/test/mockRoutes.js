import { rest } from 'msw';
import { createMockVariable } from './variableFaker';
import { createMockStudy } from './studyFaker';
import { createMockKeyword } from './keywordFaker';
import { fintoMockResponse } from './mockData/fintoMockResponse';
import * as routes from '../store/utils/apiRoutes';

export const handlers = [
  // ------> Variables <------ //
  rest.get(routes.variables, (req, res, ctx) => {
    const query = req.url.searchParams;
    const skip = query.get('skip');
    const limit = query.get('limit');
    const language_id = query.get('language_id');
    return res(ctx.json(createMockVariable(skip, limit, language_id)));
  }),
  rest.patch(`${routes.variables}/*`, (req, res, ctx) => {
    return res(ctx.status(200));
  }),
  rest.post(`${routes.variables}/pick`, (req, res, ctx) => {
    return res(ctx.status(200));
  }),
  rest.get(`${routes.variables}/*/finto-suggestions`, (req, res, ctx) => {
    return res(ctx.json(fintoMockResponse));
  }),
  // ------> Studies <------ //
  rest.get(routes.studies, (req, res, ctx) => {
    const query = req.url.searchParams;
    const skip = query.get('skip');
    const limit = query.get('limit');
    const language_id = query.get('language_id');
    return res(ctx.json(createMockStudy(skip, limit, language_id)));
  }),
  rest.patch(`${routes.studies}/*`, (req, res, ctx) => {
    return res(ctx.status(200));
  }),
  rest.post(`${routes.studies}/pick`, (req, res, ctx) => {
    return res(ctx.status(200));
  }),
  rest.get(`${routes.studies}/*/finto-suggestions`, (req, res, ctx) => {
    return res(ctx.json(fintoMockResponse));
  }),
  // ------> Keywords <------ //
  rest.get(routes.keywords, (req, res, ctx) => {
    const query = req.url.searchParams;
    const limit = query.get('limit');
    const skip = query.get('skip');
    const value = query.get('value');

    if (!value) {
      return res(ctx.json(createMockKeyword(skip, limit)));
    }
    else {
      return res(ctx.json(
        {
          count: 1,
          data: [
            {
              "id": "testID",
              "vocab": "testVocab",
              "vocabulary_id": "test_fi",
              "value": "testValue",
              "uri": "testUri",
              "removed": false,
              "deprecated": false
            }
          ]
        }
      ))
    }
  }),
  rest.put(routes.keywords, (req, res, ctx) => {
    return res(ctx.status(200));
  }),
  // ------> StudyTerm <------ //
  rest.post(`${routes.studies}/*/terms/`, (req, res,ctx) => {
    return res(ctx.status(201));
  }),
  rest.post(`${routes.studies}/*/terms/custom`, (req, res,ctx) => {
    return res(ctx.json(
      {
        "study_id": "00",
        "source": "user",
        "annotator_name": "unknown_user",
        "term": {
          "id": 1,
          "vocab": "Custom",
          "language_id": "fi",
          "value": "testKeyword",
          "uri": null,
          "removed": false,
          "deprecated": false
        }
      }
    ));
  }),
  rest.post(`${routes.studies}/*/terms/finto-ai`, (req, res,ctx) => {
    return res(ctx.json(
      {
        "study_id": "00",
        "source": "user",
        "annotator_name": "unknown_user",
        "term": {
          "id": 1,
          "vocab": "YSO",
          "language_id": "fi",
          "value": "Suomi",
          "uri": "http://www.yso.fi/onto/yso/p94426",
          "removed": false,
          "deprecated": false
        }
      }
    ));
  }),
  rest.delete(`${routes.studies}/*/terms/user/*`, (req, res, ctx) => {
    return res(ctx.status(204));
  }),
  // ------> VariableTerm <------ //
  rest.post(`${routes.variables}/*/terms/`, (req, res,ctx) => {
    return res(ctx.status(201));
  }),
  rest.post(`${routes.variables}/*/terms/custom`, (req, res,ctx) => {
    return res(ctx.json(
      {
        "variable_id": "00",
        "source": "user",
        "annotator_name": "unknown_user",
        "term": {
          "id": 1,
          "vocab": "Custom",
          "language_id": "fi",
          "value": "testKeyword",
          "uri": null,
          "removed": false,
          "deprecated": false
        }
      }
    ));
  }),
  rest.post(`${routes.variables}/*/terms/finto-ai`, (req, res,ctx) => {
    return res(ctx.status(201));
  }),
  rest.delete(`${routes.variables}/*/terms/user/*`, (req, res, ctx) => {
    return res(ctx.status(204));
  })
];
