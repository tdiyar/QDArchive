import React from 'react';
import { render as rtlRender } from '@testing-library/react';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import { MemoryRouter } from 'react-router-dom';
import rootReducer from '../store/rootReducer';

const render = (ui, {initialState, store = createStore(rootReducer, initialState, applyMiddleware(thunk)), ...renderOptions} = {}) => {
  const Wrapper = ({ children }) => {
    return (
      <Provider store={store}>
        <MemoryRouter>{children}</MemoryRouter>
      </Provider>
    );
  }

  return rtlRender(ui, { wrapper: Wrapper, ...renderOptions });
}

// Re-export everything from testing-library and override render method
export * from '@testing-library/react';
export { render };

export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
