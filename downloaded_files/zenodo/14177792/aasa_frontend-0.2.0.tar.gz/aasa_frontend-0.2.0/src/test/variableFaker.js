const faker = require('faker');

export function createMockVariable(skip, limit, language) {
  const mockResponseObject = { count: 90 };
  const mockVariableArray = [];

  for (let i = 0; i < limit; i++) {
    mockVariableArray.push({
      "id": faker.datatype.number(6000),
      "name": `Q${skip}${i}`,
      "study_id": faker.datatype.number(6000),
      "study_idno":  "FSD0115",
      "language_id": language,
      "is_translated": faker.datatype.boolean(),
      "is_fielded": faker.datatype.boolean(),
      "varGrp": "",
      "labl": `[q${i}] ${faker.lorem.word()}`,
      "preQTxt": faker.lorem.sentence(),
      "qstnLit": `${faker.lorem.words()}?`,
      "postQTxt": "",
      "ivuInstr": "",
      "catValues": generateCatValues(faker.datatype.number({'min':3, 'max': 10})),
      "notes": "",
      "var_cluster": null,
      "date_added": faker.date.recent(),
      "date_modified": faker.date.recent(),
      "keyworded": false,
      "terms": [],
      "index": faker.datatype.number(100)
    });
  }

  mockResponseObject['data'] = mockVariableArray;

  return mockResponseObject;
}

function generateCatValues(amount) {
  const catValues = [];

  for (let i = 0; i < amount; i++) {
    catValues.push({
      "catvalue_index": i,
      "catValu": (i === amount - 1 ? "SYSMIS" : i + 1),
      "catLabl": (i === amount - 1 ? "" : faker.lorem.word()),
      "catStat": faker.datatype.number()
    });
  }

  return catValues;
}
