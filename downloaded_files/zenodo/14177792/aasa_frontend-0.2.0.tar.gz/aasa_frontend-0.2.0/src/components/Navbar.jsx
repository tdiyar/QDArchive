import React, { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useHistory } from 'react-router';
import { Menu, Dropdown, Popup, Button } from 'semantic-ui-react';
import { NavLink } from 'react-router-dom';
import { changeLanguage, changeUiLanguage } from '../store/global/globalActions';
import { fetchData, resetResults } from '../store/items/itemActions';
import { resetInspection, resetKeywordVocabulary } from '../store/inspection/inspectionActions';
import './Navbar.css';

export default function Navbar() {
  const dispatch = useDispatch();
  const location = useLocation();
  const history = useHistory();
  const mounted = useRef(false);
  const languageID = useSelector(state => state.global.languageID);
  const languageUI = useSelector(state => state.global.languageUI);
  const dictionary = useSelector(state => state.global.dictionary);
  const inspectionType = useSelector(state => state.inspection.inspectionType);

  // Track if the component is mounted or not
  useEffect(() => {
    mounted.current = true;

    return () => {
      mounted.current = false;
    }
  }, []);

  const languageOptions = [
    { text: 'FI', value: 'fi' },
    { text: 'EN', value: 'en' }
  ];

  function toggleLanguage(e, { value }) {
    e.preventDefault();
    dispatch(changeLanguage(value));
    dispatch(resetInspection());
    dispatch(resetKeywordVocabulary(languageID))
    dispatch(resetResults('variables'));
    dispatch(resetResults('studies'));
    dispatch(resetResults('keywords'));

    for (let i = 1; i < 7; i++) {
      // Fetch data from backend only if the component is mounted
      mounted.current && dispatch(fetchData('variables', 'section', i));
      mounted.current && dispatch(fetchData('studies', 'section', i));
      mounted.current && dispatch(fetchData('keywords', 'section', i));
    }
  }

  function handleDictionaryChange(e, { value }) {
    e.preventDefault();
    dispatch(changeUiLanguage(value));
  }

  function signout() {
    window.location.href = '/Shibboleth.sso/Logout';
  }

  return (
    <Menu pointing secondary role='navigation' aria-label='Main'>
      <Menu.Item as={NavLink} to='/variables' name={dictionary.variables} />
      <Menu.Item as={NavLink} to='/studies' name={dictionary.studies} />
      <Menu.Item as={NavLink} to='/keywords' name={dictionary.keywords} />
      <Popup
        disabled={inspectionType ? true : false}
        trigger={
          <Menu.Item
            onClick={() => inspectionType ?  history.push('/inspect') : null}
            name={dictionary.inspection}
            disabled={inspectionType ? false : true}
          />
        }
      >
        <Popup.Content>
          {dictionary.tooltipMessage}
        </Popup.Content>
      </Popup>
      <Menu.Menu>
        <Menu.Item>
          <span>
            {dictionary.languageOfData}{': '}
            <Dropdown
              disabled={location.pathname === '/inspect' ? true : false}
              inline
              options={languageOptions}
              onChange={toggleLanguage}
              value={languageID}
            />
          </span>
        </Menu.Item>
      </Menu.Menu>
      <Popup
        trigger={
          <Menu.Item
            href='https://manual'
            target='_blank'
            icon='question circle outline'
          />
        }
      >
        <Popup.Content>
          {dictionary.appInstructions}
        </Popup.Content>
      </Popup>
      <Menu.Menu position='right'>
        <Menu.Item>
          <span>
            {dictionary.languageOfUi}{': '}
            <Dropdown
              inline
              options={languageOptions}
              onChange={handleDictionaryChange}
              value={languageUI}
            />
          </span>
        </Menu.Item>
        <Popup
          trigger={
            <Menu.Item>
              <Button icon='sign-out' basic onClick={signout} />
            </Menu.Item>
          }
        >
        <Popup.Content>
          {dictionary.logOut}
        </Popup.Content>
      </Popup>
      </Menu.Menu>
    </Menu>
  );
}
