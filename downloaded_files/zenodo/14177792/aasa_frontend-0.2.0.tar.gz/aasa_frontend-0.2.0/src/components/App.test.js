import { setupServer } from 'msw/node';
import userEvent from '@testing-library/user-event';
import { render, screen, within, sleep } from '../test/test-utils';
import { handlers } from '../test/mockRoutes';
import App from './App';

describe('Integration tests of App', () => {
  const server = setupServer(...handlers);

  // Establish API mocking before all tests
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
  })

  // Reset any request handlers that are declared
  afterEach(() => {
    server.resetHandlers();
  })

  // Clean up once the tests are done
  afterAll(() => {
    server.close();
  })

  // Increase the timeout for the test from the default timeout
  jest.setTimeout(20000);

  test('Renders correctly', async () => {
    render(<App />);

    // Assert that the basic elements of App are rendered on mount
    expect(screen.getByRole('img')).toBeInTheDocument();
    expect(screen.getByText('Aasa')).toBeInTheDocument();
    expect(screen.getAllByRole('navigation')).toHaveLength(2);
    expect(screen.getByRole('table')).toBeInTheDocument();
    expect(screen.getAllByRole('columnheader')).toHaveLength(6);
    expect(screen.getAllByRole('row')).toHaveLength(1);

    // Assert that during loading of data there are 15 placeholder rows
    expect(screen.getAllByRole('status')).toHaveLength(15);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // After data has been loaded, first actual data row is shown
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Assert that after loading the data there are no placeholder rows anymore
    expect(screen.queryAllByRole('status')).toHaveLength(0);

    // Assert that after loading the data there are 16 rows
    expect(screen.getAllByRole('row')).toHaveLength(16);
  })

  test('Views can be changed', async () => {
    render(<App />);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Clicking the link "Aineistot" will change the view
    userEvent.click(screen.getByRole('link', { name: /aineistot/i }));
    expect(await screen.findByText(/fsd00/i)).toBeInTheDocument();

    // Clicking the link "Asiasanat" will change the view
    userEvent.click(screen.getByRole('link', { name: /asiasanat/i }));
    expect(await screen.findAllByRole('cell', { name: /0-0/i})).toHaveLength(1);

    // Clicking the disabled link "Tarkastelu" does not change the view
    userEvent.click(screen.getByText(/tarkastelu/i));
    expect(screen.getAllByRole('cell', { name: /0-0/i})).toHaveLength(1);

    // Clicking the link "Muuttujat" will change the view
    userEvent.click(screen.getByRole('link', { name: /muuttujat/i }));
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Clicking the first linkbutton within the table will change the view to "Tarkastelu"
    userEvent.click(screen.getAllByRole('button')[3]);

    // Wait for the animation to finnish
    await sleep(500);

    // Assert that the view has changed by checking for the correct headers
    expect(screen.getByRole('heading', { name: /muuttujien tiedot/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /asiasanat/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /tarkasteltava muuttuja/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /asiasanalähteet/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /ehdotukset/i})).toBeInTheDocument();
  })

  test('Buttons on the "Asiasanat" view triggers new search', async () => {
    render(<App />);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Change the view to "Asiasanat"
    userEvent.click(screen.getByRole('link', { name: /asiasanat/i }));
    expect(await screen.findAllByText(/0-0/i)).toHaveLength(1);

    // Find the first row from the table and click the button to expand the row
    const firstRow = screen.getByRole('row', { name: /0-0/i});
    userEvent.click(within(firstRow).getByRole('button'));

    // Click button from expanded row
    userEvent.click(screen.getByRole('button', { name: /etsi aineistoja\.\.\./i}));

    // Assert that loading has begun by checking that there are 15 placeholder rows
    expect(screen.getAllByRole('status')).toHaveLength(15);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Assert that that the view has changed to "Aineistot"
    expect(await screen.findByText(/fsd00/i)).toBeInTheDocument();

    // Go back to the view to "Asiasanat" and assert the view has changed
    userEvent.click(screen.getByRole('link', { name: /asiasanat/i }));
    expect(await screen.findAllByText(/0-0/i)).toHaveLength(1);

    // Find the second row from the table and click the button to expand the row
    const secondRow = screen.getAllByRole('row', { name: /0-1/i})[0];
    userEvent.click(within(secondRow).getByRole('button'));

    userEvent.click(screen.getByRole('button', { name: /etsi muuttujia\.\.\./i}));

    // Assert that loading has begun by checking that there are 15 placeholder rows
    expect(screen.getAllByRole('status')).toHaveLength(15);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Assert that that the view has changed to "Muuttujat"
    expect(await screen.findByRole('cell', { name: /q00/i})).toBeInTheDocument();
  })

  test('Triggering new Study search in "Asiasanat" view resets the connected Inspection', async () => {
    render(<App />);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Click the link "Aineistot" to change the view
    userEvent.click(screen.getByRole('link', { name: /aineistot/i }));
    expect(await screen.findByText(/fsd00/i)).toBeInTheDocument();

    // Find the first row and click the checkbox
    const firstStudyRow = screen.getByRole('row', { name: /fsd00/i});
    userEvent.click(within(firstStudyRow).getByRole('checkbox'));

    // Change the view to "Tarkastelu" by clicking the correct link button
    userEvent.click(screen.getAllByRole('button')[3]);

    // Wait for the animation to finnish
    await sleep(500);

    // Assert that the view has changed by checking for a correct header
    expect(screen.getByRole('heading', { name: /aineistojen tiedot/i})).toBeInTheDocument();

    // Change the view to "Asiasanat"
    userEvent.click(screen.getByRole('link', { name: /asiasanat/i }));
    expect(await screen.findAllByText(/0-0/i)).toHaveLength(1);

    // Find the first row from the table and click the button to expand the row
    const firstRow = screen.getByRole('row', { name: /0-0/i});
    userEvent.click(within(firstRow).getByRole('button'));

    // Click button from expanded row
    userEvent.click(screen.getByRole('button', { name: /etsi aineistoja\.\.\./i}));

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Assert that that the view has changed to "Aineistot"
    expect(await screen.findByText(/fsd00/i)).toBeInTheDocument();

    // Assert that the "Tarkastelu" link in the menu is disabled indicating that the Inspection has been reset
    expect(screen.getByText(/tarkastelu/i)).toHaveClass('disabled');
  })

  test('Triggering new Variables search in "Asiasanat" view resets the connected Inspection', async () => {
    render(<App />);

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Assert that the first actual data row is shown
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Find the first row and click the checkbox to select the row
    const firstVariableRow = screen.getByRole('row', { name: /q00/i});
    userEvent.click(within(firstVariableRow).getByRole('checkbox'));

    // Change the view to "Tarkastelu" by clicking the correct link button
    userEvent.click(screen.getAllByRole('button')[3]);

    // Wait for the animation to finnish
    await sleep(500);

    // Assert that the view has changed by checking for a correct header
    expect(screen.getByRole('heading', { name: /muuttujien tiedot/i})).toBeInTheDocument();

    // Change the view to "Asiasanat"
    userEvent.click(screen.getByRole('link', { name: /asiasanat/i }));
    expect(await screen.findAllByText(/0-0/i)).toHaveLength(1);

    // Find the first row from the table and click the button to expand the row
    const firstRow = screen.getByRole('row', { name: /0-0/i});
    userEvent.click(within(firstRow).getByRole('button'));

    // Click button from expanded row
    userEvent.click(screen.getByRole('button', { name: /etsi muuttujia\.\.\./i}));

    // Wait for the data and animation to finish loading
    await sleep(500);

    // Click the link "Muuttujat" and assert that the view has changed
    userEvent.click(screen.getByRole('link', { name: /muuttujat/i }));
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Assert that the "Tarkastelu" link in the menu is disabled indicating that the Inspection has been reset
    expect(screen.getByText(/tarkastelu/i)).toHaveClass('disabled');
  })
})
