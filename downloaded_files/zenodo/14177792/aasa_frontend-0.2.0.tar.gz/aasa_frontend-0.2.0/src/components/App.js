import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Route, Redirect, Switch, useLocation } from 'react-router-dom';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import Header from './Header';
import Navbar from './Navbar';
import InspectView from './views/inspection/InspectView';
import KeywordsView from './views/keywords/KeywordsView';
import StudiesView from './views/studies/StudiesView';
import VariablesView from './views/variables/VariablesView';
import { fetchData } from '../store/items/itemActions';
import './App.css';

export default function App() {
  const location = useLocation();
  const dispatch = useDispatch();

  useEffect(() => {
    let mounted = true;

    for (let i = 1; i < 7; i++) {
      // Fetch data from backend only if the component is mounted
      mounted && dispatch(fetchData('variables', 'section', i));
      mounted && dispatch(fetchData('studies', 'section', i));
      mounted && dispatch(fetchData('keywords', 'section', i));
    }

    return () => {
      mounted = false;
    }
  }, [dispatch]);

  return (
    <div className='main'>
      <Header />
      <Navbar />
      <TransitionGroup>
        <CSSTransition key={location.key} classNames='fade' timeout={500} unmountOnExit>
          <div className='views' role='main'>
            <Switch location={location}>
              <Route exact path='/inspect' component={InspectView} />
              <Route exact path='/keywords' component={KeywordsView} />
              <Route exact path='/studies' component={StudiesView} />
              <Route exact path='/variables' component={VariablesView} />
              <Redirect to='/variables' />
            </Switch>
          </div>
        </CSSTransition>
      </TransitionGroup>
    </div>
  );
}
