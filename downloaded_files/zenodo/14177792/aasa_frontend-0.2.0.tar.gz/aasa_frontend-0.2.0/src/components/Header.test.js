import { render, screen } from '../test/test-utils';
import Header from './Header';

describe('Header component', () => {
  test('Renders correctly', () => {
    render(<Header />);

    expect(screen.getByRole('img')).toBeInTheDocument();
    expect(screen.getByRole('heading')).toBeInTheDocument();
    expect(screen.getByText('Aasa')).toBeInTheDocument();
    expect(screen.queryByText(/virhe/i)).not.toBeInTheDocument();
  })
})
