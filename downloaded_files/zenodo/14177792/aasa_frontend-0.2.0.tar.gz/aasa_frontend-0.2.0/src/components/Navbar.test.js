import { render, screen } from '../test/test-utils';
import userEvent from '@testing-library/user-event';
import Navbar from './Navbar';

describe('Navbar component', () => {
  beforeEach(() => {
    render(<Navbar />);
  })

  test('Renders correctly', () => {
    expect(screen.getByRole('navigation')).toBeInTheDocument();
    expect(screen.getAllByRole('link')).toHaveLength(4);
    expect(screen.getAllByRole('option')).toHaveLength(4);
  })

  test('Changing language of UI works', () => {
    expect(screen.getByText(/muuttujat/i)).toBeInTheDocument();
    const options = screen.getAllByRole('option');
    userEvent.click(options[3]);

    expect(screen.getByText(/variables/i)).toBeInTheDocument();
  })

  test('Language of data can be toggled', () => {
    // Assert that on initial render the dropdown menu has correct settings
    expect(screen.getByText(/datan kieli/i)).toBeInTheDocument();
    expect(screen.getAllByRole('option')[0]).toBeChecked();
    expect(screen.getAllByRole('option')[1]).not.toBeChecked();

    // Assert that the choice can be changed
    userEvent.click(screen.getAllByRole('option')[1]);
    expect(screen.getAllByRole('option')[0]).not.toBeChecked();
    expect(screen.getAllByRole('option')[1]).toBeChecked();
  })
})
