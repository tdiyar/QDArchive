import { useDispatch, useSelector } from 'react-redux';
import { Image, Message } from 'semantic-ui-react';
import logo from '../images/aasa.png';
import { resetErrors } from '../store/global/globalActions';
import './Header.css';

export default function Header() {
  const dispatch = useDispatch();
  const { errors, errorMessage } = useSelector(state => state.global);

  const messageHeader = errors > 1 ? `${errors} virhettä` : 'Virhe';

  return (
    <div className='header'>
      <Image src={logo} size='tiny' />
      <h1>Aasa</h1>
      { errors > 0
        ? <Message
            error
            onDismiss={() => dispatch(resetErrors())}
            header={messageHeader}
            content={errorMessage}
          />
        : null
      }
    </div>
  );
}
