import React, { useState } from 'react';
import { Button, Dropdown, Input, Header, Segment } from 'semantic-ui-react';
import { useDispatch, useSelector } from 'react-redux';
import { addFilterRow, removeFilterRow, changeFilterValue, changeSelectedFilter, resetFilters } from '../../../store/items/itemActions';
import './SearchOptions.css';

export default function SearchOptions({ view, onInput }) {
  const dispatch = useDispatch();
  const mainSearch = useSelector(state => state[view].text);
  const filters = useSelector(state => state[view].searchOptions.filters);
  const values = useSelector(state => state[view].searchOptions.values);
  const selectedFilters = useSelector(state => state[view].searchOptions.selected);
  const active = useSelector(state => state[view].searchOptions.active);
  const dictionary = useSelector(state => state.global.dictionary);
  const [timer, setTimer] = useState(null);

  // Remove filtering options that have already been selected and return
  // an array of the remaining options for the dropdown element
  function remainingOptions(currentKey) {
    const availableFilters = [];

    filters.forEach(filter => {
      if (filter.key === currentKey || !selectedFilters.includes(filter.key)) {
        availableFilters.push({
          'key': filter.key,
          'value': filter.key,
          'text': dictionary[filter.name]
        });
      }
    });

    availableFilters.sort((a, b) => {
      return a.text > b.text ? 1 : -1;
    });

    return availableFilters;
  }

  function removeFilter(key) {
    dispatch(removeFilterRow(view, key));
    onInput();
  }

  // Add selected filter option to store and trigger a new search
  function selectItem(event, result) {
    event.preventDefault();
    dispatch(changeSelectedFilter(view, result.index, result.value));
    onInput();
  }

  function handleChangeValue(event, result) {
    event.preventDefault();
    clearTimeout(timer);

    dispatch(changeFilterValue(view, result.name, result.value));

    setTimer(setTimeout(() => {
      if (onInput) {
        onInput();
      }
    }, 500));
  }

  function clearFilters() {
    dispatch(resetFilters(view));
    onInput();
  }

  const boolOptions = [
    {'key': 'yes', 'value': 'yes', 'text': `${dictionary.yes}`},
    {'key': 'no', 'value': 'no', 'text': `${dictionary.no}`}
  ];

  const filterRows = selectedFilters.map((key, index) => {
    // Find a filter with the same key as the currently selected key
    const currentFilter = filters.find(filter => filter.key === key);
    const availableFilters = remainingOptions(key);

    // Do not add the filter added from the Keywords-view to filterRows, since it is not included in selectable filters
    if (key === 'terms_include') {
      return null;
    }

    return (
      <div key={key}>
        <Button
          icon='x'
          size='mini'
          onClick={() => removeFilter(key)}
        />
        <Dropdown
          search
          selection
          options={availableFilters}
          value={key}
          index={index}
          onChange={selectItem}
        />
        { currentFilter.bool
          ? <Dropdown
              selection
              options={boolOptions}
              onChange={handleChangeValue}
              name={key}
              value={values[key]}
            />
          : <Input
              className='filter-input'
              onChange={handleChangeValue}
              name={key}
              value={values[key]}
            />
        }
      </div>
    );
  });

  if (!active) {
    return null;
  }

  return (
    <React.Fragment>
      <Segment className='search-options'>
        <Header as='h1' size='medium'>
          {dictionary.advancedSearch}
          <Button
            disabled={(selectedFilters.length === 0 && !mainSearch) ? true : false}
            floated='right'
            content={dictionary.clearFilters}
            onClick={clearFilters}
          />
        </Header>
        { filterRows }
        { filterRows.length < filters.length
          ? <div>
              <Button
                icon='plus'
                size='mini'
                onClick={() => dispatch(addFilterRow(view))}
              />
            </div>
          : null
        }
      </Segment>
    </React.Fragment>
  );
}
