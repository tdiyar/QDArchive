import { useDispatch, useSelector } from 'react-redux';
import { Button, Loader } from 'semantic-ui-react';
import DragArea from './DragArea';
import { selectItemsKeywords, selectAllKeywordingStatus, selectInspectedKeywordingStatus } from '../../../store/items/itemReducer';
import { updateKeywordedForItems } from '../../../store/items/itemActions';
import { selectAllSharedKeywords } from '../../../store/inspection/inspectionReducer';
import './ItemKeywords.css';

export default function ItemKeywords(props) {
  const { view, textInspectedItem, dragAttributes, textAllItems } = props;
  const dispatch = useDispatch();
  const selectedItems = useSelector(state => state.inspection.selected);
  const inspectedKeywords = [...useSelector(state =>
    selectItemsKeywords(state[view], state.inspection.inspectedItem, 'user'))].sort((a, b) => {
      return a.value.toLowerCase() > b.value.toLowerCase() ? 1 : -1;
    }
  );
  const allKeywords = useSelector(state => selectAllSharedKeywords(state, view));
  const pendingRequests = useSelector(state => state.inspection.pendingRequests > 0);
  const allKeyworded = useSelector(state => selectAllKeywordingStatus(state[view], selectedItems));
  const inspectedKeyworded = useSelector(state => selectInspectedKeywordingStatus(state[view], state.inspection.inspectedItem));
  const dictionary = useSelector(state => state.global.dictionary);

  function toggleInspectedKeywording() {
    dispatch(updateKeywordedForItems('inspected', view, !inspectedKeyworded));
  }

  function toggleAllKeywording() {
    dispatch(updateKeywordedForItems('all', view, !allKeyworded));
  }

  return (
    <div>
      <div className='flex-row'>
        <h2>{dictionary.keywords}</h2>
        {pendingRequests && <Loader active inline />}
      </div>
      <div className='horizontal-divider' />
      <h3>{`${dictionary.inspected} ${textInspectedItem}`}</h3>
      <DragArea
        id='selected'
        emptyText={dictionary.noKeywords}
        items={inspectedKeywords}
        {...dragAttributes}
        height={selectedItems.length > 1 ? '16.5em' : '40em'}
      />
      <div className='right-aligned'>
        <Button onClick={toggleInspectedKeywording}>
          {inspectedKeyworded ? dictionary.markAsUnready : dictionary.markAsReady}
        </Button>
      </div>

      { selectedItems.length > 1
        ? <div>
            <h3>{textAllItems}</h3>
            <DragArea
              id='all-keywords'
              emptyText={dictionary.noKeywords}
              items={allKeywords}
              {...dragAttributes}
              height='16.5em'
            />
            <div className='right-aligned'>
              <Button onClick={toggleAllKeywording}>
                {allKeyworded ? dictionary.markAllAsUnready : dictionary.markAllAsReady}
              </Button>
            </div>
          </div>
        : null
      }
    </div>
  );
}
