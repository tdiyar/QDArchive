import { Table } from 'semantic-ui-react';
import './SearchTableHeaders.css';

export default function SearchTableHeaders(props) {
  const { tableHeaders, view, sortColumn, sortDirection, callFunc } = props;

  const headers = tableHeaders.map(header => {
    return (
      <Table.HeaderCell
        key={header.key}
        disabled={header.key === 'uri'? true : false}
        onClick={() => callFunc(header.key)}
        width={header.width}
        sorted={header.key === sortColumn ? sortDirection : null}
      >
        {header.name}
      </Table.HeaderCell>
    );
  })

  return (
    <Table.Header>
      <Table.Row>
        { view !== 'keywords'
          ? <Table.HeaderCell disabled width={1} key={'checkbox-header'}></Table.HeaderCell>
          : null
        }
        { headers }
        <Table.HeaderCell disabled width={1} key='details-header'></Table.HeaderCell>
      </Table.Row>
    </Table.Header>
  );
}
