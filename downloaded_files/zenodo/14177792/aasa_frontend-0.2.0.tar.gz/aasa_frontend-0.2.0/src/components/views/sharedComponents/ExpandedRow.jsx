import React from 'react';
import { useSelector } from 'react-redux';
import { Table, Button, List } from 'semantic-ui-react';

export default function ExpandedRow({ view, length, headers, item }) {
  const dictionary = useSelector(state => state.global.dictionary);

  // Return correct value from item in correct format based on the properties of current header
  function findContent(header) {
    if (item[header.key] === '' || item[header.key] === null) return '-';
    if (typeof item[header.key] === 'boolean') return item[header.key] ? `${dictionary.yes}` : `${dictionary.no}`;
    if (header.callFunc) return <Button onClick={() => header.callFunc(item.id)}>{header.text}</Button>;

    if (header.key === 'user_terms') {
      const userTermsArrray = item[header.key].map(term => `${term.vocab}-${term.value}`);

      return userTermsArrray.join(', ');
    }

    if (header.key === 'catValuesList') {
      const catValuesList = item['catValues'].map(value => {
        return (
          `${value.catLabl} (${value.catValu})`
        );
      });

      return catValuesList.join(', ');
    }

    // Default return
    return item[header.key];
  }

  // Map through the headers and return list items correspongind to header
  const listItems = headers.map(header => {
    return (
      <List.Item key={`${item.jointID}-${header.key}`}>
        { header.name ? <strong>{header.name}: </strong> : null }
        { findContent(header) }
      </List.Item>
    );
  });

  return (
    <Table.Row>
      { view !== 'keywords' && <Table.Cell key={'emptyCell-' + item.jointID}></Table.Cell> }
      <Table.Cell colSpan={length}>
        <List style={{marginBottom: '0.5em'}} >
          { listItems }
        </List>
      </Table.Cell>
    </Table.Row>
  );
}
