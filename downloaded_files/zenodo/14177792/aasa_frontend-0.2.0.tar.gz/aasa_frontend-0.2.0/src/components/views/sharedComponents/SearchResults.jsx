import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Pagination, Table } from 'semantic-ui-react';
import { changeSort, changeCurrentPage, fetchData } from '../../../store/items/itemActions';
import { selectPageItems, selectTotalPages, selectPages } from '../../../store/items/itemReducer';
import SearchTableHeaders from './SearchTableHeaders';
import LoadingPlaceholder from './LoadingPlaceholder';
import SearchTableRow from './SearchTableRow';
import './SearchResults.css';

export default function SearchResults({ view, tableHeaders, inspectionHeaders, newSearch }) {
  const dispatch = useDispatch();
  const dictionary = useSelector(state => state.global.dictionary);
  const totalPages = useSelector(state => selectTotalPages(state[view]));
  const currentPage = useSelector(state => state[view].currentPage);
  const allPages = useSelector(state => selectPages(state[view]));
  const items = useSelector(state => selectPageItems(state[view]));
  const sortDirection = useSelector(state => state[view].sortDirection);
  const sortColumn = useSelector(state => state[view].sortColumn);
  const loading = useSelector(state => state[view].loading);
  const itemsCount = useSelector(state => state[view].itemsCount);
  const [expandedRows, setExpandedRows] = useState([]);

  // Control opening and closing the expanded views
  function toggleExpand(itemKey) {
    if (expandedRows.includes(itemKey)) {
      setExpandedRows(expandedRows.filter((key) => key !== itemKey));
    }
    else {
      setExpandedRows(expandedRows => [...expandedRows, itemKey]);
    }
  }

  function toggleSort(key) {
    dispatch(changeSort(view, key));
    newSearch();
  }

  function changePage(data) {
    // Load more data for next pages if necessary
    for (let i = data.activePage; i < data.activePage + 6; i++) {
      if (i in allPages === false) {
        dispatch(fetchData(view, 'section', i));
      }
    }

    dispatch(changeCurrentPage(view, data.activePage));
  }

  // Map through the items array and return row-components populated with items data
  const rows = items.map((item, index) => {
    return (
      <SearchTableRow
        key={item.jointID}
        item={item}
        index={index}
        toggleExpand={toggleExpand}
        expanded={expandedRows.includes(item.jointID)}
        view={view}
        tableHeaders={tableHeaders}
        inspectionHeaders={inspectionHeaders}
      />
    );
  })

  return (
    <div className='search-results'>
      <div className='table-content'>
        <Table sortable fixed celled>
          <SearchTableHeaders
            tableHeaders={tableHeaders}
            view={view}
            sortColumn={sortColumn}
            sortDirection={sortDirection}
            callFunc={(key) => toggleSort(key)}
          />
          <Table.Body>
            { loading
              ? <LoadingPlaceholder tableHeaders={tableHeaders} />
              : rows
            }
          </Table.Body>
        </Table>
      </div>
      <div>
        <Pagination
          defaultActivePage={currentPage}
          totalPages={totalPages}
          onPageChange={(event, data) => changePage(data)}
        />
        <span className='itemCount'>
          <strong>{dictionary.found} {dictionary[view].toLowerCase()}: {itemsCount}</strong>
        </span>
      </div>
    </div>
  );
}
