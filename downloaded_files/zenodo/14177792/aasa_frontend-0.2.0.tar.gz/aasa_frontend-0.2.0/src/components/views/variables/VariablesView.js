import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid } from 'semantic-ui-react';
import SearchBar from '../sharedComponents/SearchBar';
import SearchResults from '../sharedComponents/SearchResults';
import SelectionListing from '../sharedComponents/SelectionListing';
import LoadingButton from '../sharedComponents/LoadingButton';
import SearchOptions from '../sharedComponents/SearchOptions';
import { fetchData, resetResults } from '../../../store/items/itemActions';
import { resetInspection } from '../../../store/inspection/inspectionActions';

export default function VariablesView() {
  const dispatch = useDispatch();
  const dictionary = useSelector(state => state.global.dictionary);
  const inspectionType = useSelector(state => state.inspection.inspectionType);

  const tableHeaders = [
    {'key': 'index', 'name': '#', 'width': 1},
    {'key': 'qstnLit', 'name': `${dictionary.qstnLit}`, 'width': 8},
    {'key': 'name', 'name': 'ID', 'width': 2},
    {'key': 'study_idno', 'name': `${dictionary.studyId}`, 'width': 3}
  ];

  const inspectionHeaders = [
    {'key': 'name', 'name': `${dictionary.variableId}`},
    {'key': 'study_idno', 'name': `${dictionary.studyId}`},
    {'key': 'is_fielded', 'name': `${dictionary.fielded}`},
    {'key': 'varGrp', 'name': `${dictionary.varGrp}`},
    {'key': 'labl', 'name': `${dictionary.labl}`},
    {'key': 'preQTxt', 'name':  `${dictionary.preQTxt}`},
    {'key': 'qstnLit', 'name':  `${dictionary.qstnLit}`},
    {'key': 'postQTxt', 'name': `${dictionary.postQTxt}`},
    {'key': 'ivuInstr', 'name': `${dictionary.ivuInstr}`},
    {'key': 'catValuesList', 'name': `${dictionary.catValuesList}`},
    {'key': 'notes', 'name':  `${dictionary.notes}`},
    {'key': 'keyworded', 'name': `${dictionary.keyworded}`},
    {'key': 'user_terms', 'name': `${dictionary.keywords}`}
  ];

  function newSearch() {
    dispatch(resetResults('variables'));

    inspectionType === 'variables' && dispatch(resetInspection());

    for (let i = 1; i < 7; i++) {
      dispatch(fetchData('variables', 'section', i));
    }
  }

  function loadAll() {
    dispatch(fetchData('variables', 'all', 1, 10000));
  }

  return (
    <Grid columns={2}>
      <Grid.Column width={12}>
        <div className='row-flexbox'>
          <SearchBar view='variables' newSearch={newSearch} />
          <LoadingButton view='variables' text={dictionary.chooseAll} callFunc={() => loadAll()} />
        </div>
        <SearchOptions view='variables' onInput={newSearch} />
        <SearchResults
          tableHeaders={tableHeaders}
          view='variables'
          inspectionHeaders={inspectionHeaders}
          newSearch={newSearch}
        />
      </Grid.Column>
      <Grid.Column width={4}>
        <SelectionListing
          view='variables'
          heading={`${dictionary.selected} ${dictionary.variables}`}
          header={dictionary.variable}
        />
      </Grid.Column>
    </Grid>
  );
}
