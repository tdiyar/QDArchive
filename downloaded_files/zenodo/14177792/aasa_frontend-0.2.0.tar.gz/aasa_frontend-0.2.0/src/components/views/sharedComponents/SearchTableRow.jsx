import React from 'react';
import { Checkbox, Icon, Table } from 'semantic-ui-react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setInspection, fetchOtherLanguageItems } from '../../../store/inspection/inspectionActions';
import { addSelected, removeSelected } from '../../../store/items/itemActions';
import ExpandButton from './ExpandButton';
import ExpandedRow from './ExpandedRow';
import './SearchTableRow.css';

export default function SearchTableRow(props) {
  const { item, index, toggleExpand, expanded, view, tableHeaders, inspectionHeaders } = props;
  const dispatch = useDispatch();
  const history = useHistory();
  const selected = useSelector(state => state[view].selected);
  const dataLanguage = useSelector(state => state.global.languageID);

  // Select an item for inspection and change the view to '/inspect'
  function startInspection() {
    // Add clicked item to selected items if it is not selected already
    if (!selected.includes(item.jointID)) {
      dispatch(addSelected(view, item.jointID, index));
    }

    dispatch(setInspection(view, [item.jointID], dataLanguage));
    dispatch(fetchOtherLanguageItems(view));
    history.push('/inspect');
  }

  // Select or unselect an item
  function toggleSelect() {
    if (selected.includes(item.jointID)) {
      dispatch(removeSelected(view, item.jointID));
    }
    else {
      dispatch(addSelected(view, item.jointID, index));
    }
  }

  function createCellContent(headerKey) {
    if ((headerKey === 'idno' || headerKey === 'name') && view !== 'keywords') {
      return (
        <button className='linkbutton' onClick={() => startInspection()}>
          { item[headerKey] }
        </button>
      )
    }

    if (headerKey === 'uri') {
      return <a href={item[headerKey]}>{item[headerKey]}</a>
    }

    return item[headerKey];
  }

  // Map the headers and create cells for the table row
  const rowCells = tableHeaders.map(header => {
    return (
      <Table.Cell key={item.jointID + header.key} singleLine>
        { createCellContent(header.key) }
      </Table.Cell>
    )
  });

  return (
    <React.Fragment>
      <Table.Row>
        { view !== 'keywords'
          ? <Table.Cell className='checkbox-cell'>
              <Checkbox checked={selected.includes(item.jointID)} onClick={() => toggleSelect()} />
            </Table.Cell>
          : null
        }
        { rowCells }
        <Table.Cell className='toggle-expand-cell'>
          <div>
            { item.keyworded && <Icon color='green' name='checkmark' size='small' /> }
            <ExpandButton expanded={expanded} callFunc={() => toggleExpand(item.jointID)} />
          </div>
        </Table.Cell>
      </Table.Row>
      { expanded
        ? <ExpandedRow
            view={view}
            length={tableHeaders.length + 1}
            headers={inspectionHeaders}
            item={item}
          />
        : null
      }
    </React.Fragment>
  );
}
