import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';
import { Grid } from 'semantic-ui-react';
import SearchBar from '../sharedComponents/SearchBar';
import SearchResults from '../sharedComponents/SearchResults';
import SearchOptions from '../sharedComponents/SearchOptions';
import { fetchData, resetResults, setSearchTerm } from '../../../store/items/itemActions';
import { resetInspection } from '../../../store/inspection/inspectionActions';

export default function KeywordsView() {
  const dispatch = useDispatch();
  const dictionary = useSelector(state => state.global.dictionary);
  const inspectionType = useSelector(state => state.inspection.inspectionType);
  const history = useHistory();

  const tableHeaders = [
    {'key': 'value', 'name': `${dictionary.word}`, 'width': 6},
    {'key': 'uri', 'name': 'URI', 'width': 7},
    {'key': 'vocab', 'name': `${dictionary.vocabularyId}`, 'width': 2}
  ];

  const inspectionHeaders = [
    {'key': 'vocab', 'name': `${dictionary.vocabularyId}`},
    {'key': 'value', 'name': `${dictionary.word}`},
    {'key': 'deprecated', 'name': `${dictionary.deprecated}`},
    {'key': 'removed', 'name': `${dictionary.removed}`},
    {'key': 'studies', 'text': `${dictionary.searchStudies}`, 'callFunc': (id) => studySearch(id)},
    {'key': 'variables', 'text': `${dictionary.searchVariables}`, 'callFunc': (id) => variableSearch(id)}
  ];

  function newSearch(view = 'keywords') {
    dispatch(resetResults(view));

    for (let i = 1; i < 7; i++) {
      dispatch(fetchData(view, 'section', i));
    }
  }

  function variableSearch(id) {
    dispatch(setSearchTerm('variables', id));
    newSearch('variables');

    if (inspectionType === 'variables') {
      dispatch(resetInspection());
    }

    history.push('/variables');
  }

  function studySearch(id) {
    dispatch(setSearchTerm('studies', id));
    newSearch('studies');

    if (inspectionType === 'studies') {
      dispatch(resetInspection());
    }

    history.push('/studies');
  }

  return (
    <Grid>
      <Grid.Column>
        <div className='row-flexbox'>
          <SearchBar view='keywords' newSearch={newSearch} />
        </div>
        <SearchOptions view='keywords' onInput={newSearch} />
        <SearchResults
          tableHeaders={tableHeaders}
          view='keywords'
          maxLength={60}
          maxItems={1}
          inspectionHeaders={inspectionHeaders}
          newSearch={newSearch}
        />
      </Grid.Column>
    </Grid>
  );
}
