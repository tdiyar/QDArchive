import React from 'react';
import { Label } from 'semantic-ui-react';

export default function DraggableLabel(props) {
  function startDrag(event) {
    event.dataTransfer.setData('text/plain', '');

    if (props.onDragStart) {
      props.onDragStart(event);
    }
  }

  return (
    <div draggable='true' onDragStart={startDrag} style={{'margin': '0.25em 0.25em'}}>
      <Label size='large'>
        {props.children}
      </Label>
    </div>
  );
}
