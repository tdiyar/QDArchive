import { useDispatch, useSelector } from 'react-redux';
import { Button, Input, Icon } from 'semantic-ui-react';
import { changeText, toggleSearchActive } from '../../../store/items/itemActions';

export default function SearchBar({view, newSearch}) {
  const dispatch = useDispatch();
  const searchValue = useSelector(state => state[view].text);
  const dictionary = useSelector(state => state.global.dictionary);

  function handleChange(e) {
    e.preventDefault();
    dispatch(changeText(view, e.target.value));
  }

  function triggerSearch(e) {
    if (e.key === 'Enter') {
      newSearch();
    }
  }

  function openFilterChoices() {
    dispatch(toggleSearchActive(view));
  }

  return (
    <div>
      <Input
        icon={<Icon name='search' circular link onClick={() => newSearch()} />}
        placeholder={dictionary.search}
        size='large'
        value={searchValue}
        onChange={handleChange}
        onKeyPress={triggerSearch}
      />
      <Button size='large' style={{'marginLeft': '0.25em'}} icon onClick={openFilterChoices}>
        <div style={{'display': 'inline'}}>{dictionary.advancedSearch}</div>
        <Icon name='caret down' />
      </Button>
    </div>
  );
}
