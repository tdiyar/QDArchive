import { setupServer } from 'msw/node';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { sleep } from '../../../test/test-utils';
import { handlers } from '../../../test/mockRoutes';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { fetchData } from '../../../store/items/itemActions';
import VariablesView from './VariablesView';

describe('VariablesView component', () => {
  const server = setupServer(...handlers);

  // Establish API mocking before all tests
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
  })

  // For each test, create a store, preload data to store and render the component within provider
  beforeEach(async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    render(
      <Provider store={store}>
        <VariablesView />
      </Provider >
    );
  })

  // Reset request handlers
  afterEach(() => {
    server.resetHandlers();
  })

  // Clean up once the tests are done
  afterAll(() => {
    server.close();
  })

  test('Renders correctly', async () => {
    // Correct elements are rendered
    expect(screen.getByRole('textbox')).toBeInTheDocument();
    expect(screen.getAllByRole('button')).toHaveLength(2);
    expect(screen.getByRole('table')).toBeInTheDocument();
    expect(screen.getAllByRole('columnheader')).toHaveLength(6);
    expect(screen.getAllByRole('checkbox')).toHaveLength(15);
    expect(screen.getByRole('navigation')).toBeInTheDocument();
    expect(screen.getByRole('heading')).toBeInTheDocument();

    // Placeholder rows are shown while the data is loading
    expect(screen.getAllByRole('status')).toHaveLength(15);

    await sleep(200);

    // After data has been loaded the placeholder rows are not shown anymore and there is more buttons
    expect(screen.queryAllByRole('status')).toHaveLength(0);
    expect(screen.getAllByRole('button')).toHaveLength(32);
  })

  test('New search can be triggered and data is loaded', async () => {
    // Select searchbox and click enter
    userEvent.type(screen.getByPlaceholderText(/haku/i), '{enter}');

    // Placeholder rows are shown while data is loading
    expect(screen.getAllByRole('status')).toHaveLength(15);

    // After data has been loaded, first actual data row is shown and the placeholder rows are not shown anymore
    const firstVariableRow = await screen.findByText(/q00/i);
    expect(firstVariableRow).toBeInTheDocument();
    expect(screen.queryAllByRole('status')).toHaveLength(0);
  })

  test('Rows can be selected and de-selected', async () => {
    // Wait for the data to load
    const firstVariableCell = await screen.findByText(/q00/i);
    expect(firstVariableCell).toBeInTheDocument();

    // Assert that the first row has not been selected
    expect(screen.queryByRole('cell', { name: /q00-fsd0115-fi/i})).not.toBeInTheDocument();

    // Find the first row and click the checkbox
    const firstDataRow = screen.getAllByRole('row')[1];
    userEvent.click(within(firstDataRow).getByRole('checkbox'));

    // Assert that the first row has been selected
    expect(screen.getByRole('cell', { name: /q00-fsd0115-fi/i})).toBeInTheDocument();

    // Click the checkbox of the first row and assert that the row is not selected anymore
    userEvent.click(within(firstDataRow).getByRole('checkbox'));
    expect(screen.queryByRole('cell', { name: /q00-fsd0115-fi/i})).not.toBeInTheDocument();
  })

  test('"Valitse kaikki" button shows loading indicator when clicked', async () => {
    // Wait for the data to load
    const firstVariableCell = await screen.findByText(/q00/i);
    expect(firstVariableCell).toBeInTheDocument();

    // Assert that the "Valitse kaikki" button does not currently have the "loading" class
    expect(screen.getByRole('button', {name: /valitse kaikki/i})).not.toHaveClass('loading');

    // Click the "Tarkennettu haku" button to open the filters sections
    userEvent.click(screen.getByRole('button', {name: /tarkennettu haku/i}));

    // Click on the button with X-icon to add a filter
    userEvent.click(screen.getAllByRole('button')[3]);

    // Select the input field of the added filter and type text to activate the "Valitse kaikki" button
    const filterInput = document.querySelector('.filter-input > input');
    userEvent.type(filterInput, 'test input');

    // Click the "Valitse kaikki" button
    userEvent.click(screen.getByRole('button', {name: /valitse kaikki/i}));

    // Assert that the "Valitse kaikki" button now has the "loading" class
    expect(screen.getByRole('button', {name: /valitse kaikki/i})).toHaveClass('loading');
  })
})
