import { setupServer } from 'msw/node';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { sleep } from '../../../test/test-utils';
import { handlers } from '../../../test/mockRoutes';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { fetchData } from '../../../store/items/itemActions';
import { setInspection } from '../../../store/inspection/inspectionActions';
import InspectView from './InspectView';

describe('InspectView component', () => {
  const server = setupServer(...handlers);

  // Establish API mocking before all tests
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
  })

  // Reset request handlers
  afterEach(() => {
    server.resetHandlers();
  })

  // Clean up once the tests are done
  afterAll(() => {
    server.close();
  })

  // Increase the timeout for the test from the default timeout
  jest.setTimeout(15000);

  test('Renders correctly when nothing has been selected', () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    expect(screen.getByText(/mitään ei ole valittu tarkasteluun/i)).toBeInTheDocument();
  })

  test('Renders correctly when an item has been selected for inspection', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('variables', ['Q00-FSD0115-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the correct headings can be found on the screen
    expect(screen.getByRole('heading', {name: /muuttujien tiedot/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', {name: /asiasanat/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', {name: /asiasanalähteet/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', {name: /tarkasteltava muuttuja/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', {name: /ehdotukset/i})).toBeInTheDocument();

    // Assert that the first table has correct cells
    expect(screen.getByRole('cell', {name: /kielen id/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /vaihda kieliversiota/i})).toBeInTheDocument();

    // Assert that the button in the first table is disabled
    expect(screen.getAllByRole('button')[3]).toBeDisabled();

    // Assert that the second table has correct cells
    expect(screen.getByRole('cell', {name: /muuttujan id/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /aineistonumero/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /kysytty kysymys/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /kysymysryhmän esiteksti/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /muuttujan selite/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /kysymyksen esiteksti/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /kysymysteksti/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /kysymyksen jälkiteksti/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /haastattelijan ohjeet/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /vastausvaihtoehdot/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /muistiinpanot/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /asiasanoitettu/i})).toBeInTheDocument();

    // Assert that there is 3 listboxes and the correct options for them
    expect(screen.getAllByRole('listbox')).toHaveLength(3);
    expect(screen.getByRole('option', {name: /q00-fsd0115-fi/i})).toBeInTheDocument();
    expect(screen.getAllByRole('option', {name: /yso/i})).toHaveLength(2);
    expect(screen.getAllByRole('option', {name: /elsst/i})).toHaveLength(2);
    expect(screen.getByRole('option', {name: /custom/i})).toBeInTheDocument();
    expect(screen.getByRole('option', {name: /annif/i})).toBeInTheDocument();
    expect(screen.getByRole('option', {name: /finto/i})).toBeInTheDocument();
    expect(screen.getByRole('option', {name: /muissa valituissa muuttujissa/i})).toBeInTheDocument();
    expect(screen.getByRole('option', {name: /tty/i})).toBeInTheDocument();

    // Assert that there is correct amount of buttons
    expect(screen.getAllByRole('button')).toHaveLength(8);

    // Assert that buttons with correct texts are rendered
    expect(screen.getByRole('button', {name: /merkitse valmiiksi/i})).toBeInTheDocument();
    expect(screen.getByRole('button', {name: /lisää kaikki ehdotetut tarkasteltavaan/i})).toBeInTheDocument();
    expect(screen.getByRole('button', {name: /lisää kaikki ehdotetut valittuihin/i})).toBeInTheDocument();

    // Assert that there are two tables on the screen
    expect(screen.getAllByRole('table')).toHaveLength(2);

    // Assert that there is correct amount of rows
    expect(screen.getAllByRole('row')).toHaveLength(15);
  })

  test('Table cells can be opened and closed', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('variables', ['Q00-FSD0115-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Select the first expandable cell
    const firstExpandCell = screen.getAllByRole('cell')[23];

    // Assert that the cell has the symbol indicating the cell can be expanded
    expect(firstExpandCell).toHaveTextContent(/.../i);

    // Select the expand button from the first expandable cell
    const firstExpandButton = within(firstExpandCell).getByRole('button');

    // Assert that the caret icon on the button is downwards
    expect(firstExpandButton.querySelector('i')).toHaveClass('down');

    // Click the button to expand the cell
    userEvent.click(firstExpandButton);

    // Assert that the caret icon on the button is upwards
    expect(firstExpandButton.querySelector('i')).toHaveClass('up');

    // Click the button to close the expandable cell
    userEvent.click(firstExpandButton);

    // Assert that the caret icon on the clicked button is now downwards
    expect(firstExpandButton.querySelector('i')).toHaveClass('down');
  })

  test('Selected items can be removed and the view updates accordingly', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('variables', ['Q00-FSD0115-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the correct view is open and the selected item can be found on screen
    expect(screen.getByRole('heading', {name: /muuttujien tiedot/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', {name: /asiasanat/i})).toBeInTheDocument();
    expect(screen.getByRole('heading', {name: /asiasanalähteet/i})).toBeInTheDocument();
    expect(screen.getByRole('option', {name: /q00-fsd0115-fi/i})).toBeInTheDocument();

    // Click the remove item button
    userEvent.click(screen.getAllByRole('button')[2]);

    // Wait for the data to be processed
    await sleep(500);

    // Assert that the view has changed and the item can not be found on the screen anymore
    expect(screen.getByText(/mitään ei ole valittu tarkasteluun/i)).toBeInTheDocument();
    expect(screen.queryByRole('option', {name: /q00-fsd0115-fi/i})).not.toBeInTheDocument();
  })

  test('Keywords can be removed from studies', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi', 'FSD01-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that initially there is right amount of keywords with text beginning YSA_fi
    expect(screen.getAllByText(/ysa_fi/i)).toHaveLength(1);

    // Select the first keyword and click the removing icon
    const firstKeyword = screen.getAllByText(/ysa_fi/i)[0];
    userEvent.click(firstKeyword.querySelector('i'));

    // Wait for the action to be processed
    await sleep(50);

    // Assert that the keyword is removed
    expect(firstKeyword).not.toBeInTheDocument();
  })

  test('Chosen study can be changed', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi', 'FSD01-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the first of the chosen items is selected and the second is not
    expect(screen.getByRole('option', {name: /fsd00-fi/i})).toBeChecked();
    expect(screen.getByRole('option', {name: /fsd01-fi/i})).not.toBeChecked();

    // Click the button with chevron down to select the next item
    userEvent.click(screen.getAllByRole('button')[1]);

    // Assert that now the second of the chosen items is selected and the first is not
    expect(screen.getByRole('option', {name: /fsd01-fi/i})).toBeChecked();
    expect(screen.getByRole('option', {name: /fsd00-fi/i})).not.toBeChecked();

    // Click the button with chevron up to select the previous item
    userEvent.click(screen.getAllByRole('button')[0]);

    // Assert that the first of the chosen items is selected and the second is not
    expect(screen.getByRole('option', {name: /fsd00-fi/i})).toBeChecked();
    expect(screen.getByRole('option', {name: /fsd01-fi/i})).not.toBeChecked();

    // Click the dropdown menu open and select the second item by clicking it
    userEvent.click(screen.getAllByRole('combobox')[0]);
    userEvent.click(screen.getByRole('option', {name: /fsd01-fi/i}));

    // Assert that now the second of the chosen items is selected and the first is not
    expect(screen.getByRole('option', {name: /fsd01-fi/i})).toBeChecked();
    expect(screen.getByRole('option', {name: /fsd00-fi/i})).not.toBeChecked();
  })

  test('New custom keywords can be added to studies', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi', 'FSD01-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the YSO vocabulary is intially chosen
    expect(screen.getAllByRole('option', {name: /yso/i})[0]).toBeChecked();

    // Open the dropdown list and choose the "Custom" option
    userEvent.click(screen.getAllByRole('textbox')[1]);
    userEvent.click(screen.getByRole('option', {name: /custom/i}));

    // Assert that the YSO vocabulary is not selected
    expect(screen.getAllByRole('option', {name: /yso/i})[0]).not.toBeChecked();

    // Assert that the Custom vocabulary is selected
    expect(screen.getByRole('option', {name: /custom/i})).toBeChecked();

    // Input test keyword to the input field
    userEvent.type(screen.getByPlaceholderText(/asiasana/i), 'testKeyword');

    // Click the button to add the keyword into the inspected study
    userEvent.click(screen.getByRole('button', {name: /lisää tarkasteltavaan/i}));

    // Wait for the action to be processed
    await sleep(150);

    // Assert that the custom keyword has been added to the study and can be found in one drag-area
    expect(screen.getAllByText(/custom-testKeyword/i)).toHaveLength(1);
  })

  test('Keyword suggestions can be searched from YSO', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the YSO vocabulary is selected
    expect(screen.getAllByRole('option', {name: /yso/i})[0]).toBeChecked();

    // Input test keyword to the input field
    userEvent.type(screen.getByPlaceholderText(/haku/i), 'test keyword');

    // Assert that the textbox has the "test keyword" input value
    expect(screen.getAllByRole('textbox')[2]).toHaveValue('test keyword');

    // Wait for the action to be processed and the timer to run out
    await sleep(600);

    // Assert that the mock response from msw can now be seen on screen
    expect(screen.getByText(/testvalue/i)).toBeInTheDocument();
  })

  test('Finto can be called for suggestions', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that initially the option "Finto" is selected
    expect(screen.getByRole('option', {name: /finto/i})).toBeChecked();

    // Wait for the action to be processed
    await sleep(100);

    // Assert that the mock Finto response from msw can now be seen on screen
    expect(screen.getByText(/suomi/i)).toBeInTheDocument();

    // Click the button to add the Finto suggestion to the selected study
    userEvent.click(screen.getByRole('button', {name: /lisää kaikki ehdotetut tarkasteltavaan/i}));

    // Wait for the action to be processed
    await sleep(100);

    // Assert that the mock Finto response have been added to the selected
    expect(screen.getAllByText(/suomi/i)).toHaveLength(2);
  })

  test('Suggestion source can be changed', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that initially the option "Finto" is selected
    expect(screen.getByRole('option', {name: /finto/i})).toBeChecked();

    // Click the dropdown menu open and select the option Muissa aineistoissa by clicking it
    userEvent.click(screen.getAllByRole('combobox')[2]);
    userEvent.click(screen.getByRole('option', {name: /muissa valituissa aineistoissa/i}));

    // Assert that the option "Muissa aineistoissa" is now selected
    expect(screen.getByRole('option', {name: /muissa valituissa aineistoissa/i})).toBeChecked();

    // Wait for the action to be processed
    await sleep(100);
  })

  test('Variables can be marked as keyworded and unkeyworded', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('variables', ['Q00-FSD0115-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the button to mark the variable keyworded is rendered and click the button
    expect(screen.getByRole('button', {name: /merkitse valmiiksi/i})).toBeInTheDocument();
    userEvent.click(screen.getByRole('button', {name: /merkitse valmiiksi/i}));

    // Wait for the action to be processed
    await sleep(50);

    // Assert that the button to mark the variable keyworded is not rendered anymore
    expect(screen.queryByRole('button', {name: /merkitse valmiiksi/i})).not.toBeInTheDocument();

    // Assert that the button to mark the variable unkeyworded is rendered and click the button
    expect(screen.getByRole('button', {name: /merkitse keskeneräiseksi/i})).toBeInTheDocument();
    userEvent.click(screen.getByRole('button', {name: /merkitse keskeneräiseksi/i}));

    // Wait for the action to be processed
    await sleep(50);

    // Assert that the button to mark the variable unkeyworded is not rendered anymore
    expect(screen.queryByRole('button', {name: /merkitse keskeneräiseksi/i})).not.toBeInTheDocument();
  })

  test('Studies can be marked as keyworded and unkeyworded', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('studies', 'section', 1));

    // Wait for the data to be processed
    await sleep(100);

    store.dispatch(setInspection('studies', ['FSD00-fi']));

    render(
      <Provider store={store}>
        <InspectView />
      </Provider >
    );

    // Assert that the button to mark the variable keyworded is rendered and click the button
    expect(screen.getByRole('button', {name: /merkitse valmiiksi/i})).toBeInTheDocument();
    userEvent.click(screen.getByRole('button', {name: /merkitse valmiiksi/i}));

    // Wait for the action to be processed
    await sleep(100);

    // Assert that the button to mark the variable keyworded is not rendered anymore
    expect(screen.queryByRole('button', {name: /merkitse valmiiksi/i})).not.toBeInTheDocument();

    // Assert that the button to mark the variable unkeyworded is rendered and click the button
    expect(screen.getByRole('button', {name: /merkitse keskeneräiseksi/i})).toBeInTheDocument();
    userEvent.click(screen.getByRole('button', {name: /merkitse keskeneräiseksi/i}));

    // // Wait for the action to be processed
    await sleep(100);

    // Assert that the button to mark the variable unkeyworded is not rendered anymore
    expect(screen.queryByRole('button', {name: /merkitse keskeneräiseksi/i})).not.toBeInTheDocument();
  })
})
