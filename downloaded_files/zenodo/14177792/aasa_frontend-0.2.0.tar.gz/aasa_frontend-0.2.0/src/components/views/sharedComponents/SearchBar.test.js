import { render, screen } from '../../../test/test-utils';
import userEvent from '@testing-library/user-event';
import SearchBar from './SearchBar';

describe('SearchBar component', () => {
  const mockFunc = jest.fn();

  beforeEach(() => {
    render(<SearchBar view={'inspection'} newSearch={mockFunc} />);
  })

  test('Renders correctly', () => {
    expect(screen.getByRole('textbox')).toBeInTheDocument();
    expect(screen.getByText(/tarkennettu haku/i)).toBeInTheDocument();
  })

  test('Input field can be typed', () => {
    userEvent.type(screen.getByPlaceholderText(/haku/i), 'Test text');

    expect(screen.getByRole('textbox')).toHaveValue('Test text');
  })

  test('Pressing enter calls function', () => {
    userEvent.type(screen.getByPlaceholderText(/haku/i), '{enter}');

    expect(mockFunc).toBeCalledTimes(1);
  })
})
