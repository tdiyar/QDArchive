import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Dropdown, Button, Table } from 'semantic-ui-react';
import InspectionTable from './InspectionTable';
import { removeSelected, changeInspected, selectInspection } from '../../../store/inspection/inspectionActions';
import { selectDropdownOptions } from '../../../store/inspection/inspectionReducer';
import './InspectedItems.css';

export default function InspectedItems({ view, textInfo, headers, maxItems, maxLength }) {
  const dispatch = useDispatch();
  const dictionary = useSelector(state => state.global.dictionary);
  const itemDropdown = useSelector(state => selectDropdownOptions(state.inspection));
  const itemId = useSelector(state => state.inspection.inspectedItem);
  const inspectedItem = useSelector(state => state[view].items[itemId]);
  const selectedItemIds = useSelector(state => state.inspection.selected);
  const otherLanguageItems = useSelector(state => state.inspection.otherLanguageItems);
  const [currentIndex, setCurrentIndex] = useState(selectedItemIds.indexOf(itemId));
  const [itemLangToggled, setItemLangToggled] = useState(false);

  useEffect(() => {
    setCurrentIndex(selectedItemIds.indexOf(itemId));
  }, [itemId, selectedItemIds]);

  function deleteSelected() {
    dispatch(removeSelected());
    dispatch(changeInspected());
  }

  function handleChange(event, result) {
    event.preventDefault();
    dispatch(selectInspection(result.value))
  }

  function selectNext() {
    if (currentIndex < selectedItemIds.length - 1) {
      dispatch(selectInspection(selectedItemIds[currentIndex + 1]));
    }
  }

  function selectPrevious() {
    if (currentIndex > 0) {
      dispatch(selectInspection(selectedItemIds[currentIndex - 1]));
    }
  }

  function findAnotherLanguageVersion() {
    return Object.values(otherLanguageItems).find(item => inspectedItem.jointID.slice(0, -3) === item.jointID.slice(0, -3));
  }

  function changeLanguageVersion() {
    setItemLangToggled(!itemLangToggled);
  }

  return (
    <div>
      <h2>{textInfo}</h2>
      <div className='horizontal-divider' />
      <div className='selection-row'>
        <Dropdown
          search
          selection
          fluid
          options={itemDropdown}
          onChange={handleChange}
          value={inspectedItem.jointID}
        />
        <Button icon='chevron up' disabled={currentIndex === 0 ? true : false} onClick={selectPrevious} />
        <Button icon='chevron down' disabled={currentIndex === selectedItemIds.length - 1 ? true : false} onClick={selectNext} />
        <Button icon='delete' onClick={deleteSelected} />
      </div>
      <Table celled striped compact>
        <Table.Body>
          <Table.Row>
            <Table.Cell width='8'><b>{dictionary.languageID}</b></Table.Cell>
            <Table.Cell width='8' textAlign='center'>
              <b>
                {!itemLangToggled ? inspectedItem.language_id.toUpperCase() : findAnotherLanguageVersion().language_id.toUpperCase()}
              </b>
            </Table.Cell>
          </Table.Row>
          <Table.Row disabled={findAnotherLanguageVersion() ? false : true}>
            <Table.Cell width='8'><b>{dictionary.changeLanguageVersion}</b></Table.Cell>
            <Table.Cell width='8' textAlign='center'>
              <Button icon='exchange' onClick={changeLanguageVersion} disabled={findAnotherLanguageVersion() ? false : true} />
            </Table.Cell>
          </Table.Row>
        </Table.Body>
      </Table>
      <InspectionTable
        headers={headers}
        item={!itemLangToggled ? inspectedItem : findAnotherLanguageVersion()}
        otherLanguageItem={itemLangToggled ? inspectedItem : findAnotherLanguageVersion()}
        maxItems={maxItems}
        maxLength={maxLength}
      />
    </div>
  );
}
