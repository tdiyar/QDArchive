import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid } from 'semantic-ui-react';
import SearchBar from '../sharedComponents/SearchBar';
import SearchResults from '../sharedComponents/SearchResults';
import SelectionListing from '../sharedComponents/SelectionListing';
import LoadingButton from '../sharedComponents/LoadingButton';
import SearchOptions from '../sharedComponents/SearchOptions';
import { fetchData, resetResults } from '../../../store/items/itemActions';
import { resetInspection } from '../../../store/inspection/inspectionActions';

export default function StudiesView() {
  const dispatch = useDispatch();
  const dictionary = useSelector(state => state.global.dictionary);
  const inspectionType = useSelector(state => state.inspection.inspectionType);

  const tableHeaders = [
    {'key': 'title', 'name': `${dictionary.studyName}`, 'width': 5},
    {'key': 'idno', 'name': `${dictionary.studyId}`, 'width': 3},
    {'key': 'abstract', 'name': `${dictionary.abstract}`, 'width': 4},
    {'key': 'language_id', 'name': `${dictionary.languageID}`, 'width': 2}
  ];

  const inspectionHeaders = [
    {'key': 'idno', 'name': `${dictionary.studyId}`},
    {'key': 'language_id', 'name': `${dictionary.languageID}`},
    {'key': 'title', 'name': `${dictionary.studyName}`},
    {'key': 'abstract', 'name': `${dictionary.abstract}`},
    {'key': 'keyworded', 'name': `${dictionary.keyworded}`},
    {'key': 'user_terms', 'name': `${dictionary.keywords}`}
  ];

  function newSearch() {
    dispatch(resetResults('studies'));

    inspectionType === 'studies' && dispatch(resetInspection());

    for (let i = 1; i < 7; i++) {
      dispatch(fetchData('studies', 'section', i));
    }
  }

  function loadAll() {
    dispatch(fetchData('studies', 'all', 1, 1000));
  }

  return (
    <Grid columns={2}>
      <Grid.Column width={12}>
        <div className='row-flexbox'>
          <SearchBar view='studies' newSearch={newSearch} />
          <LoadingButton view='studies' text={dictionary.chooseAll} callFunc={() => loadAll()} />
        </div>
        <SearchOptions view='studies' onInput={newSearch} />
        <SearchResults
          tableHeaders={tableHeaders}
          view='studies'
          maxLength={60}
          maxItems={2}
          inspectionHeaders={inspectionHeaders}
          newSearch={newSearch}
        />
      </Grid.Column>
      <Grid.Column width={4}>
        <SelectionListing
          view='studies'
          heading={`${dictionary.selected} ${dictionary.studies}`}
          header={dictionary.study}
        />
      </Grid.Column>
    </Grid>
  );
}
