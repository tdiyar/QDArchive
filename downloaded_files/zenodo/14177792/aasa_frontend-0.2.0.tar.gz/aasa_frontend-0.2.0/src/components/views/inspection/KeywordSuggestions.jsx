import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Dropdown, Button } from 'semantic-ui-react';
import DragArea from './DragArea';
import { changeKeywordSource, fetchFintoSuggestions } from '../../../store/inspection/inspectionActions';
import { selectSuggestedKeywords } from '../../../store/inspection/inspectionReducer';
import { postTermsToItems } from '../../../store/items/itemActions';

export default function KeywordSuggestions({ view, textOtherItems, dragAttributes }) {
  const dispatch = useDispatch();
  const inspectedItem = useSelector(state => state.inspection.inspectedItem);
  const keywordSource = useSelector(state => state.inspection.keywordSource);
  const suggestedKeywords = useSelector(state => selectSuggestedKeywords(state, view));
  const suggestionsLoading = useSelector(state => state.inspection.suggestionsLoading);
  const dictionary = useSelector(state => state.global.dictionary);

  useEffect(() => {
    dispatch(fetchFintoSuggestions(view));
  }, [dispatch, view, inspectedItem]);

  function handleDropdownChange(event, result) {
    event.preventDefault();
    dispatch(changeKeywordSource(result.value));
    dispatch(fetchFintoSuggestions(view));
  }

  function addSuggestedTo(type) {
    dispatch(postTermsToItems(type, view));
  }

  const suggestionSources= [
    {'value': 'annif', 'text': 'Annif'},
    {'value': 'finto', 'text': 'Finto'},
    {'value': 'other', 'text': `${textOtherItems}`},
    {'value': 'tty', 'text': 'TTY'}
  ];

  return (
    <React.Fragment>
      <h3>{dictionary.suggestions}</h3>
      <Dropdown
        selection
        search
        fluid
        options={suggestionSources}
        onChange={handleDropdownChange}
        value={keywordSource}
      />
      <DragArea
        id='suggested'
        disableRemove={true}
        items={suggestedKeywords}
        emptyText={dictionary.noKeywords}
        loading={suggestionsLoading}
        {...dragAttributes}
      />
      <div className='button-container'>
        <Button onClick={() => {addSuggestedTo('inspected')}}>
          {dictionary.addSuggestedToInspected}
        </Button>
        <Button onClick={() => {addSuggestedTo('all')}}>
          {dictionary.addSuggestedToAll}
        </Button>
      </div>
    </React.Fragment>
  );
}
