import React, {useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Dropdown, Input, Button, Icon } from 'semantic-ui-react';
import DragArea from './DragArea';
import { changeVocabulary, changeKeywordInput, fetchKeywords } from '../../../store/inspection/inspectionActions';
import { postCustomTermToItems } from '../../../store/items/itemActions';
import { selectVocabularyOptions } from '../../../store/global/globalReducer';
import './KeywordSources.css';

export default function KeywordSources({ view, textSelection, dragAttributes }) {
  const dispatch = useDispatch();
  const vocabularies = useSelector(state => selectVocabularyOptions(state.global));
  const selectedVocabularyId = useSelector(state => state.inspection.keywordVocabulary);
  const keywordResults = [...useSelector(state => state.inspection.keywordResults)].sort((a,b) => {
    return a.id > b.id ? 1 : -1;
  });
  const loading = useSelector(state => state.inspection.loading);
  const searchValue = useSelector(state => state.inspection.keywordInput);
  const dictionary = useSelector(state => state.global.dictionary);
  const [timer, setTimer] = useState(null);

  function searchKeywords() {
    dispatch(fetchKeywords(selectedVocabularyId));
  }

  function handleChange(event, result) {
    event.preventDefault();
    dispatch(changeVocabulary(result.value));
  }

  function handleInput(event) {
    clearTimeout(timer);
    event.preventDefault();
    dispatch(changeKeywordInput(event.target.value));

    setTimer(setTimeout(() => {
      if (event.target.name === 'Search') {
        searchKeywords();
      }
    }, 500));
  }

  function addCustomKeyword(type) {
    dispatch(postCustomTermToItems(type, view));
  }

  return (
    <React.Fragment>
      <h2>{dictionary.keywordSources}</h2>
      <div className='horizontal-divider' />
      <Dropdown
        search
        selection
        fluid
        options={vocabularies}
        onChange={handleChange}
        value={selectedVocabularyId}
      />
      <Input
        placeholder={selectedVocabularyId !== 'Custom' ? dictionary.search : dictionary.keyword}
        name={selectedVocabularyId !== 'Custom' ? 'Search' : 'Keyword'}
        className='input-field'
        fluid
        size='large'
        onChange={handleInput}
        icon={selectedVocabularyId !== 'Custom' && <Icon name='search' circular link onClick={searchKeywords} />}
        value={searchValue}
      />
      { selectedVocabularyId !== 'Custom'
        ? <DragArea
            id='search'
            disableRemove={true}
            items={keywordResults}
            loading={loading}
            emptyText={textSelection && !loading ? dictionary.noSearchResults : ''}
            {...dragAttributes}
          />
        : <div className='button-container'>
            <Button onClick={() => {addCustomKeyword('inspected')}}>
              {dictionary.addToInspected}
            </Button>
            <Button onClick={() => {addCustomKeyword('all')}}>
              {dictionary.addToAllSelected}
            </Button>
          </div>
      }
    </React.Fragment>
  );
}
