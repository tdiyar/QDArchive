import React from 'react';
import { useSelector } from 'react-redux';
import { Loader } from 'semantic-ui-react';
import InspectionContainer from './InspectionContainer';

export default function InspectView() {
  const inspectionType = useSelector(state => state.inspection.inspectionType);
  const otherItemsLoading = useSelector(state => state.inspection.otherItemsLoading);
  const dictionary = useSelector(state => state.global.dictionary);

  const variableHeaders = [
    { key: 'name', name: `${dictionary.variableId}` },
    { key: 'study_idno', name: `${dictionary.studyId}` },
    { key: 'is_fielded', name: `${dictionary.fielded}` },
    { key: 'varGrp', name: `${dictionary.varGrp}` },
    { key: 'labl', name:  `${dictionary.labl}` },
    { key: 'preQTxt', name:  `${dictionary.preQTxt}` },
    { key: 'qstnLit', name: `${dictionary.qstnLit}` },
    { key: 'postQTxt', name: `${dictionary.postQTxt}` },
    { key: 'ivuInstr', name: `${dictionary.ivuInstr}` },
    { key: 'catValues', name: `${dictionary.catValuesList}` },
    { key: 'notes', name: `${dictionary.notes}` },
    { key: 'keyworded', name: `${dictionary.keyworded}` },
    { key: 'otherLangItem', name: `${dictionary.keywordsOfAnotherLanguageVersion}` }
  ];

  const studyHeaders = [
    { key: 'idno', name: `${dictionary.studyId}` },
    { key: 'title', name: `${dictionary.studyName}` },
    { key: 'abstract', name: `${dictionary.abstract}` },
    { key: 'keyworded', name: `${dictionary.keyworded}` },
    { key: 'otherLangItem', name: `${dictionary.keywordsOfAnotherLanguageVersion}` }
  ];

  if (inspectionType === null) {
    return <div><strong>{dictionary.nothingSelectedMessage}</strong></div>;
  }

  if (otherItemsLoading) {
    return <div style={{'marginTop': '8em'}}><Loader active inline='centered' size='massive'></Loader></div>;
  }

  return (
    <React.Fragment>
      <InspectionContainer
        view={inspectionType}
        headers={inspectionType === 'variables' ? variableHeaders : studyHeaders}
        textInfo={inspectionType === 'variables' ? dictionary.dataOfVariables : dictionary.dataOfStudies }
        textSelection={inspectionType === 'variables' ? dictionary.chooseVariable : dictionary.chooseStudy}
        textInspectedItem={inspectionType === 'variables' ? dictionary.variable : dictionary.study}
        textAllItems={inspectionType === 'variables' ? `${dictionary.all} ${dictionary.variables}` : `${dictionary.all} ${dictionary.studies}`}
        textOtherItems={inspectionType === 'variables' ? dictionary.inOtherVariables : dictionary.inOtherStudies}
        maxItems={inspectionType === 'variables' ? 2 : 4}
        maxLength={inspectionType === 'variables' ? 100 : 200}
      />
    </React.Fragment>
  );
}
