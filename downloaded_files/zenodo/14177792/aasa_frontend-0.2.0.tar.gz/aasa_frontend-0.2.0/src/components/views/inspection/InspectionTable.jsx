import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { List, Table } from 'semantic-ui-react';
import ExpandButton from './../sharedComponents/ExpandButton';
import './InspectionTable.css';

export default function InspectionTable({ headers, item, otherLanguageItem, maxItems, maxLength }) {
  const dictionary = useSelector(state => state.global.dictionary);
  const [expandedCells, setExpandedCells] = useState([]);

  function toggleExpand(headerKey) {
    if (expandedCells.includes(headerKey)) {
      setExpandedCells(expandedCells.filter((key) => key !== headerKey));
    }
    else {
      setExpandedCells(expandedCells => [...expandedCells, headerKey]);
    }
  }

  function isExpanded(headerKey) {
    return expandedCells.find(key => key === headerKey);
  }

  // Create an element that can be expanded with a click of a button
  function createExpandCell(value, expanded, toggleFunction) {
    return (
      <div className='expand-cell'>
        { value }
        <div>
          <ExpandButton expanded={expanded} callFunc={toggleFunction} />
        </div>
      </div>
    );
  }

  // Create a bulleted list from an array of values
  function createList(value, expanded, toggleFunction) {
    let itemArray = value.map(itemObj =>
      <List.Item key={itemObj.catValu}>{itemObj.catValu} - {itemObj.catLabl}</List.Item>
    );

    if (value.length > maxItems) {
      if (!expanded) {
        itemArray.splice(maxItems);
        itemArray = [...itemArray, <List.Item key={'...'}>{'...'}</List.Item>];
      }

      const itemList = <List bulleted>{itemArray}</List>;
      return createExpandCell(itemList, expanded, toggleFunction);
    }

    return <List bulleted>{itemArray}</List>;
  }

  // Create a table cell based on the content and type of value
  function createCell(value, expanded, toggleFunction) {
    if (typeof value === 'boolean') return value ? dictionary.yes : dictionary.no;
    if (!value || value.length === 0) return '-';
    if (Array.isArray(value)) return createList(value, expanded, toggleFunction);

    if (value.length > maxLength) {
      if (!expanded) {
        value = `${value.substring(0, maxLength - 3)}...`;
      }
      return createExpandCell(value, expanded, toggleFunction);
    }

    return value;
  }

  function createOtherKeywordsCell() {
    if (!otherLanguageItem) return `${dictionary.anotherVersionNotFound}`;
    if (otherLanguageItem.user_terms.length === 0) return '-';

    const otherLangKeywords = otherLanguageItem.user_terms.map(term => `${term.vocab}-${term.value}`);

    return otherLangKeywords.join(', ');
  }

  function populateCell(headerKey) {
    if (headerKey !== 'otherLangItem') return createCell(item[headerKey], isExpanded(headerKey), () => toggleExpand(headerKey));

    return createOtherKeywordsCell();
  }

  // Map through the headers and return a table populated with values from item based on keys of headers
  const rows = headers.map(header =>
    <Table.Row key={header.key}>
      <Table.Cell><b>{header.name}</b></Table.Cell>
      <Table.Cell>
        { populateCell(header.key) }
      </Table.Cell>
    </Table.Row>
  );

  return (
    <Table celled striped compact>
      <Table.Body>
        { rows }
      </Table.Body>
    </Table>
  );
}
