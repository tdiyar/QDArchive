import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { sleep } from '../../../test/test-utils';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { toggleSearchActive } from '../../../store/items/itemActions';
import SearchOptions from './SearchOptions';

describe('SearchOptions component', () => {
  const mockFunc = jest.fn();

  test('Renders correctly', () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(toggleSearchActive('variables'));

    render(
      <Provider store={store}>
        <SearchOptions view={'variables'} onInput={mockFunc} />
      </Provider >
    );

    // Assert that the correct elements are rendered on screen
    expect(screen.getByRole('heading', {name: /tarkennettu haku/i})).toBeInTheDocument();
    expect(screen.getByRole('button', {name: /tyhjennä hakuvalinnat/i})).toBeInTheDocument();
    expect(screen.getAllByRole('button')).toHaveLength(2);
  })

  test('New filtters can be added and removed', () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(toggleSearchActive('variables'));

    render(
      <Provider store={store}>
        <SearchOptions view={'variables'} onInput={mockFunc} />
      </Provider >
    );

    // Click the rendered button to add a filter
    userEvent.click(screen.getAllByRole('button')[1]);

    // Assert that correct elements are now rendered on screen
    expect(screen.getAllByRole('button')).toHaveLength(3);
    expect(screen.getByRole('combobox')).toBeInTheDocument();
    expect(screen.getAllByRole('textbox')).toHaveLength(2);
    expect(screen.getAllByRole('option')).toHaveLength(13);
    expect(screen.getByRole('option', {name: /kysymysteksti/i})).toBeChecked();

    // Click the third button on the screen to add new filter
    userEvent.click(screen.getAllByRole('button')[2]);

    // Assert that a filter has been added and it is selected
    expect(screen.getByRole('option', {name: /kysymysryhmän esiteksti/i})).toBeChecked();

    // Click the fourth button on the screen to add new filter
    userEvent.click(screen.getAllByRole('button')[3]);

    // Assert that a filter has been added and it is selected
    expect(screen.getByRole('option', {name: /muuttujan selite/i})).toBeChecked();

    // Click the third button on the screen to remove a filter
    userEvent.click(screen.getAllByRole('button')[2]);

    // Assert that the correct filter has been selected
    expect(screen.getAllByRole('option', {name: /kysymysryhmän esiteksti/i})[0]).not.toBeChecked();

    // Assert that the function has been called after the filtter was removed
    expect(mockFunc).toHaveBeenCalledTimes(1);
  })

  test('Filter can be given a value and search will be triggered after timer has ran', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(toggleSearchActive('variables'));

    render(
      <Provider store={store}>
        <SearchOptions view={'variables'} onInput={mockFunc} />
      </Provider >
    );

    // Click the rendered X button to add a filter
    userEvent.click(screen.getAllByRole('button')[1]);

    // Assert that input field is initially empty
    expect(screen.getAllByRole('textbox')[1]).toHaveValue('');

    // Input text to the input field and assert that the value has changed
    userEvent.type(screen.getAllByRole('textbox')[1], 'Test text');
    expect(screen.getAllByRole('textbox')[1]).toHaveValue('Test text');

    // Wait until the timer runs and assert that the function has been called after the timer
    await sleep(500);
    expect(mockFunc).toHaveBeenCalledTimes(1);
  })

  test('Filter can be changed', () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(toggleSearchActive('variables'));

    render(
      <Provider store={store}>
        <SearchOptions view={'variables'} onInput={mockFunc} />
      </Provider >
    );

    // Click the rendered X button to add a filter
    userEvent.click(screen.getAllByRole('button')[1]);

    // Click on the rendered combobox
    userEvent.click(screen.getByRole('combobox'));

    // Assert that the initial filter value "Kysymysteksti" has been selected
    expect(screen.getByRole('option', {name: /kysymysteksti/i})).toBeChecked();

    // Assert that the "Aineistonumero" filter has not been selected
    expect(screen.getByRole('option', {name: /aineistonumero/i})).not.toBeChecked();

    // Click on the option "Aineistonumero"
    userEvent.click(screen.getByRole('option', {name: /aineistonumero/i}));

    // Assert that the "Aineistonumero" filter has been selected
    expect(screen.getByRole('option', {name: /aineistonumero/i})).toBeChecked();

    // Assert that the initial filter value "Kysymysteksti" is not selected anymore
    expect(screen.getByRole('option', {name: /kysymysteksti/i})).not.toBeChecked();

    // Assert that the function has been called after the filtter was changed
    expect(mockFunc).toHaveBeenCalledTimes(1);
  })
})
