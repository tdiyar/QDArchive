import { setupServer } from 'msw/node';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { handlers } from '../../../test/mockRoutes';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { fetchData, addSelected } from '../../../store/items/itemActions';
import SelectionListing from './SelectionListing';

describe('SelectionListing component', () => {
  const server = setupServer(...handlers);

  // Establish API mocking before all tests
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
  })

  // Reset request handlers
  afterEach(() => {
    server.resetHandlers();
  })

  // Clean up once the tests are done
  afterAll(() => {
    server.close();
  })

  test('Renders correctly without selected items', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));

    render(
      <Provider store={store}>
        <SelectionListing
          view={'variables'}
          heading={'Valitut muuttujat'}
          header={'Muuttuja'}
        />
      </Provider >
    );

    // Assert that correct elements with correct content are rendered on screen
    expect(screen.getByRole('heading', {name: /valitut muuttujat/i})).toBeInTheDocument();
    expect(screen.getByText(/0 kappaletta valittu/i)).toBeInTheDocument();
  })

  test('Renders correctly with two selected items', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));
    store.dispatch(addSelected('variables', 'Q1-FSD0115-fi' , 0));
    store.dispatch(addSelected('variables', 'Q12C-FSD0115-fi' , 1));

    render(
      <Provider store={store}>
        <SelectionListing
          view={'variables'}
          heading={'Valitut muuttujat'}
          header={'Muuttuja'}
        />
      </Provider >
    );

    // Assert that correct text is rendered on screen
    expect(screen.getByText(/2 kappaletta valittu/i)).toBeInTheDocument();

    // Assert that correct items have been selected
    expect(screen.getByRole('cell', {name: /q1-fsd0115-fi/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /q12c-fsd0115-fi/i})).toBeInTheDocument();
  })

  test('Selected items can be removed', async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));
    store.dispatch(addSelected('variables', 'Q1-FSD0115-fi' , 0));
    store.dispatch(addSelected('variables', 'Q12C-FSD0115-fi' , 1));
    store.dispatch(addSelected('variables', 'FSD_ID-FSD0115-fi' , 1));

    render(
      <Provider store={store}>
        <SelectionListing
          view={'variables'}
          heading={'Valitut muuttujat'}
          header={'Muuttuja'}
        />
      </Provider >
    );

    // Assert that 3 correct items have been selected
    expect(screen.getByText(/3 kappaletta valittu/i)).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /q1-fsd0115-fi/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /q12c-fsd0115-fi/i})).toBeInTheDocument();
    expect(screen.getByRole('cell', {name: /fsd_id-fsd0115-fi/i})).toBeInTheDocument();

    // Find the last selected item and click the remove button within the row
    const lastSelectedRow = screen.getAllByRole('row')[3];
    userEvent.click(within(lastSelectedRow).getByRole('button'));

    // Assert that the last selected item has been removed
    expect(screen.getByText(/2 kappaletta valittu/i)).toBeInTheDocument();
    expect(screen.queryByRole('cell', {name: /fsd_id-fsd0115-fi/i})).not.toBeInTheDocument();

    // Click the button "Tyhjenä valinta" to remove all selected
    userEvent.click(screen.getByRole('button', {name: /tyhjennä valinta/i}));

    // Assert that all selected items have been removed
    expect(screen.getByText(/0 kappaletta valittu/i)).toBeInTheDocument();
    expect(screen.queryByRole('cell', {name: /q1-fsd0115-fi/i})).not.toBeInTheDocument();
    expect(screen.queryByRole('cell', {name: /q12c-fsd0115-fi/i})).not.toBeInTheDocument();
  })
})
