import { setupServer } from 'msw/node';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { sleep } from '../../../test/test-utils';
import { handlers } from '../../../test/mockRoutes';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { fetchData } from '../../../store/items/itemActions';
import { tableHeaders, inspectionHeaders } from '../../../test/mockData/variableMockHeaders';
import SearchResults from './SearchResults';

describe('SearchResults component', () => {
  const server = setupServer(...handlers);

  // Establish API mocking before all tests
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
  })

  // For each test, create a store, preload data to store and render the component within provider
  beforeEach(async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('variables', 'section', 1));
    store.dispatch(fetchData('variables', 'section', 2));
    const mockFunc = jest.fn();

    render(
      <Provider store={store}>
        <SearchResults
          view={'variables'}
          tableHeaders={tableHeaders}
          inspectionHeaders={inspectionHeaders}
          newSearch={mockFunc}
        />
      </Provider >
    );
  })

  // Reset request handlers
  afterEach(() => {
    server.resetHandlers();
  })

  // Clean up once the tests are done
  afterAll(() => {
    server.close();
  })

  test('Renders correctly', async () => {
    await sleep(200);

    // Assert that the data has been loaded
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Assert that the correct elements have been rendered
    expect(screen.getByRole('table')).toBeInTheDocument();
    expect(screen.getAllByRole('columnheader')).toHaveLength(6);
    expect(screen.getAllByRole('cell')).toHaveLength(90);
    expect(screen.getAllByRole('checkbox')).toHaveLength(15);
    expect(screen.getAllByRole('row')).toHaveLength(16);
    expect(screen.getAllByRole('button')).toHaveLength(30);
    expect(screen.getByRole('navigation')).toBeInTheDocument();
  })

  test('Rows can be expanded', async () => {
    // Await for the data to load and assert that the data is loaded
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Assert that the amount of rows is correct
    expect(screen.getAllByRole('row')).toHaveLength(16);

    // Find the first data row and click the expand button
    const firstDataRow = screen.getAllByRole('row')[1];
    userEvent.click(within(firstDataRow).getAllByRole('button')[1]);

    // Assert that a new row has been added to view
    expect(screen.getAllByRole('row')).toHaveLength(17);

    // Assert that the contents of expanded row are on the screen
    expect(screen.getByText(/muuttujan id:/i)).toBeInTheDocument();
    expect(screen.getByText(/aineiston id:/i)).toBeInTheDocument();
    expect(screen.getByText(/muuttujaryhmän teksti:/i)).toBeInTheDocument();
    expect(screen.getByText(/nimike:/i)).toBeInTheDocument();
    expect(screen.getByText(/esikysymys:/i)).toBeInTheDocument();
    expect(screen.getByText(/kysymysliteraali:/i)).toBeInTheDocument();
    expect(screen.getByText(/jälkikysymys:/i)).toBeInTheDocument();
    expect(screen.getByText(/haastattelijan ohjeet:/i)).toBeInTheDocument();
    expect(screen.getByText(/vastausvaihtoehdot:/i)).toBeInTheDocument();
    expect(screen.getByText(/muistiinpanot:/i)).toBeInTheDocument();
    expect(screen.getByText(/asiasanoitettu:/i)).toBeInTheDocument();
    expect(screen.getByText(/asiasanat:/i)).toBeInTheDocument();

    // Find the second unexpanded data row and click the expand button
    const secondDataRow = screen.getAllByRole('row')[3];
    userEvent.click(within(secondDataRow).getAllByRole('button')[1]);

    // Assert that a new row has been added to view
    expect(screen.getAllByRole('row')).toHaveLength(18);

    // Click the expand button again in the secod data row
    userEvent.click(within(secondDataRow).getAllByRole('button')[1]);

    // Assert that the row is no more expanded
    expect(screen.getAllByRole('row')).toHaveLength(17);
  })

  test('Header row cells can be clicked to change the sorting', async () => {
    // Assert that on render the fifth columnheader is used for ascending sorting
    expect(screen.getAllByRole('columnheader')[4]).toHaveClass('ascending');
    expect(screen.getAllByRole('columnheader')[4]).toHaveClass('sorted');

    // Click the third columnheader to change sorting
    userEvent.click(screen.getAllByRole('columnheader')[2]);

    // Assert the third columnheader is now used for ascending sorting
    expect(screen.getAllByRole('columnheader')[2]).toHaveClass('ascending');
    expect(screen.getAllByRole('columnheader')[2]).toHaveClass('sorted');

    // Click the third columnheader to change sorting order
    userEvent.click(screen.getAllByRole('columnheader')[2]);

    // Assert that the third columnheader is now used for descending sorting
    expect(screen.getAllByRole('columnheader')[2]).toHaveClass('descending');
  })

  test('Pagination items can be clicked to change the active page', async () => {
    // Await for the data to load and assert that the data is loaded
    expect(await screen.findByText(/q00/i)).toBeInTheDocument();

    // Select the pagination element from the screen
    const pagination = screen.getByRole('navigation', {  name: /pagination navigation/i});

    // Assert that the first page is active item and the second page is not active item
    expect(within(pagination).getByText(/1/i)).toHaveClass('active');
    expect(within(pagination).getByText(/2/i)).not.toHaveClass('active');

    // Click the second page
    userEvent.click(within(pagination).getByText(/2/i));

    // Assert that the first page is not active item and the second page is active item
    expect(within(pagination).getByText(/1/i)).not.toHaveClass('active');
    expect(within(pagination).getByText(/2/i)).toHaveClass('active');
  })
})
