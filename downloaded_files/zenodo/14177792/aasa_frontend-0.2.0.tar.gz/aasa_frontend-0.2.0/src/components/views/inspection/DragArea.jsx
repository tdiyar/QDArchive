import React from 'react';
import { Icon, Loader, Segment } from 'semantic-ui-react';
import DraggableLabel from './DraggableLabel';

export default function DragArea(props) {
  function dragOver(event) {
    if (props.dragOverAccept(props.id)) {
      event.preventDefault();
    }
  }

  const style = {
    'maxHeight': props.height ? props.height : '14em',
    'minHeight': '8em',
    'width':'100%',
    'display': 'flex',
    'flexDirection': 'row',
    'flexWrap': 'wrap',
    'overflowY': 'scroll'
  };

  const labels = props.items.map((item) =>
    <DraggableLabel key={item.id} onDragStart={() => props.dragStart(props.id, item)}>
      {item.vocab}-{item.value}{item.removed ? ' (R)': null}{item.deprecated ? ' (D)': null}
      {!props.disableRemove && <Icon onClick={() => props.remove(props.id, item)} name='delete' />}
    </DraggableLabel>
  )

  if (props.loading) {
    return <Segment style={style}><Loader active/></Segment>;
  }

  return (
    <React.Fragment>
      <Segment style={style} onDrop={() => props.drop(props.id)} onDragOver={(event) => dragOver(event)}>
        { props.items.length === 0
          ? <p style={{'opacity': '0.6'}}>{props.emptyText}</p>
          : labels
        }
      </Segment>
    </React.Fragment>
  );
}
