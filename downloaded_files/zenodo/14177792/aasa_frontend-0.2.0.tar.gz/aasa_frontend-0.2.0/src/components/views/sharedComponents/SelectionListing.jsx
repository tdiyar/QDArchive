import React from 'react';
import { useHistory } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Table } from 'semantic-ui-react';
import { setInspection, fetchOtherLanguageItems } from '../../../store/inspection/inspectionActions';
import { removeSelected, removeAllSelected } from '../../../store/items/itemActions';
import './SelectionListing.css';

export default function SelectionListing({view, heading, header}) {
  const dispatch = useDispatch();
  const history = useHistory();
  const selected = useSelector(state => state[view].selected);
  const dataLanguage = useSelector(state => state.global.languageID);
  const dictionary = useSelector(state => state.global.dictionary);

  function startInspection() {
    dispatch(setInspection(view, selected, dataLanguage));
    dispatch(fetchOtherLanguageItems(view));
    history.push('/inspect');
  }

  const maxResults = 30;

  const rows = selected.slice(0, maxResults).map(item => {
    return (
      <Table.Row key={item}>
        <Table.Cell>
          {item}
          <Button
            icon='close'
            size='mini'
            onClick={() => {dispatch(removeSelected(view, item))}}
          />
        </Table.Cell>
      </Table.Row>
    );
  });

  return (
    <React.Fragment>
      <h2>{heading}</h2>
      <p className='selection-info'>
        {selected.length} {selected.length === 1
          ? `${dictionary.object}`
          : `${dictionary.objects}`} {dictionary.chosen}
      </p>
      { selected.length > 0
        ? <div>
            <div className='selection-buttons'>
              <Button onClick={startInspection}>
                {dictionary.inspect}
              </Button>
              <Button onClick={() => {dispatch(removeAllSelected(view))}}>
                {dictionary.clearSelection}
              </Button>
            </div>
            <div className='selection-table'>
              <Table>
                <Table.Header>
                  <Table.Row>
                    <Table.HeaderCell className='capitalized'>
                      {header}
                    </Table.HeaderCell>
                  </Table.Row>
                </Table.Header>
                <Table.Body>
                  {rows}
                </Table.Body>
              </Table>
            </div>
          </div>
        : null
      }
    </React.Fragment>
  );
}
