import { render, screen } from '../../../test/test-utils';
import userEvent from '@testing-library/user-event';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { toggleSearchActive } from '../../../store/items/itemActions';
import LoadingButton from './LoadingButton';
import SearchOptions from './SearchOptions';

describe('LoadingButton component', () => {
  const callFunc = jest.fn();
  const inputFunc = jest.fn();

  test('Renders correctly', () => {
    render(<LoadingButton view={'variables'} text={'Valitse kaikki'} callFunc={callFunc} />);

    expect(screen.getByRole('button')).toBeInTheDocument();
    expect(screen.getByText(/valitse/i)).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  })

  test('After button is not disabled, click will fire function', () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(toggleSearchActive('variables'));

    render(
      <Provider store={store}>
        <LoadingButton view={'variables'} text={'Valitse kaikki'} callFunc={callFunc} />
        <SearchOptions view={'variables'} onInput={inputFunc} />
      </Provider>
    );

    // Assert that initially the LoadingButton is disabled and the function can not be called
    userEvent.click(screen.getAllByRole('button')[0]);
    expect(callFunc).toBeCalledTimes(0);

    // Click the X-button to add filter row
    userEvent.click(screen.getAllByRole('button')[2]);

    // Select the input field of the added filter and type text to activate the "Valitse kaikki" button
    const filterInput = document.querySelector('.filter-input > input');
    userEvent.type(filterInput, 'test input');

    // Assert that the LoadingButton is no longer disabled
    expect(screen.getAllByRole('button')[0]).not.toBeDisabled();

    // Click the Loading button and assert that the function has been called
    userEvent.click(screen.getAllByRole('button')[0]);
    expect(callFunc).toBeCalledTimes(1);
  })
})
