import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Grid } from 'semantic-ui-react';
import InspectedItems from './InspectedItems';
import ItemKeywords from './ItemKeywords';
import KeywordSources from './KeywordSources';
import KeywordSuggestions from './KeywordSuggestions';
import { postTermsToItems, deleteTermFromItems } from '../../../store/items/itemActions';
import './InspectionContainer.css';

export default function InspectionContainer(props) {
  const dispatch = useDispatch();
  const [dragSource, setDragSource] = useState(null);
  const [dragItem, setDragItem] = useState(null);

  function dragStart(source, item) {
    setDragSource(source);
    setDragItem(item);
  }

  // Accept dragOver if the start and end locations differ and end location is one of the accepted areas
  function dragOverAccept(location) {
    return dragSource !== location && (location === 'all-keywords' || location === 'selected');
  }

  function drop(location) {
    if (location === 'selected') {
      dispatch(postTermsToItems('inspected', props.view, [dragItem]));
    }
    else if (location === 'all-keywords') {
      dispatch(postTermsToItems('all', props.view, [dragItem]));
    }
  }

  function remove(source, keyword) {
    if (source === 'selected') {
      dispatch(deleteTermFromItems('inspected', keyword, props.view));
    }
    else if (source === 'all-keywords' || source === 'other') {
      dispatch(deleteTermFromItems('all', keyword, props.view));
    }
  }

  const dragAttributes = {
    dragOverAccept: (location) => dragOverAccept(location),
    dragSource: dragSource,
    drop: (location) => drop(location),
    dragStart: (source, item) => dragStart(source, item),
    remove: (source, item) => remove(source, item)
  };

  return (
    <Grid stackable columns={3} divided>
      <Grid.Column>
        <InspectedItems
          view={props.view}
          textInfo={props.textInfo}
          headers={props.headers}
          maxItems={props.maxItems}
          maxLength={props.maxLength}
        />
      </Grid.Column>
      <Grid.Column>
        <ItemKeywords
          view={props.view}
          textInspectedItem={props.textInspectedItem}
          dragAttributes={dragAttributes}
          textAllItems={props.textAllItems}
        />
      </Grid.Column>
      <Grid.Column>
        <KeywordSources
          view={props.view}
          textSelection={props.textSelection}
          dragAttributes={dragAttributes}
        />
        <KeywordSuggestions
          view={props.view}
          textOtherItems={props.textOtherItems}
          dragAttributes={dragAttributes}
        />
      </Grid.Column>
    </Grid>
  );
}
