import { render, screen } from '../../../test/test-utils';
import userEvent from '@testing-library/user-event';
import ExpandButton from './ExpandButton';

describe('ExpandButton component', () => {
  const callFunc = jest.fn();

  test('Renders correctly with caret down', () => {
    render(<ExpandButton expanded={false} callFunc={callFunc} />);

    expect(screen.getByRole('button')).toBeInTheDocument();
    expect(screen.getByRole('button').firstElementChild).toHaveClass('caret down icon');
  })

  test('Renders correctly with caret up', () => {
    render(<ExpandButton expanded={true} callFunc={callFunc} />);

    expect(screen.getByRole('button')).toBeInTheDocument();
    expect(screen.getByRole('button').firstElementChild).toHaveClass('caret up icon');
  })

  test('Click will fire function', () => {
    render(<ExpandButton expanded={false} callFunc={callFunc} />);

    userEvent.click(screen.getByRole('button'));
    expect(callFunc).toBeCalledTimes(1);
  })
})
