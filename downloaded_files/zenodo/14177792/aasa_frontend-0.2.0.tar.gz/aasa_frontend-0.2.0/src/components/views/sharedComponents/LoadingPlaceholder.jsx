import React from 'react';
import { Checkbox, Placeholder, Table } from 'semantic-ui-react';

export default function LoadingPlaceHolder({ tableHeaders }) {
  // Create a placeholder row with as many cells as there are headers
  const placeholderRow = tableHeaders.map((field, index) => {
    return (
      <Table.Cell key={index}>
        <Placeholder>
          <Placeholder.Line length='full' />
        </Placeholder>
      </Table.Cell>
    );
  })

  // Create 15 placeholder rows to show during the loading of data
  const holderRows = [...Array(15).keys()].map((value, index) => {
    return (
      <Table.Row role='status' key={index}>
        <Table.Cell>
          <Checkbox disabled/>
        </Table.Cell>
        { placeholderRow }
      </Table.Row>
    );
  })

  return (
    <React.Fragment>
      { holderRows }
    </React.Fragment>
  );
}
