import { setupServer } from 'msw/node';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { sleep } from '../../../test/test-utils';
import { handlers } from '../../../test/mockRoutes';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import rootReducer from '../../../store/rootReducer';
import { fetchData } from '../../../store/items/itemActions';
import KeywordsView from './KeywordsView';

describe('StudiesView component', () => {
  const server = setupServer(...handlers);

  // Establish API mocking before all tests
  beforeAll(() => {
    server.listen({ onUnhandledRequest: 'error' });
  })

  // For each test, create a store, preload data to store and render the component within provider
  beforeEach(async () => {
    const store = createStore(rootReducer, applyMiddleware(thunk));
    store.dispatch(fetchData('keywords', 'section', 1));

    render(
      <Provider store={store}>
        <KeywordsView />
      </Provider >
    );
  })

  // Reset request handlers
  afterEach(() => {
    server.resetHandlers();
  })

  // Clean up once the tests are done
  afterAll(() => {
    server.close();
  })

  test('Renders correctly', async () => {
     // Correct elements are rendered
     expect(screen.getByRole('textbox')).toBeInTheDocument();
     expect(screen.getAllByRole('button')).toHaveLength(1);
     expect(screen.getByRole('table')).toBeInTheDocument();
     expect(screen.getAllByRole('columnheader')).toHaveLength(4);
     expect(screen.getAllByRole('checkbox')).toHaveLength(15);
     expect(screen.getByRole('navigation')).toBeInTheDocument();

     // Placeholder rows are shown while the data is loading
    expect(screen.getAllByRole('status')).toHaveLength(15);

    await sleep(200);

    // After data has been loaded the placeholder rows are not shown anymore and there is more buttons
    expect(screen.queryAllByRole('status')).toHaveLength(0);
    expect(screen.getAllByRole('button')).toHaveLength(16);
  })

  test('New search can be triggered and data is loaded', async () => {
    userEvent.type(screen.getByPlaceholderText(/haku/i), '{enter}');

    // Placeholder rows are shown while data is loading
    expect(screen.getAllByRole('status')).toHaveLength(15);

    // After data has been loaded, first actual data row is shown and the placeholder rows are not shown anymore
    const firstKeywordCells = await screen.findAllByText(/0-0/i);
    expect(firstKeywordCells).toHaveLength(1);
    expect(screen.queryAllByRole('status')).toHaveLength(0);
  })
})
