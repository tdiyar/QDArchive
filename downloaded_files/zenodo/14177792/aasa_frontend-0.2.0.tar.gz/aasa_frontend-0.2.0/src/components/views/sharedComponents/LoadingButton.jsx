import React from 'react';
import { Button } from 'semantic-ui-react';
import { useSelector } from 'react-redux';
import { selectFiltersStatus } from '../../../store/items/itemReducer';

export default function LoadingButton({ view, text, callFunc }) {
  const loading = useSelector(state => state[view].selectLoading);
  const valueInFilters = useSelector(state => selectFiltersStatus(state[view]));
  const lastQuery = useSelector(state => state[view].lastQuery);

  return (
    <Button
      disabled={(!valueInFilters && !lastQuery.includes('search')) ? true : false}
      className={loading ? 'loading disabled' : null}
      size='large'
      content={text}
      onClick={callFunc}
    />
  );
}
