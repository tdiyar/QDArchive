import React from 'react';
import { Button } from 'semantic-ui-react';

export default function ExpandButton({ expanded, callFunc }) {
  return (
    <Button compact icon={expanded ? 'caret up' : 'caret down'} size={'mini'} onClick={callFunc} />
  );
}
