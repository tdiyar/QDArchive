import * as constants from './inspectionConstants';
import { addError } from '../global/globalActions';
import { addKeywordToItems } from '../items/itemActions';
import { selectItemsKeywords } from '../items/itemReducer';
import { createKeywordQuery, createKeywordObject, callBackend, addNewProperties } from '../utils/helperFunctions';
import * as routes from '../utils/apiRoutes';

// ------------- ACTION CREATORS ------------- //
export function setInspection(view, selected, dataLanguage) {
  return {
    type: constants.SET_INSPECTION,
    inspectionType: view,
    selected: selected,
    languageID: dataLanguage
  }
}

export function removeSelected() {
  return {
    type: constants.REMOVE_SELECTED
  }
}

export function changeInspected() {
  return {
    type: constants.CHANGE_INSPECTED
  }
}

export function resetInspection() {
  return {
    type: constants.RESET_INSPECTION
  }
}

export function resetKeywordVocabulary(languageID) {
  return {
    type: constants.RESET_KEYWORD_VOCABULARY,
    languageID
  }
}

export function selectInspection(selected) {
  return {
    type: constants.SELECT_INSPECTION,
    selected
  }
}

export function changeVocabulary(vocabulary) {
  return {
    type: constants.CHANGE_VOCABULARY,
    vocabulary
  }
}

export function changeKeywordSource(keywordSource) {
  return {
    type: constants.CHANGE_KEYWORD_SOURCE,
    keywordSource
  }
}

export function changeKeywordInput(text) {
  return {
    type: constants.CHANGE_KEYWORD_INPUT,
    text
  }
}

export function changeQuery(query) {
  return {
    type: constants.CHANGE_QUERY,
    query
  }
}

export function startLoading() {
  return {
    type: constants.START_LOADING
  }
}

export function fetchKeywordsSuccess(keywords) {
  return {
    type: constants.FETCH_KEYWORDS_SUCCESS,
    keywords
  }
}

export function fetchKeywordsFailure() {
  return {
    type: constants.FETCH_KEYWORDS_FAILURE
  }
}

export function startLoadingSuggestions() {
  return {
    type: constants.START_LOADING_SUGGESTIONS
  }
}

export function fetchSuggestionsSuccess(suggestions) {
  return {
    type: constants.FETCH_SUGGESTIONS_SUCCESS,
    suggestions
  }
}

export function fetchSuggestionsFailure() {
  return {
    type: constants.FETCH_SUGGESTIONS_FAILURE
  }
}

export function incrementPendingRequests() {
  return {
    type: constants.INCREMENT_PENDING_REQUESTS
  }
}

export function decrementPendingRequests() {
  return {
    type: constants.DECREMENT_PENDING_REQUESTS
  }
}

export function startLoadingOtherItems() {
  return {
    type: constants.START_LOADING_OTHER_ITEMS
  }
}

export function otherItemsFetchSuccess(view, items) {
  return {
    type: constants.OTHER_ITEMS_FETCH_SUCCESS,
    view,
    items
  }
}

export function otherItemsFetchFailure() {
  return {
    type: constants.OTHER_ITEMS_FETCH_FAILURE
  }
}

// ------------------- THUNKS ------------------- //
/**
 * Fetch keywords of target vocabulary from backend
 * @param {String} vocabularyId The ID of the target vocabulary
 * @param {Number} maxResults Amount of keywords to fetch (defaults to 10)
 */
export function fetchKeywords(vocabularyId, maxResults = 10) {
  return async (dispatch, getState) => {
    dispatch(startLoading());

    try {
      const searchValue = getState().inspection.keywordInput;
      const vocabularies = getState().global.vocabularies;
      const vocabulary = vocabularies.find(vocab => vocab.id === vocabularyId);

      const query = createKeywordQuery(maxResults, vocabulary, searchValue);
      dispatch(changeQuery(query));

      const response = await fetch(query);

      if (!response.ok) {
        throw new Error(`Tila: ${response.status}. URL: ${response.url}`);
      }

      const responseJson = await response.json();
      dispatch(fetchKeywordsSuccess(responseJson.data));
    }
    catch (error) {
      dispatch(fetchKeywordsFailure());
      dispatch(addError(`Tapahtui odottamaton virhe. ${error.message}`));
    }
  }
}

/**
 * Fetch keyword suggestions for inspected item from Finto via backend
 * @param {String} view Information whether the function is targeting variables or studies
 */
export function fetchFintoSuggestions(view) {
  return async (dispatch, getState) => {
    const state = getState();
    const itemID = state.inspection.inspectedItem;
    const item = state[view].items[itemID];

    const fintoKeywords = selectItemsKeywords(state[view], itemID, 'finto');

    // Skip the fetch if keywords have already been loaded from Finto for inspected item
    if (state.inspection.keywordSource === 'finto' && fintoKeywords.length === 0) {
      dispatch(startLoadingSuggestions());

      try {
        const response = await fetch(`${routes[view]}/${item.id}/finto-suggestions`);

        if (!response.ok) {
          throw new Error(`Tila: ${response.status}. URL: ${response.url}`);
        }

        const suggestions = await response.json();

        suggestions.forEach((result) => {
          const keyword = createKeywordObject(result);
          dispatch(addKeywordToItems(view, keyword, [itemID], 'finto'));
        });

        dispatch(fetchSuggestionsSuccess());
      }
      catch (error) {
        dispatch(fetchSuggestionsFailure());
        dispatch(addError(`Tapahtui odottamaton virhe. ${error.message}`));
      }
    }
  }
}

/**
 * Fetch other language version of the items selected for inspection
 * @param {String} view Information whether the function is targeting variables or studies
 */
export function fetchOtherLanguageItems(view) {
  return async (dispatch, getState) => {
    dispatch(startLoadingOtherItems());

    try {
      const selectedItemIds = getState()[view].selected;
      const items = selectedItemIds.map(id => getState()[view].items[id]);

      // TODO: add a guard that prevents unnecessary loading of data if the data has already been loaded previously
      const reqBody = items.map(item => {
        return view === 'studies'
          ? { idno: item.idno, language_id: item.language_id === 'fi' ? 'en' : 'fi' }
          : { study_idno: item.study_idno, language_id: item.language_id === 'fi' ? 'en' : 'fi', name: item.name }
      });

      const response = await callBackend(`${routes[view]}/pick`, 'POST', reqBody);

      if (!response.ok) {
        throw new Error(`Tila: ${response.status}. URL: ${response.url}`);
      }

      const data = await response.json();
      const otherItems = addNewProperties(data, view);

      dispatch(otherItemsFetchSuccess(view, otherItems));
    }
    catch (error) {
      dispatch(otherItemsFetchFailure());
      dispatch(addError(`Tapahtui odottamaton virhe. ${error.message}`));
    }
  }
}
