import * as constants from './inspectionConstants';
import { selectItemsKeywords } from '../items/itemReducer';

const initialState = {
  inspectionType: null,         // Current inspection type, can be variable/study
  selected: [],                 // An array of selected item identifiers
  inspectedItem: '',            // Currently selected item Id
  keywordInput: '',             // Keyword search input
  keywordVocabulary: 'YSO_fi',  // Currently selected vocabulary
  keywordResults: [],           // Keyword results fetched from backend
  keywordQuery: '',             // Last query sent to /terms
  loading: false,               // Keyword loading
  pendingRequests: 0,           // Number of pending API requests to add/remove terms
  keywordSource: 'finto',       // Source of suggestions
  suggestionsLoading: false,    // Suggestions loading
  otherLanguageItems: {},       // Other language version of the selected items
  otherItemsLoading: false      // Other language items loading
}

/**
 * Reducer used to track the state of Inspection view
 * @param {Object} state The initial state object for the reducer
 * @param {Object} action An action object describing what happened
 * @returns The new state object
 */
export default function inspectionReducer(state = initialState, action) {
  switch (action.type) {
    case constants.SET_INSPECTION:
      return {
        ...state,
        inspectionType: action.inspectionType,
        selected: action.selected,
        inspectedItem: action.selected[0],
        keywordSource: (action.inspectionType === 'studies' && action.languageID === 'en') ? 'annif' : 'finto'
      }
    case constants.REMOVE_SELECTED:
      return {
        ...state,
        selected: state.selected.filter(item => item !== state.inspectedItem),
      }
    case constants.CHANGE_INSPECTED:
      return {
        ...state,
        inspectedItem: state.selected.length > 0 ? state.selected[0] : '',
        inspectionType: state.selected.length > 0 ? state.inspectionType : null
      }
    case constants.RESET_INSPECTION:
      return {
        ...state,
        inspectionType: null,
        selected: [],
        inspectedItem: '',
        keywordInput: '',
        keywordResults: [],
        keywordQuery: '',
        keywordSource: 'finto',
        otherLanguageItems: {}
      }
    case constants.RESET_KEYWORD_VOCABULARY:
      return {
        ...state,
        keywordVocabulary: action.languageID === 'en' ? 'YSO_fi' : 'ELSST_en'
      }
    case constants.SELECT_INSPECTION:
      return {
        ...state,
        inspectedItem: action.selected
      }
    case constants.CHANGE_VOCABULARY:
      return {
        ...state,
        keywordVocabulary: action.vocabulary
      }
    case constants.CHANGE_KEYWORD_SOURCE:
      return {
        ...state,
        keywordSource: action.keywordSource
      }
    case constants.CHANGE_KEYWORD_INPUT:
      return {
        ...state,
        keywordInput: action.text
      }
    case constants.START_LOADING:
      return {
        ...state,
        loading: true
      }
    case constants.CHANGE_QUERY:
      return {
        ...state,
        keywordQuery: action.query
      }
    case constants.FETCH_KEYWORDS_SUCCESS:
      return {
        ...state,
        loading: false,
        keywordResults: action.keywords
      }
    case constants.FETCH_KEYWORDS_FAILURE:
      return {
        ...state,
        loading: false
      }
    case constants.START_LOADING_SUGGESTIONS:
      return {
        ...state,
        suggestionsLoading: true
      }
    case constants.FETCH_SUGGESTIONS_SUCCESS:
    case constants.FETCH_SUGGESTIONS_FAILURE:
      return {
        ...state,
        suggestionsLoading: false
      }
    case constants.INCREMENT_PENDING_REQUESTS:
      return {
        ...state,
        pendingRequests: state.pendingRequests + 1
      }
    case constants.DECREMENT_PENDING_REQUESTS:
      return {
        ...state,
        pendingRequests: state.pendingRequests - 1
      }
    case constants.START_LOADING_OTHER_ITEMS:
      return {
        ...state,
        otherItemsLoading: true
      }
    case constants.OTHER_ITEMS_FETCH_SUCCESS: {
      const itemsObj = {};
      // Add objects from arrays in action.items to an object used for storing the data
      action.items.forEach(item => {
        itemsObj[item.jointID] = item;
      });

      return {
        ...state,
        otherLanguageItems: itemsObj,
        otherItemsLoading: false
      }
    }
    case constants.OTHER_ITEMS_FETCH_FAILURE:
      return {
        ...state,
        otherItemsLoading: false
      }
    default:
      return state;
  }
}

// ------------------- SELECTORS ------------------- //
/**
 * Return an array of objects for dropwdown menu used to show selected items
 * @param {Object} state Slice of the state used in the Inspection view
 * @returns An array of objects mapped to be used in a dropdown menu
 */
export function selectDropdownOptions(state) {
  return state.selected.map(item => {
    return {value: item, text: item}
  })
}

/**
 * Return function to select correct group of keywords depending on the chosen keyword source
 * @param {Object} state The whole state of the application
 * @param {String} view Information whether the function is targeting variables or studies
 * @returns A function that returns keywords
 */
export function selectSuggestedKeywords(state, view) {
  if (state.inspection.keywordSource === 'other') {
    return selectOtherKeywords(state, view)
  }
  else {
    return selectItemsKeywords(state[view], state.inspection.inspectedItem, state.inspection.keywordSource);
  }
}

/**
 * Return an union of keywords from selected items that are not included in the currently inspected item
 * @param {Object} state The whole state of the application
 * @param {String} view Information whether the function is targeting variables or studies
 * @returns A sorted array of keyword objects
 */
export function selectOtherKeywords(state, view) {
  const inspectedObj = createKeywordsObject(state[view], state.inspection.inspectedItem);
  const otherKeywords = {};

  // Gather an union of keywords that are not included in the currently inspected item
  state.inspection.selected.forEach(item => {
    if (item !== state.inspection.inspectedItem) {
      const itemsKeywordsObj = createKeywordsObject(state[view], item);

      // Find keywords that are not included in the inspected item and that are not already included in the otherKeywords-object
      for (const itemKey in itemsKeywordsObj) {
        if (!Object.keys(inspectedObj).includes(itemKey) && !Object.keys(otherKeywords).includes(itemKey)) {
          otherKeywords[itemKey] = itemsKeywordsObj[itemKey];
        }
      }
    }
  });

  // Return keywords in the object as a sorted array
  return Object.values(otherKeywords).sort((a, b) => a.value > b.value ? 1 : -1);
}

/**
 * Return an object containing all keywords from a single item
 * @param {Object} state Slice of the state
 * @param {String} item The ID of the target item
 * @returns A keyword object
 */
function createKeywordsObject(state, item) {
  const itemsKeywordsArray = selectItemsKeywords(state, item, 'user');
  const keywordsObject = {};

  itemsKeywordsArray.forEach(keyword => {
    keywordsObject[keyword.id] = keyword;
  });

  return keywordsObject;
}

/**
 * Return an intersection of keyword objects from all selected items
 * @param {Object} state The whole state of the application
 * @param {String} view Information whether the function is targeting variables or studies
 * @returns A sorted array of objects
 */
export function selectAllSharedKeywords(state, view) {
  let allKeywords = [];

  // Loop through all the selected items and concatenate their keywords to a single array
  state.inspection.selected.forEach(item => {
    const singleItemsKeywords = selectItemsKeywords(state[view], item, 'user');
    allKeywords = [...allKeywords, ...singleItemsKeywords];
  });

  // Find an intersection from all the keywords present in the selected items
  const keywordsIntersection = createIntersection(allKeywords, state.inspection.selected.length);

  return Object.values(keywordsIntersection).sort((a, b) => a.value > b.value ? 1 : -1);
}

/**
 * Return an intersection of keyword objects from an array
 * @param {Array} keywordsArr An array containing keyword objects
 * @param {Number} itemsAmount The amount of items selected for inspection
 * @returns An array of keyword objects
 */
function createIntersection(keywordsArr, itemsAmount) {
  const keywordsIntersection = [];
  const keywordsAmountTable = {};

  // Loop through all the keywords to find those that have as many occurences as there are items
  keywordsArr.forEach(keyword => {
    // If the keyword id key is not in table, add the key and increment by one, else just increment by one
    keywordsAmountTable[keyword.id] = (keywordsAmountTable[keyword.id] || 0) + 1;

    // Add the keyword to intersection if there are as many occurences as there are items
    if (keywordsAmountTable[keyword.id] === itemsAmount) {
      keywordsIntersection.push(keyword);
    }
  });

  return keywordsIntersection;
}
