import { ADD_ERROR, RESET_ERRORS, CHANGE_LANGUAGE, CHANGE_UI_LANGUAGE } from './globalConstants';
const dictionaryFI = require('../../translations/finnish.json');
const dictionaryEN = require('../../translations/english.json');

const initialState = {
  languageID: 'fi',           // Language of the data
  languageUI: 'fi',           // Language of the UI
  dictionary: dictionaryFI,   // Dictionary currently in use
  vocabularies: [             // Available vocabularies
    {'id': 'YSO_fi', 'name': 'YSO (FI)', 'vocabName': 'YSO', 'language_id': 'fi'},
    {'id': 'YSO_en', 'name': 'YSO (EN)', 'vocabName': 'YSO', 'language_id': 'en'},
    {'id': 'ELSST_fi', 'name': 'ELSST (FI)', 'vocabName': 'ELSST', 'language_id': 'fi'},
    {'id': 'ELSST_en', 'name': 'ELSST (EN)', 'vocabName': 'ELSST', 'language_id': 'en'},
    {'id': 'Custom', 'name': 'Custom', 'vocabName': 'Custom', 'language_id': null}
  ],
  errors: 0,                  // Amount of errors
  errorMessage: ''            // Latest error message
}

/**
 * Reducer used to track the state of global settings
 * @param {Object} state The initial state object for the reducer
 * @param {Object} action An action object describing what happened
 * @returns The new state object
 */
export default function globalReducer(state = initialState, action) {
  switch (action.type) {
    case ADD_ERROR:
      return {
        ...state,
        errors: state.errors + 1,
        errorMessage: action.errorMessage
      };
    case RESET_ERRORS:
      return {
        ...state,
        errors: 0,
        errorMessage: ''
      };
    case CHANGE_LANGUAGE:
      return {
        ...state,
        languageID: action.languageID
      };
    case CHANGE_UI_LANGUAGE:
      return {
        ...state,
        languageUI: action.languageUI,
        dictionary: action.languageUI === 'fi' ? dictionaryFI : dictionaryEN
      }
    default:
      return state;
  }
}

// ------------------- SELECTORS ------------------- //
/**
 * Return an array of vocabulary objects for use in a dropdown menu
 * @param {Object} state Slice of the state
 * @returns An array of vocabulary objects
 */
export function selectVocabularyOptions(state) {
  return state.vocabularies.map(vocabulary => {
    return {
      value: vocabulary.id,
      text: vocabulary.name,
    }
  });
}
