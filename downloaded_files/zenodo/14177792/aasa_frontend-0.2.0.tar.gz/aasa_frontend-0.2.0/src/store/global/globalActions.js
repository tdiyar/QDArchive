import { ADD_ERROR, RESET_ERRORS, CHANGE_LANGUAGE, CHANGE_UI_LANGUAGE } from './globalConstants';

// ------------- ACTION CREATORS ------------- //
export function addError(errorMessage) {
  return {
    type: ADD_ERROR,
    errorMessage
  }
}

export function resetErrors() {
  return {
    type: RESET_ERRORS
  }
}

export function changeLanguage(languageID) {
  return {
    type: CHANGE_LANGUAGE,
    languageID
  }
}

export function changeUiLanguage(languageUI) {
  return {
    type: CHANGE_UI_LANGUAGE,
    languageUI
  }
}
