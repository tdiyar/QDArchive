import * as constants from './itemConstants';

/**
 * Reducer factory used to create multiple similar reducers
 * @param {String} name The name of the new reducer to be created
 * @param {Object} inititalState  The initial state object for the new reducer
 * @returns Reducer function
 */
export default function createItemReducer(name = '', inititalState) {
  return function itemReducer(state = inititalState, action) {
    switch (action.type) {
      case `${name}/${constants.CHANGE_TEXT}`:
        return {
          ...state,
          text: action.text
        }
      case `${name}/${constants.CHANGE_SORT}`:
        return {
          ...state,
          sortDirection: state.sortDirection === 'ascending' && state.sortColumn === action.column
            ? 'descending'
            : 'ascending',
          sortColumn: action.column
        }
      case `${name}/${constants.ADD_SELECTED}`:
        return {
          ...state,
          selected: [...state.selected, action.jointId],
          lastSelectedIndex: action.index
        }
      case `${name}/${constants.REMOVE_SELECTED}`:
        return {
          ...state,
          selected: state.selected.filter((id) => id !== action.jointId)
        }
      case `${name}/${constants.REMOVE_ALL_SELECTED}`:
        return {
          ...state,
          selected: []
        }
      case `${name}/${constants.START_LOADING}`:
        return {
          ...state,
          loading: true
        }
      case `${name}/${constants.START_LOADING_ALL}`:
        return {
          ...state,
          selectLoading: true
        }
      case `${name}/${constants.CHANGE_LAST_QUERY}`:
        return {
          ...state,
          lastQuery: action.query
        }
      case `${name}/${constants.CHANGE_CURRENT_PAGE}`:
        return {
          ...state,
          currentPage: action.page,
          lastSelectedIndex: null
        }
      case `${name}/${constants.GET_ITEMS_SUCCESS}`: {
        const itemsObj = {};
        // Add objects from arrays in action.items to an object used for storing the data
        action.items.forEach((item) => {
          itemsObj[item.jointID] = item;
        });

        return {
          ...state,
          items: {
            ...state.items,
            ...itemsObj
          },
          pages: {
            ...state.pages,
            ...action.items && action.items.length > 0 && { [action.pageNo]: action.items.map((item) => item.jointID) }
          },
          itemsCount: action.count,
          loading: false
        }
      }
      case `${name}/${constants.STOP_LOADING}`:
      case `${name}/${constants.GET_ITEMS_FAILURE}`:
        return {
          ...state,
          itemsCount: 0,
          loading: false
        }
      case `${name}/${constants.GET_ALL_ITEMS_SUCCESS}`: {
        const itemsObj = {};
        // Add objects from arrays in action.items to an object used for storing the data
        action.items.forEach((item) => {
          itemsObj[item.jointID] = item;
        });

        const newSelected = Object.keys(itemsObj);

        return {
          ...state,
          items: {
            ...state.items,
            ...itemsObj
          },
          selected: newSelected,
          itemsCount: action.count,
          selectLoading: false
        }
      }
      case `${name}/${constants.STOP_LOADING_ALL}`:
      case `${name}/${constants.GET_ALL_ITEMS_FAILURE}`:
        return {
          ...state,
          itemsCount: 0,
          selectLoading: false
        }
      case `${name}/${constants.TOGGLE_SEARCH_OPTIONS_ACTIVE}`:
        return {
          ...state,
          searchOptions: {
            ...state.searchOptions,
            active: !state.searchOptions.active
          }
        }
      case `${name}/${constants.ADD_FILTER_ROW}`: {
        // Find the first unused filter
        const selectedFilter = [...state.searchOptions.filters].find((filter) => {
          return !state.searchOptions.selected.includes(filter.key);
        });

        return {
          ...state,
          searchOptions: {
            ...state.searchOptions,
            selected: [...state.searchOptions.selected, selectedFilter.key],
            values: {
              ...state.searchOptions.values,
              [selectedFilter.key]: selectedFilter.bool ? 'yes' : ''
            }
          }
        }
      }
      case `${name}/${constants.REMOVE_FILTER_ROW}`: {
        // Remove the value with action.key from the values object by destructuring the object and discarding the selected filter
        const {[action.key]: removedValue, ...remainingValues} = state.searchOptions.values;

        return {
          ...state,
          searchOptions: {
            ...state.searchOptions,
            selected: [
              ...state.searchOptions.selected.filter((value) => value !== action.key)
            ],
            values: remainingValues
          }
        }
      }
      case `${name}/${constants.CHANGE_SELECTED_FILTER}`: {
        // Find the current filter that is to be changed
        const valueToRemove = state.searchOptions.selected[action.row];
        // Remove the current filter from the values object by destructuring the object and discarding the current filter
        const {[valueToRemove]: removedValue, ...remainingValues} = state.searchOptions.values;
        // Find the chosen new filter
        const filter = state.searchOptions.filters.find((value) => value.key === action.key);
        // Replace the old filter key with the new one in the selected array
        const remainingSelected = state.searchOptions.selected.map((value, index) => {
          if (index === action.row) {
            return action.key
          }
          else {
            return value
          }
        });

        return {
          ...state,
          searchOptions: {
            ...state.searchOptions,
            selected: [
              ...remainingSelected
            ],
            values: {
              ...remainingValues,
              [action.key]: filter.bool ? 'yes' : ''
            }
          }
        }
      }
      case `${name}/${constants.CHANGE_FILTER_VALUE}`:
        return {
          ...state,
          searchOptions: {
            ...state.searchOptions,
            values: {
              ...state.searchOptions.values,
              [action.key]: action.value
            }
          }
        }
      case `${name}/${constants.SET_SEARCH_TERM}`:
        return {
          ...state,
          searchOptions: {
            ...state.searchOptions,
            selected: [...state.searchOptions.selected, 'terms_include'],
            values: {
              ...state.searchOptions.values,
              'terms_include': action.key
            }
          },
        }
      case `${name}/${constants.RESET_RESULTS}`:
        return {
          ...state,
          items: {},
          currentPage: 1,
          selected: [],
          lastSelectedIndex: null,
          pages: {}
        }
      case `${name}/${constants.ADD_KEYWORD_TO_ITEMS}`: {
        const itemsCopy = {...state.items};

        // Loop through all of the items in the action object
        action.items.forEach(item => {
          // Use selector function to get a copy of all the keywords of a chosen source for the current item
          const keywords = [...selectItemsKeywords(state, item, action.source)];

          // If the item does not contain a keyword with the same id as the keyword in the action object
          if (!keywords.some(keyword => keyword.id === action.keyword.id)) {
            keywords.push(action.keyword);

            // Create a copy of the current item from the copied items object
            const copyItem = {...itemsCopy[item]};

            // Change the correct array of keywords in the copied item based on the action objects source
            // and replace the original item in the copied items object with a copied item object
            if (action.source === 'user') {
              copyItem.user_terms = keywords;
              itemsCopy[item] = copyItem;
            }
            else {
              copyItem.suggested_terms[action.source] = keywords;
              itemsCopy[item] = copyItem;
            }
          }
        });

        return {
          ...state,
          items: itemsCopy
        }
      }
      case `${name}/${constants.REMOVE_KEYWORD_FROM_ITEMS}`: {
        const itemsCopy = {...state.items};

        action.items.forEach(item => {
          const prevKeywords = [...selectItemsKeywords(state, item.jointID, 'user')];
          const filtteredKeywords = prevKeywords.filter(keyword => keyword.id !== action.keyword.id);

          const copyItem = {...itemsCopy[item.jointID]};
          copyItem.user_terms = filtteredKeywords;
          itemsCopy[item.jointID] = copyItem;
        });

        return {
          ...state,
          items: itemsCopy
        }
      }
      case `${name}/${constants.CHANGE_ITEMS_KEYWORDED}`: {
        const itemsCopy = {...state.items};
        const copyItem = {...itemsCopy[action.itemID]};
        copyItem.keyworded = action.keyworded;
        itemsCopy[action.itemID] = copyItem;

        return {
          ...state,
          items: itemsCopy
        }
      }
      case `${name}/${constants.RESET_FILTERS}`:
        return {
          ...state,
          text: '',
          searchOptions: {
            ...state.searchOptions,
            selected: [],
            values: {}
          }
        }
      default:
        return state;
    }
  }
}

// ------------------- SELECTORS ------------------- //
/**
 * Return all item objects placed on current page
 * @param {Object} state Slice of the state
 * @returns Array of items in the current page
 */
export function selectPageItems(state) {
  if (state.pages[state.currentPage]) {
    return state.pages[state.currentPage].map((item) => {
      return state.items[item];
    })
  }
  else {
    return [];
  }
}

/**
 * Return total amount of pages loaded
 * @param {Object} state Slice of the state
 * @returns Amount of pages loaded
 */
export function selectTotalPages(state) {
  return Object.keys(state.pages).length;
}

/**
 * Return an object with arrays describing the items on each page
 * @param {Object} state Slice of the state
 * @returns Object containing all pages
 */
export function selectPages(state) {
  return state.pages;
}

/**
 * Return all keywords of a single item from a selected source
 * @param {Object} state Slice of the state
 * @param {String} item The ID of the target item
 * @param {String} source Name of the source
 * @returns An array of keywords from single item if found, otherwise empty array
 */
export function selectItemsKeywords(state, item, source) {
  if (!state.items[item]) {
    return [];
  }

  if (source === 'user') {
    return state.items[item].user_terms;
  }
  else {
    if (state.items[item].suggested_terms[source]) {
      return state.items[item].suggested_terms[source];
    }
    else {
      return [];
    }
  }
}

/**
 * Return a boolean describing are all the selected items keyworded or not
 * @param {Object} state Slice of the state
 * @param {Array} selected An array of selected item IDs
 * @returns Boolean
 */
export function selectAllKeywordingStatus(state, selected) {
  let allKeyworded = true;

  selected.forEach(item => {
    if (!state.items[item].keyworded) {
      allKeyworded = false;
    }
  });

  return allKeyworded;
}

/**
 * Return a boolean describing if the inspected item is keyworded or not
 * @param {Object} state Slice of the state
 * @param {String} inspected The ID of the inspected item
 * @returns Boolean
 */
export function selectInspectedKeywordingStatus(state, inspected) {
  return state.items[inspected].keyworded;
}

/**
 * Return true if any of the filters contain some value, false if none of the filters contains a value
 * @param {Object} state Slice of the state
 * @returns Boolean
 */
export function selectFiltersStatus(state) {
  return Object.values(state.searchOptions.values).some(filter => filter !== '');
}
