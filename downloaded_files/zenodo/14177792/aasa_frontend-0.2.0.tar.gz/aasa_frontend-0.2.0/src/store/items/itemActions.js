import * as constants from './itemConstants';
import { addError } from '../global/globalActions';
import { incrementPendingRequests, decrementPendingRequests } from '../inspection/inspectionActions';
import { selectSuggestedKeywords } from '../inspection/inspectionReducer';
import * as routes from '../utils/apiRoutes';
import * as utils from '../utils/helperFunctions';

// ------------- ACTION CREATORS ------------- //
export function changeText(view, text) {
  return {
    type: `${view}/${constants.CHANGE_TEXT}`,
    text
  }
}

export function changeSort(view, column) {
  return {
    type: `${view}/${constants.CHANGE_SORT}`,
    column
  }
}

export function addSelected(view, jointId, index) {
  return {
    type: `${view}/${constants.ADD_SELECTED}`,
    jointId,
    index
  }
}

export function removeSelected(view, jointId) {
  return {
    type: `${view}/${constants.REMOVE_SELECTED}`,
    jointId
  }
}

export function removeAllSelected(view) {
  return {
    type: `${view}/${constants.REMOVE_ALL_SELECTED}`
  }
}

export function startLoading(view) {
  return {
    type: `${view}/${constants.START_LOADING}`
  }
}

export function stopLoading(view) {
  return {
    type: `${view}/${constants.STOP_LOADING}`
  }
}

export function startLoadingAll(view) {
  return {
    type: `${view}/${constants.START_LOADING_ALL}`
  }
}

export function stopLoadingAll(view) {
  return {
    type: `${view}/${constants.STOP_LOADING_ALL}`
  }
}

export function changeLastQuery(view, query) {
  return {
    type: `${view}/${constants.CHANGE_LAST_QUERY}`,
    query
  }
}

export function getItemsSuccess(view, pageNo, items, count) {
  return {
    type: `${view}/${constants.GET_ITEMS_SUCCESS}`,
    pageNo,
    items,
    count
  }
}

export function getItemsFailure(view) {
  return {
    type: `${view}/${constants.GET_ITEMS_FAILURE}`
  }
}

export function getAllItemsSuccess(view, items, count) {
  return {
    type: `${view}/${constants.GET_ALL_ITEMS_SUCCESS}`,
    items,
    count
  }
}

export function getAllItemsFailure(view) {
  return {
    type: `${view}/${constants.GET_ALL_ITEMS_FAILURE}`
  }
}

export function changeCurrentPage(view, page) {
  return {
    type: `${view}/${constants.CHANGE_CURRENT_PAGE}`,
    page
  }
}

export function toggleSearchActive(view) {
  return {
    type: `${view}/${constants.TOGGLE_SEARCH_OPTIONS_ACTIVE}`
  }
}

export function addFilterRow(view) {
  return {
    type: `${view}/${constants.ADD_FILTER_ROW}`
  }
}

export function removeFilterRow(view, key) {
  return {
    type: `${view}/${constants.REMOVE_FILTER_ROW}`,
    key
  }
}

export function changeSelectedFilter(view, row, key) {
  return {
    type: `${view}/${constants.CHANGE_SELECTED_FILTER}`,
    row,
    key
  }
}

export function changeFilterValue(view, key, value) {
  return {
    type: `${view}/${constants.CHANGE_FILTER_VALUE}`,
    key,
    value
  }
}

export function setSearchTerm(view, key) {
  return {
    type: `${view}/${constants.SET_SEARCH_TERM}`,
    key
  }
}

export function resetResults(view) {
  return {
    type: `${view}/${constants.RESET_RESULTS}`,
  }
}

export function addKeywordToItems(view, keyword, items, source) {
  return {
    type: `${view}/${constants.ADD_KEYWORD_TO_ITEMS}`,
    keyword,
    items,
    source
  }
}

export function removeKeywordFromItems(view, keyword, items) {
  return {
    type: `${view}/${constants.REMOVE_KEYWORD_FROM_ITEMS}`,
    keyword,
    items
  }
}

export function changeItemsKeyworded(view, itemID, keyworded) {
  return {
    type: `${view}/${constants.CHANGE_ITEMS_KEYWORDED}`,
    itemID,
    keyworded
  }
}

export function resetFilters(view) {
  return {
    type: `${view}/${constants.RESET_FILTERS}`,
  }
}

// ------------------- THUNKS ------------------- //
/**
 * Fetch data from the backend
 * @param {String} view Name of the view which calls this function
 * @param {String} type Information whether the call is intended to load a section of data or all available data
 * @param {Number} pageNo Current page number
 * @param {Number} limit How many items to load (defaults to 15)
 */
export function fetchData(view, type, pageNo, limit = 15) {
  return async (dispatch, getState) => {
    dispatch(type === 'all' ? startLoadingAll(view) : startLoading(view));

    try {
      const query = utils.createFetchQuery(view, pageNo, limit, getState);
      const response = await fetch(query);
      dispatch(changeLastQuery(view, query));

      if (!response.ok) {
        throw new Error(`Tila: ${response.status}. URL: ${response.url}`);
      }

      const responseJson = await response.json();
      const count = responseJson.count;

      // Throw an error if the backend considers the response for fetch request to contain too many items
      if (type === 'all' && (responseJson.count > 0 && responseJson.data.length === 0)) {
        throw new Error(`Tapahtui odottamaton virhe. Liikaa hakutuloksia (${count}). Rajaa hakua.`);
      }

      if (responseJson.count > 0) {
        const items = utils.addNewProperties(responseJson.data, view);
        dispatch(type === 'all' ? getAllItemsSuccess(view, items, count) : getItemsSuccess(view, pageNo, items, count));
      }
      else {
        dispatch(type === 'all' ? stopLoadingAll(view) : stopLoading(view));
      }
    }
    catch(error) {
      dispatch(type === 'all' ? getAllItemsFailure(view) : getItemsFailure(view));
      dispatch(addError(error.message));
    }
  }
}

/**
 * Add one or more keywords to one or more items
 * @param {String} type Information whether the call is targeting all selected items or only the inspected one
 * @param {String} view Information whether the function is targeting variables or studies
 * @param {Array} givenKeyword Array containing keyword objects (optional)
 */
export function postTermsToItems(type, view, givenKeyword = null) {
  return async (dispatch, getState) => {
    const state = getState();
    const errors = [];
    const keywords = givenKeyword || selectSuggestedKeywords(state, view);
    const keywordSource = state.inspection.keywordSource;

    if (keywords.length > 0) {
      const itemIDs = type === 'all' ? state.inspection.selected : [state.inspection.inspectedItem];
      const items = itemIDs.map(id => state[view].items[id]);

      for await (let item of items) {
        const query = keywordSource !== 'finto' ? `${routes[view]}/${item.id}/terms` : `${routes[view]}/${item.id}/terms/finto-ai`;

        for await (let keyword of keywords) {
          try {
            dispatch(incrementPendingRequests());
            const reqBody = keywordSource === 'finto' ? { "uri": keyword.uri } : utils.createTermObject(keyword);
            const response = await utils.callBackend(query, 'POST', reqBody);

            if (!response.ok) {
              throw new Error(`${keyword.value} lisääminen kohteeseen ${item.jointID}`, { cause: response.status });
            }

            const responseData = await response.json();
            const addedKeyword = responseData.term;
            dispatch(addKeywordToItems(view, addedKeyword, [item.jointID], 'user'));
          }
          catch(error) {
            // Collect error message to errors array if the error is not 403
            error.cause !== 403 && errors.push(error.message);
          }

          dispatch(decrementPendingRequests());
        }
      }

      // Dispatch error messages if any were gathered
      if (errors.length > 0) {
        if (errors.length === 1) {
          dispatch(addError(`Asiasanan ${errors[0]} epäonnistui.`));
        }
        else {
          dispatch(addError(`Asiasanojen ${errors.join(', ')} lisääminen epäonnistui.`));
        }
      }
    }
    else {
      dispatch(addError('Koitettiin lisätä 0 asiasanaa'));
    }
  }
}

/**
 * Change the "keyworded" attribute for one or more items
 * @param {String} type Information whether the call is targeting all selected items or only the inspected one
 * @param {String} view Information whether the function is targeting variables or studies
 * @param {Boolean} keyworded New state for the "keyworded" attribute
 */
export function updateKeywordedForItems(type, view, keyworded) {
  return async (dispatch, getState) => {
    const state = getState();
    const itemIDs = type === 'all' ? state.inspection.selected : [state.inspection.inspectedItem];

    // Map the itemIDs and return an array of copied items to prevent mutating original state
    const items = itemIDs.map(id => {
      return {...state[view].items[id]};
    });

    for await (let item of items) {
      try {
        dispatch(incrementPendingRequests());
        const response = await utils.callBackend(`${routes[view]}/${item.id}`, 'PATCH', {'keyworded': keyworded});

        if (!response.ok) {
          throw new Error();
        }

        dispatch(changeItemsKeyworded(view, item.jointID, keyworded));
      }
      catch(error) {
        dispatch(addError(`Virhe aineistojen/muuttujien tilaa muutettaessa.`));
      }

      dispatch(decrementPendingRequests());
    }
  }
}

/**
 * Add custom keyword to one or more items
 * @param {String} type Information whether the call is targeting all selected items or only the inspected one
 * @param {String} view Information whether the function is targeting variables or studies
 */
export function postCustomTermToItems(type, view) {
  return async (dispatch, getState) => {
    const state = getState();
    const itemIDs = type === 'all' ? state.inspection.selected : [state.inspection.inspectedItem];
    const items = itemIDs.map(id => state[view].items[id]);
    const inputValue = state.inspection.keywordInput;

    for await (let item of items) {
      try {
        dispatch(incrementPendingRequests());
        const query = `${routes[view]}/${item.id}/terms/custom`;
        const response = await utils.callBackend(query, 'POST', { value: inputValue });

        if (!response.ok) {
          throw new Error(`Asiasanan ${inputValue} lisääminen kohteeseen ${item.jointID} epäonnistui.`, { cause: response.status });
        }

        const responseData = await response.json()
        const customKeyword = responseData.term;

        dispatch(addKeywordToItems(view, customKeyword, [item.jointID], 'user'));
      }
      catch(error) {
        // Dispatch an error message if the error is not 403
        error.cause !== 403 && dispatch(addError(error.message));
      }

      dispatch(decrementPendingRequests());
    }
  }
}

/**
 * Delete a keyword from one or more items
 * @param {String} type Information whether the call is targeting all selected items or only the inspected one
 * @param {Object} keyword Keyword object that will be removed
 * @param {String} view Information whether the function is targeting variables or studies
 */
export function deleteTermFromItems(type, keyword, view) {
  return async (dispatch, getState) => {
    const state = getState();
    const itemIDs = type === 'all' ? state.inspection.selected : [state.inspection.inspectedItem];
    const items = itemIDs.map(id => state[view].items[id]);
    const source = 'user';

    for await (let item of items) {
      try {
        dispatch(incrementPendingRequests());
        const response = await utils.callBackend(`${routes[view]}/${item.id}/terms/${source}/${keyword.id}`, 'DELETE');

        if (!response.ok) {
          throw new Error();
        }

        dispatch(removeKeywordFromItems(view, keyword, items));
      }
      catch(error) {
        dispatch(addError(`Asiasanan ${keyword.value} poistaminen epäonnistui.`));
      }

      dispatch(decrementPendingRequests());
    }
  }
}
