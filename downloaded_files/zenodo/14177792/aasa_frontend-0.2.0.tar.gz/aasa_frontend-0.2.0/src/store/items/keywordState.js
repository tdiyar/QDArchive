const keywordState = {
  text: '',                     // Text in the main search box
  sortColumn: 'value',          // The column to sort on
  sortDirection: 'ascending',   // The sort direction
  items: {},                    // Object from keyword IDs to keywords
  currentPage: 1,               // The current page
  lastQuery: '',                // Last query made to server
  itemsCount: '',               // Count of items found on last GET query
  pages: {},                    // Object from page indices to lists of keyword IDs
  loading: false,               // Are new search results being loaded?
  searchOptions: {              // Advanced search options
    active: false,              // Display advanced search?
    selected: [],               // Selected filters
    values: {},                 // Values for different filters
    filters: [                  // Available filters
      {'key': 'vocab', 'name': 'vocabularyId', 'bool': false, 'partial': false},
      {'key': 'deprecated', 'name': 'deprecated', 'bool': true, 'partial': false},
      {'key': 'removed', 'name': 'removed', 'bool': true, 'partial': false}
    ]
  }
}

export default keywordState;
