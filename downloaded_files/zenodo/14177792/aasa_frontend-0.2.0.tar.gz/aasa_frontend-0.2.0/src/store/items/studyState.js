const studyState = {
  text: '',                     // Text in the main search box
  sortColumn: 'idno',           // The column to sort on
  sortDirection: 'ascending',   // The sort direction
  items: {},                    // Object from study IDs to studies
  currentPage: 1,               // The current page
  selected: [],                 // List of selected study IDs
  lastSelectedIndex: null,      // The index of the last toggled checkbox in the search results on the current page
  lastQuery: '',                // Last query made to server
  itemsCount: '',               // Count of items found on last GET query
  pages: {},                    // Object from page indices to lists of study IDs
  loading: false,               // Are new search results being loaded?
  selectLoading: false,         // "Select all" feature is loading items
  searchOptions: {              // Advanced search options
    active: false,              // Display advanced search?
    selected: [],               // Selected filters
    values: {},                 // Values for different filters
    filters: [                  // Available filters
      {'key': 'idno', 'name': 'studyId', 'bool': false, 'partial': false},
      {'key': 'title', 'name': 'studyTitle', 'bool': false, 'partial': true},
      {'key': 'abstract', 'name': 'abstract', 'bool': false, 'partial': true},
      {'key': 'terms_value_include', 'name': 'keyword', 'bool': false, 'partial': true},
      {'key': 'terms_uri_include', 'name': 'keywordUri', 'bool': false, 'partial': false},
      {'key': 'keyworded', 'name': 'studyKeyworded', 'bool': true, 'partial': false}
    ]
  }
}

export default studyState;
