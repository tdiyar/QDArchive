const variableState = {
  text: '',                     // Text in the main search box
  sortColumn: 'study_idno',     // The column to sort on
  sortDirection: 'ascending',   // The sort direction
  items: {},                    // Object from variable IDs to variables
  currentPage: 1,               // The current page
  selected: [],                 // List of selected variable IDs
  lastSelectedIndex: null,      // The index of the last toggled checkbox in the search results on the current page
  lastQuery: '',                // Last query made to server
  itemsCount: '',               // Count of items found on last GET query
  pages: {},                    // Object from page indices to lists of variable IDs
  loading: false,               // Are new search results being loaded?
  selectLoading: false,         // "Select all" feature is loading items
  searchOptions: {              // Advanced search options
    active: false,              // Display advanced search?
    selected: [],               // Selected filters
    values: {},                 // Values for different filters
    filters: [                  // Available filters
      {'key': 'qstnLit', 'name': 'qstnLit', 'bool': false, 'partial': true},
      {'key': 'varGrp', 'name': 'varGrp', 'bool': false, 'partial': true},
      {'key': 'labl', 'name': 'labl', 'bool': false, 'partial': true},
      {'key': 'name', 'name': 'variableName', 'bool': false, 'partial': false},
      {'key': 'study_idno', 'name': 'studyId', 'bool': false, 'partial': false},
      {'key': 'study_title', 'name': 'studyTitle', 'bool': false, 'partial': true},
      {'key': 'terms_value_include', 'name': 'keyword', 'bool': false, 'partial': true},
      {'key': 'keyworded', 'name': 'keyworded', 'bool': true, 'partial': false},
      {'key': 'preQTxt', 'name': 'preQTxt', 'bool': false, 'partial': true},
      {'key': 'postQTxt', 'name': 'postQTxt', 'bool': false, 'partial': true},
      {'key': 'ivuInstr', 'name': 'ivuInstr', 'bool': false, 'partial': true},
      {'key': 'catLabl', 'name': 'catValuesList', 'bool': false, 'partial': true},
      {'key': 'terms_uri_include', 'name': 'keywordUri', 'bool': false, 'partial': false}
    ]
  }
}

export default variableState;
