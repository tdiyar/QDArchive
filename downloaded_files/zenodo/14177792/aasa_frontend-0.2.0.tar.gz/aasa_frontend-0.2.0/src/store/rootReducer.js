import { combineReducers } from 'redux';
import globalReducer from './global/globalReducer';
import inspectionReducer from './inspection/inspectionReducer';
import createItemReducer from './items/itemReducer';
import variableState from './items/variableState';
import studyState from './items/studyState';
import keywordState from './items/keywordState';

const rootReducer = combineReducers({
  global: globalReducer,
  variables: createItemReducer('variables', variableState),
  studies: createItemReducer('studies', studyState),
  keywords: createItemReducer('keywords', keywordState),
  inspection: inspectionReducer
});

export default rootReducer;
