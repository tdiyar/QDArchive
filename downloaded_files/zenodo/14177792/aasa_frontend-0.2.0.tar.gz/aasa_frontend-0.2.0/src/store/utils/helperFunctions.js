import * as routes from './apiRoutes';

/**
 * Gets a search string for partial matching.
 * @param {String} value The search value
 * @returns Modified value
 */
 export function getPartialValueSearchString(value) {
  // If value in quotes, use the exact value
  if (value.length > 0 && value[0] === '"' && value[value.length - 1] === '"') {
    return value.slice(1, -1);
  }
  else {
    return `%${value}%`;
  }
}

/**
 * Create a query string for data fetch
 * @param {String} view The name of the view where the fetch is called
 * @param {Number} pageNo The page number where the data belongs to
 * @param {Number} limit The amount of data items to fetch
 * @param {Function} getState A function that gives access to Redux state
 * @returns A query string with search parameters
 */
export function createFetchQuery(view, pageNo, limit, getState) {
  const defaultParams = createDefaultParams(view, pageNo, limit, getState);
  const filterParams = createFilterParams(view, getState);
  const searchValue = createSearchParam(view, getState);
  const params = { ...defaultParams, ...filterParams, ...searchValue };

  return `${routes[view]}?${new URLSearchParams(params)}`;
}

/**
 * Create default parameters object for data fetch calls
 * @param {String} view The name of the view where the fetch is called
 * @param {Number} pageNo The page number where the data belongs to
 * @param {Number} limit The amount of data items to fetch
 * @param {Function} getState A function that gives access to Redux state
 * @returns An object with default parameters
 */
export function createDefaultParams(view, pageNo, limit, getState) {
  const { sortColumn, sortDirection } = getState()[view];
  const languageID = getState().global.languageID;

  // Count how many data rows to skip to get the correct rows for the current page
  const skipValue = limit * (pageNo - 1);

  return {
    language_id: languageID,
    sort_by: sortDirection === 'ascending' ? `${sortColumn}-asc` : `${sortColumn}-desc`,
    limit: limit,
    skip: skipValue
  };
}

/**
 * Create an object with filter parameters for data fetch
 * @param {String} view The name of the view where the fetch is called
 * @param {Function} getState A function that gives access to Redux state
 * @returns An object with filter parameters
 */
export function createFilterParams(view, getState) {
  const { filters, values } = getState()[view].searchOptions;
  const filterParams = {};

  for (const key in values) {
    const filter = filters.find(filt => filt.key === key);

    // If the value of the filter is not empty, add the key and value to filterParams
    if (values[key] !== '') {
      // If the filter accepts partial values, convert the value accordingly
      if (filter && filter.partial) {
        filterParams[key] = getPartialValueSearchString(values[key]);
      }
      else {
        filterParams[key] = values[key];
      }
    }
  }

  return filterParams;
}

/**
 * Create an object with search parameters for data fetch
 * @param {String} view The name of the view where the fetch is called
 * @param {Function} getState A function that gives access to Redux state
 * @returns An object with search parameters
 */
export function createSearchParam(view, getState) {
  const languageID = getState().global.languageID;
  const textValue = getState()[view].text;

  // Set the searchKey to format used in backend based on the languageID
  const searchKey = languageID === 'en' ? 'search_en' : 'search_fi';

  // Select correct format for object to return based on the view
  return {
    ...textValue && view !== 'keywords' && { [searchKey]: getPartialValueSearchString(textValue) },
    ...textValue && view === 'keywords' && { value: getPartialValueSearchString(textValue) }
  };
}

/**
 * Add jointID-property and properties for organizing the terms in the data items
 * @param {Array} data An array of data items
 * @param {String} view The name of the view where the data belongs to
 * @returns New array of data items with new properties added
 */
export function addNewProperties(data, view) {
  return data.map((item) => {
    if (view === 'keywords') {
      item.jointID = `${item.vocab}-${item.value}-${item.language_id}`;
      return item;
    }
    else {
      item.jointID = item.study_idno
        ? `${item.name}-${item.study_idno}-${item.language_id}`
        : `${item.idno}-${item.language_id}`;

      if (item.terms) {
        item = organizeTerms(item);
      }

      return item;
    }
  });
}

/**
 * Add properties user_terms and suggested_terms and organize terms to these according to their source
 * @param {Object} item A data item object
 * @returns An object with terms organized to new properties user_terms and suggested_terms
 */
export function organizeTerms(item) {
  item.user_terms = [];
  item.suggested_terms = {};

  // Add all terms to correct arrays based on the source of the term
  item.terms.forEach(term => {
    if (term.source === 'user') {
      item.user_terms.push(term.term);
    }
    else {
      if (!item.suggested_terms.hasOwnProperty(term.source)) {
        item.suggested_terms[term.source] = [];
      }
      item.suggested_terms[term.source].push(term.term);
    }
  });

  // Sort the user_terms array based on term id
  item.user_terms.sort((a, b) => a.id > b.id ? 1 : -1);

  // Sort term arrays of all sources in the suggested_terms object based on the term id
  for (const source in item.suggested_terms) {
    item.suggested_terms[source].sort((a, b) => a.id > b.id ? 1 : -1);
  }

  return item;
}

/**
 * Make a call to backend defined by the parameters
 * @param {String} query Target query of the call
 * @param {String} method HTTP method used in the call
 * @param {Object} data Data to be sent with the call (optional)
 * @returns A Promise with the response from backend
 */
export function callBackend(query, method, data = null) {
  return fetch(query, {
    method: method,
    headers: {
      'Content-Type': 'application/json'
    },
    ...data !== null && { body: JSON.stringify(data) }
  });
}

/**
 * Create a term object compatible with backend
 * @param {Object} keyword Keyword object
 * @returns An object with term_id and source assigned as user
 */
export function createTermObject(keyword) {
  return {
    term_id: keyword.id,
    source: 'user'
  };
}

/**
 * Create a query string based on parameters for fetching keywords from backend
 * @param {Number} maxResults The amount of results wanted
 * @param {String} vocabulary The vocabulary of the wanted keywords
 * @param {String} searchValue Value of the keyword (can be partial)
 * @returns A query string with search parameters
 */
export function createKeywordQuery(maxResults, vocabulary, searchValue) {
  const params = {
    limit: maxResults,
    value: getPartialValueSearchString(searchValue),
    vocab: vocabulary.vocabName,
    language_id: vocabulary.language_id,
    deprecated: false,
    removed: false
  };

  return `${routes.keywords}?${new URLSearchParams(params)}`;
}

/**
 * Create a keyword object compatible with backend from a keyword object returned by Finto
 * @param {Object} keyword A keyword object from Finto
 * @returns A keyword object
 */
export function createKeywordObject(keyword) {
  return {
    'vocab': 'YSO',
    'value': keyword.label,
    'uri': keyword.uri,
    'id': `YSO_fi-${keyword.label}`
  };
}
