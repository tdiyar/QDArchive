export const baseURL = '/aasa';
export const variables = `${baseURL}/variables`;
export const studies = `${baseURL}/studies`;
export const keywords = `${baseURL}/terms`;
