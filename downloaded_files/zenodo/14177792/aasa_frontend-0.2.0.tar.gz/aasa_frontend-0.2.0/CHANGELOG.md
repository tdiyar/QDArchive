# Aasa Frontend Changelog

## 0.2.0 (2024-11-20)

This is the first public release. At this point, the repository was moved to a new repository host. Issues, merge requests and other branches than master were not moved. This was intentional to smoothline the transition and move to trunk-based development. Finalizing the release was done pushing directly to master. After this, the master was protects again against direct pushes. As a side effect, the release 0.1.0 had to be retagged.

### Added

- Added licensing information
- Added citation information
- Added usage instructions

### Changed

- Rename CHANGELOG to CHANGELOG.md, switch file format to Markdown
- Moved installation instructions from README to INSTALLATION, reviewed and fixed formatting
- Updated README.md

## 0.1.0 - 2021/12/17

- Initial release
- Compatible with Aasa backend version 0.3.0
