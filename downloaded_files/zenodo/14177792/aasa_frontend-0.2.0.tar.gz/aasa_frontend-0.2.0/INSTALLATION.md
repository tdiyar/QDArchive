# Installation

**At the moment, installation instructions are provided in Finnsh.**

## Yleistä

Aasa-projektin frontend aineistonkäsittelijöille. Työkalulla on tarkoitus lisätä asiasanoja aineistoille tai muuttujille.

Koodi on kirjoitettu JavaScriptillä React-frameworkillä. Sovelluksen tilan hallintaan käytetään Redux-kirjastoa.

## Asennus

### Esivaatimukset

Jotta asennus ja käynnistys onnistuu, koneellasi täytyy olla asennettuna Node ja NPM.

### Askeleet

1. Kloonaa tai lataa tämä repositorio.
2. Avaa komentorivityökalu/terminaali repositorion juuressa ja anna komento `npm install`.
3. Kun kaikki paketit ovat asentuneet, anna komento `npm start`.

Lokaali versio sovelluksesta käynnistyy osoitteessa http://localhost:3000.

### Huom

Tiedostossa package.json on määritetty proxy-osoite, jonne frontend sovellus osoittaa tekemänsä backend kutsut. Tällä hetkellä osoitteeksi on määritetty testikone osoitteessa https://....

## Testit

Anna komento `npm test` käynnistääksesi sovelluksen automaattiset testit.

Komennolla `npm test a` ajetaan kaikki sovelluksen automaattiset testit. Jättää käyntiin kuuntelijan, joka ajaa kaikki testit uudelleen aina kun johonkin tiedostoon tehdyt muutokset tallennetaan.

Komennolla `npm run coverage` saa ajettua sovelluksen automaattiset testit ja generoitua testien kattavuusraportin. Luo projektin juureen kansion /coverage, jonne generoidaan testiraportin tiedostoja.

Komennolla `npm test -- *tiedostonnimi*.test.js` voit ajaa yhden yksittäisen testin.

## Tuotantoversio

- Tuotantoversio luodaan komennolla `npm run build`. Komento luo projektin juureen kansion /build, jonne luodaan sovelluksen optimoitu tuotantoversio automaattisesti.
- Tuotantokäyttöön luotu sivu viedään /var/www/html-kansioon, josta Apache tarjoilee sivun staattisesti.




