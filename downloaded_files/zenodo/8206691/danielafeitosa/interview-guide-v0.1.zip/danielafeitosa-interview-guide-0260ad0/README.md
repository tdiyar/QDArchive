# Interview Guide

## Demographics questions

| ID    | Questions                                  | What is expected        |
| :---: | ----------------------                     | :---:                     |
| #01 | Which institute are you affiliated with? | Context |
| #02 | What is your academic formation? | Context |
| #03 | What is your research area? | Context |
| #04 | Are you a researcher? | Context |
| #05 | How many years of career as a researcher? | Context |

## RQ1: What Open Science practices do researchers use?

This question investigates the general practices used during research even if they are not explicitly related to RS development.

| ID    | Questions                                                                                  | What is expected                                                            | Options/more info                       |
| :---: | ----------------------                                                                     | :---                                                                          |:---                                     |
| #06 | Do you allow virtual access to scientific articles published in academic journals? |  | |
| #07 | Do you define the license when articles are made available? | | |
| #08 | Are experimental elements (resources, algorithms, methods) available? | | |
| #09 | Do you define license when elements are made available? | | |
| #10 | Are preliminary versions of research manuscripts published openly? | | |
| #11 | Can the data and other materials used in the research be reused without your permission? | | |
| #12 | Are the tools and software used in your scientific research open source? | | |

## RQ2: What do researchers think about Open Science?

This question investigates the researcher’s perspective on the concepts and practices related to Open Science in order to analyze their knowledge about the subject

| ID    | Questions                                                                                  | What is expected                                                            | Options/more info                       |
| :---: | ----------------------                                                                     | :---                                                                          |:---                                     |
| #13 | What do you think about making your experiment data and details available so that other researchers can reproduce it and verify your research? |  | |
| #14 | In your opinion, what is Open Science? | | |
| #15 | Which Open Science practices are you aware of and/or use? | | |
| #16 | In your research practice, have you ever encountered obstacles to your daily work? | | |
| #17 | If you need to query data from more than two or three years ago, will you still be able to understand and use it? | | |
| #18 | Do you know or have you used any tool that supports Open Science? | | |
| #19 | How much effort do you put into verifying that your inputs or outputs can be reused or shared? | | |
| #20 | In your opinion, to which public should Science be open? | | |
| #21 | In your opinion, what are the reasons for using Open Science practices? | | |
| #22 | In your opinion, what are the reasons for not using Open Science practices? | | |
| #23 | What could be done at the research institution to adopt some practices? | | |
| #24 | Would you as a researcher adopt Open Science for your research and development environment? | | |

## RQ3: What do researchers think about Sustainable Research Software?

This question investigates the researcher’s perspective on the practices related to Sustainable Research Software in order to analyze their use of these practices

| ID    | Questions                                                                                  | What is expected                                                            | Options/more info                       |
| :---: | ----------------------                                                                     | :---                                                                          |:---                                     |
| #25 | Could you tell me a about how the software to be used in the research is chosen? | Know how the researcher decides whether to develop from scratch or collaborate with an existing one | |
| #26 | What do you think about using open source software in your research? | Find out if the person is interested in reusing and improving existing software | |
| #27 | What do you think about using software developed by your group in other research? | Find out if you are interested in making the code available under an open license | |
| #28 | In your opinion, is it possible for an external researcher to reproduce your research? | Know if data and software are available and have documentation | |
| #29 | In your opinion what can be done to ensure that the software does what is expected of it? | Know what the knowledge about software testing and maintenance | |
| #30 | Are the softwarse used in the research cited? | | |


## RQ4: What are the barriers that prevent the adoption of practices that increase research software sustainability?

This question investigates the reasons that make it difficult to adopt practices that help research software to be sustainable.

| ID    | Questions                                                                                  | What is expected                                                            | Options/more info                       |
| :---: | ----------------------                                                                     | :---                                                                          |:---                                     |
| #31 | What is the background of the people who develop software in your group? | | All, some or none? |
| #32 | On average, how many people are involved in the software development process? | Know how many developers, testers... | All, some or none? |
| #33 | Are the costs related to the development/maintenance of the software accounted for in the research budget? | Find out if there is a lack of funds | |

## RQ5: What are the supporting factors for adopting practices that help research software be sustainable?

This question investigates the reasons in favor of the adoption of practices that help research software be sustainable.

| ID    | Questions                                                                                  | What is expected                                                           | Options/more info                       |
| :---: | ----------------------                                                                     | :---                                                                          |:---                                     |
| #34 | Have you ever had problems with your computer that led to loss of important data or information about your search? | If you are concerned about data availability | If yes, how long did it take to recover? |
| #35 | Would you like to receive input on the software from people outside the group? | Know about if the researcher is interested in contribution |


## RQ6: Is it beneficial for researchers to make their software sustainable?

This question aims to evaluate the researcher's interest in making their software sustainable.

| ID    | Questions                                                                                  | What is expected                                                           | Options/more info                       |
| :---: | ----------------------                                                                     | :---                                                                          |:---                                     |
| #36 | In your opinion, would your research benefit from using software with sustainable practices? | Know about interest | |
| #37 | What do you think about adopting some practices to make software sustainable? | Know about interest | Version control, open repositories, peer collaboration, code review, automated testing, data and interface standardization, documentation |
| #38 | Can you name two tools used? | | |

## Improvements

- Could you indicate any other researcher?
- Is there any question you think it's missing?
- What did you think of:
   - Duration of the interview
   - Clarity of questions and explanations
- Do you have any comments, suggestions or anything else to say about the interview and the topic covered?
