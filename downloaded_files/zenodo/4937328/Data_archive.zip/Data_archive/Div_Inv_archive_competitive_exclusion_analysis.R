#Script for analyzing competitive exclusion using data from lakes with repeated surveys


# Competetive exclusion analysis, identify richness at individual points and calculate change over time for those that remain uninvaded vs change after invasion

alldiffs=data.frame(inv_pres=vector(),reg_coefs=vector(),no_pres=vector(),lake=vector()) #Data frame for invader presence for each sampling location, regression coefficients (of average yearly change in native species richness), and locations with no species at any time point


lk_pres=vector() #lake level number of invaders
lk_reg_coef=vector() #lake level regression coeffiecint for average rate of change in native species richness
for(ii in 1:length(multisetid)){
  replake=lake_year_div[which(lake_year_div$lakeID==multi_surveys[multisetid[ii]]),] #Get yearly data for each lake
  
  
  check_surveys=check_survey_list[[multisetid[ii]]] #Identify specific surveys to include in analysis
  
  surveyyears=replake$survey_year[which(replake$survey_id%in%check_surveys)] #Year of each included survey
  
  # Collect lake level data
  lk_pres[ii]=max(replake$inv_pres) #Identify if and how many invasive species are present in a lake
  # For invaded lakes, identify inital invasion timepoint, only changes after this are considered for the effect of invasion
  if(lk_pres[ii]>0){
    replake=replake[min(which(replake$inv_pres>0)):nrow(replake),]
  }
  
  lakemod=lm(replake$lake_nat_richness[replake$survey_id%in%check_surveys]~replake$survey_year[replake$survey_id%in%check_surveys]) #estimate average yearly change in species richness
  
  lk_reg_coef[ii]=lakemod$coefficients[2] #extract coefficient
  
  
  
  # Collect sampling point level data
  gridpoints=unique(lake_dat$sample_point_num[which(lake_dat$lake_id==replake$lakeID[1]&lake_dat$survey_id%in%check_surveys)]) #Identify shared grid locations in surveys
  
  samp_sizes=length(gridpoints) #number of sampling locations
  
  survey_sp_list=list(check_surveys) #Object for species lists at each time point and location, but first object in list, is vector of survey ids
  
  rich_mat=matrix(NA,nrow=length(gridpoints),ncol=length(check_surveys)) #Matrix for native species richness at each location in lake across all timepoints
  inv_mat=matrix(NA,nrow=length(gridpoints),ncol=length(check_surveys)) #Matrix for invasive species richness at each location in lake across all timepoints

  inv_pres_vec=rep(0,samp_sizes) #Vector for invader presence at each location, will indicate how many timepoints had invaders
  lake_vec=rep(multi_surveys[multisetid[ii]],samp_sizes)

  # Loop through each sampling location and survey date
  for (vv in 1:length(gridpoints)){
    for(ss in 1:length(check_surveys)){
      survey_sp_list[[ss+1]]=list()
      
      survey_sp_list[[ss+1]][[vv]]=lake_dat$veg_code[which(lake_dat$survey_id==check_surveys[ss]&lake_dat$sample_point_num==gridpoints[vv])] #list of all species at a location 
      
      if(length(survey_sp_list[[ss+1]][[vv]])==0){ #If no samples were collected make value NA
        rich_mat[vv,ss]=NA
        inv_mat[vv,ss]=NA
      }else{
        rich_mat[vv,ss]=length(survey_sp_list[[ss+1]][[vv]])-(sum(survey_sp_list[[ss+1]][[vv]]%in%inv_sp_codes))-("EMT"%in%survey_sp_list[[ss+1]][[vv]]) #Richness of native species calculated by total unique species codes minus invasive species and minus 1 for "EMT"(no vegetation present)
        inv_mat[vv,ss]=sum(survey_sp_list[[ss+1]][[vv]]%in%inv_sp_codes) #Richness of invasive species 
      }
      
      inv_pres_vec[vv]=as.numeric(any(inv_sp_codes%in%survey_sp_list[[ss+1]][[vv]]))+inv_pres_vec[vv]
    }
  }
  
  #Modify native species richness matrix to ignore timepoints before initial invasions
  before_inv_mat=rich_mat
  for(rr in 1:nrow(inv_mat)){
    first_inv=min(which(inv_mat[rr,]==1)) #first time point with invader
    if(first_inv==Inf){first_inv=0} #if no invader at any timepoint, all timepoints included to estimate rate of change of uninvaded locations.
    before_inv_mat[rr,which(1:ncol(inv_mat)<first_inv)]=NA #Make prior timepoints NAs so ignored
  }
  
  regs=rep(NA,length=length(gridpoints)) #vector for regression coefficients at each location
  for(vv in 1:length(gridpoints)){
    mod=lm(before_inv_mat[vv,]~surveyyears) #run linear model to get rate of change
    regs[vv]=mod$coefficients[2] #extract coefficient
  }
  adder=data.frame(inv_pres=rowSums(inv_mat,na.rm = TRUE)>0,reg_coefs=regs,no_pres=(rowSums(rich_mat,na.rm = TRUE)+inv_pres_vec)==0,lake=lake_vec) #integrate all data into data frame
  
  alldiffs=rbind(alldiffs,adder) # combine data from all lakes 
}



#Competitive exclusion statistical analyses

# Sampling point level

# Set up variables for analysis
resp=alldiffs$reg_coefs #regression coefficient for each location
pred=(alldiffs$inv_pres) #Change invader presence data into binary predictor of invaded vs uninvaded
block=alldiffs$lake #Lake id for random effect

# Remove locations with no vegetation at any time point
resp=resp[alldiffs$no_pres==FALSE]
pred=pred[alldiffs$no_pres==FALSE]
block=block[alldiffs$no_pres==FALSE]


# Remove locations that have NAs
any_na=!(is.na(resp)|is.na(pred)|is.na(block))
resp=resp[any_na]
pred=pred[any_na]
block=block[any_na]



# Run Linear Mixed Effects model for point level data and calculate p-value with parametric bootstrap
#reduced model without predictor variable of interest

co_ex_full_mod=lmer(resp~pred+(1|block))#Full model with predictor variable of interest
co_ex_red_mod=lmer(resp~(1|block))#reduced model without predictor variable of interest
# summary(co_ex_full_mod)

co_ex_boot_result=PBmodcomp(co_ex_full_mod,co_ex_red_mod,nsim=1000) #Parametric bootstrap for p-value on predictor effect




#Lake level statistical analysis
lake_resp=lk_reg_coef #Lake level rates of change
lake_pred=lk_pres #Invader presence

# Run linear model
lake_exclusion_mod=lm(lake_resp~lake_pred>0)
# summary(lake_exclusion_mod)

