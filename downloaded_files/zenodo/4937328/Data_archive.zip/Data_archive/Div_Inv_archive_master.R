# Master script for data analysis archive associated with Muthukrishnan et al. 
# This script will load data files and run all additional necessary scripts which should be in the same folder. 
 

# Load necessary packages, need to be installed already
library(lme4)
library(pbkrtest)


# Initial data loading and preparation
source("Div_Inv_archive_data_setup.R")

# Overall native-exotic richness relationsips patterns
# Point level
survey_div_glm=glm(survey_invaders~survey_nat_rich,family="poisson")
summary(survey_div_glm)

# Lake Level
lake_div_glm=glm(inv_pres~lake_nat_richness,family="poisson",data=lake_inv_dat)
summary(lake_div_glm)



# Biotic resistance analysis
source(file = "Div_Inv_archive_biotic_resistance_analysis.R")

# Survey point level results
summary(bio_res_full_mod)
bio_res_boot_result

#Lake level results
summary(lake_resist_mod)


# Competitive exclusion analysis
source(file = "Div_Inv_archive_competitive_exclusion analysis.R")

# Survey point level results
summary(co_ex_full_mod)
co_ex_boot_result

#Lake level results
summary(lake_exclusion_mod)



#Environmental filtering analyses
source(file = "Div_Inv_archive_env_filtering_analysis.R")

# Analyses of species richness and depth
#Point level analyses
#Native species 
summary(nat_depth_glm)
#Invasive species 
summary(inv_depth_glm)


#Lake level analyses
#Native species
summary(nat_depth_lake_glm)
#Invasive species
summary(inv_depth_lake_glm)


# Analyses of species richness and Secchi depth
#Point level analyses
#Native species 
summary(nat_secchi_glm)
#Invasive
summary(inv_secchi_glm)

#Lake level analyses
#Native species 
summary(nat_secchi_lake_glm)
#Invasive species 
summary(inv_secchi_lake_glm)



# Lake level multiiple regressions of environmental conditions
# Native richness
summary(env_gmodel_div)

# Invader richness
summary(env_gmodel_inv)  




#Environmental heterogeneity analyses
source(file = "Div_Inv_archive_env_heterogeneity_analysis.R")

# Analyses of species richness and depth heterogeneity
#Depth
#Native species analysis
summary(full_div_depth_het_mod)
#Invasive species analysis
summary(full_inv_depth_het_mod)


# Secchi Depth
#Native species analysis
summary(full_div_sec_het_mod)
#Invasive species analysis
summary(full_inv_sec_het_mod)
