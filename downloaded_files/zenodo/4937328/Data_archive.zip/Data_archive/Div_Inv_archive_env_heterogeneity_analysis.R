# Environmental heterogeneity analyses for depth and Secchi depth 


# Analyses of species richness as a function of heterogeneity in depth
#Depth
#Native species analysis

full_div_depth_het_mod=glm(lake_inv_dat$lake_nat_richness~lake_inv_dat$depth_hetero,family = "poisson")
# summary(full_div_depth_het_mod)

#Invasive species analysis
full_inv_depth_het_mod=glm(lake_inv_dat$inv_pres~lake_inv_dat$depth_hetero,family = "poisson")
# summary(full_inv_depth_het_mod)

# Analyses of species richness as a function of heterogeneity in Secchi Depth
#Native species analysis
full_div_sec_het_mod=glm(lake_inv_dat$lake_nat_richness~lake_inv_dat$secchi_hetero,family = "poisson")
# summary(full_div_sec_het_mod)

#Invasive species analysis
full_inv_sec_het_mod=glm(lake_inv_dat$inv_pres~lake_inv_dat$secchi_hetero,family = "poisson")
# summary(full_inv_sec_het_mod)



##################################################################
# Supplementary analysis of the effects of heterogenity using binary responses of invaded vs uninvaded instead of number of invasive species

# Depth
full_inv_depth_het_log=glm((lake_inv_dat$inv_pres>0)~lake_inv_dat$depth_hetero,family = "binomial")
# summary(full_inv_depth_het_log)


# Secchi Depth
full_inv_sec_het_log=glm((lake_inv_dat$inv_pres>0)~lake_inv_dat$secchi_hetero,family = "poisson")
# summary(full_inv_sec_het_log)



