# Environmental filtering analyses for depth and secchi depth as well as lake level environmental conditions


# Get depth and Secchi depth values for all surveyed locations and remove NA locations; Depth and Secchi depth are both in units of meters
depth_surveyed=unlist(depth_vals)[!is.na(survey_sp_list_simp)]
secchi_surveyed=unlist(secchi_vals)[!is.na(survey_sp_list_simp)]
lake_surveyed=unlist(lake_vals)[!is.na(survey_sp_list_simp)] #lake ids for each location


# Analyses of species richness and depth
#Point level analyses
#Native species analysis
resp=survey_nat_rich
pred=depth_surveyed
block=survey_lake_rem
nat_depth_glm=glm(resp~pred,family = "poisson")
# summary(nat_depth_glm)

#Invasive species analysis
resp=survey_invaders
pred=depth_surveyed
inv_depth_glm=glm(resp~pred,family = "poisson")
# summary(inv_depth_glm)


#Lake level analyses
#Native species analysis
resp=lake_inv_dat$lake_nat_richness
pred=lake_inv_dat$depth_mean
nat_depth_lake_glm=glm(resp~pred,family = "poisson")
# summary(nat_depth_lake_glm)


#Invasive species analysis
resp=lake_inv_dat$inv_pres
pred=lake_inv_dat$depth_mean
inv_depth_lake_glm=glm(resp~pred,family = "poisson")
# summary(inv_depth_lake_glm)

# Analyses of species richness and Secchi depth
#Point level analyses
#Native species analysis
resp=survey_rich
pred=secchi_surveyed
nat_secchi_glm=glm(resp~pred,family = "poisson")
# summary(nat_secchi_glm)

#Invasive
resp=survey_invaders
pred=secchi_surveyed
inv_secchi_glm=glm(resp~pred,family = "poisson")
# summary(inv_secchi_glm)

#Lake level analyses
#Native species analysis
resp=lake_inv_dat$lake_nat_richness
pred=lake_inv_dat$secchi_mean
nat_secchi_lake_glm=glm(resp~pred,family = "poisson")
# summary(nat_secchi_lake_glm)

#Invasive species analysis
resp=lake_inv_dat$inv_pres
pred=lake_inv_dat$secchi_mean
inv_secchi_lake_glm=glm(resp~pred,family = "poisson")
# summary(inv_secchi_lake_glm)




####################################################################
# Lake level multiiple regressions of environmental conditions
# Load lake environmental data 
div_env_dat=read.csv("Lake_mean_env_data.csv")


# Include native and invasive species richness data for all the lakes with full environmental data

div_env_dat$lake_nat_richness=lake_inv_dat$lake_nat_richness[match(as.numeric(paste(div_env_dat$lakeID)),suppressWarnings(as.numeric(paste(lake_inv_dat$lakeID))))] #suppress warnings is included because warning about introduced NAs is irrelevant
div_env_dat$inv_pres=lake_inv_dat$inv_pres[match(as.numeric(paste(div_env_dat$lakeID)),suppressWarnings(as.numeric(paste(lake_inv_dat$lakeID))))]#suppress warnings is included because warning about introduced NAs is irrelevant


# Lake level multiiple regressions of environmental conditions
# Native richness
env_gmodel_div=glm(lake_nat_richness~pH+conductance+P+N_Kjeldahl+chlA+secchi_RS,data=div_env_dat,family="poisson")
# summary(env_gmodel_div)

# Invader richness
env_gmodel_inv=glm(inv_pres~pH+conductance+P+N_Kjeldahl+chlA+secchi_RS,data=div_env_dat,family="poisson")
# summary(env_gmodel_inv)  



##################################################################
# Supplementary analysis of the environmental filtering using binary responses of invaded vs uninvaded instead of number of invasive species

#Depth
#Point level analysis
#Invasive
resp=survey_invaders>0
pred=depth_surveyed
inv_depth_log_glm=glm(resp~pred,family = "binomial")
# summary(inv_depth_log_glm)

#Lake level analysis
#Invasive
resp=lake_inv_dat$inv_pres>0
pred=lake_inv_dat$depth_mean
inv_depth_lake_log_glm=glm(resp~pred,family = "binomial")
# summary(inv_depth_lake_log_glm)



# Secchi depth
#Point level analysis
#Invasive
resp=survey_invaders>0
pred=secchi_surveyed
inv_secchi_log_glm=glm(resp~pred,family = "binomial")
# summary(inv_secchi_log_glm)

#Lake level analysis
#Invasive
resp=lake_inv_dat$inv_pres>0
pred=lake_inv_dat$secchi_mean
inv_secchi_lake_log_glm=glm(resp~pred,family = "binomial")
# summary(inv_secchi_lake_log_glm)



# Lake level multiiple regressions of environmental conditions
#Invasive
env_log_gmodel_inv=glm(inv_pres>0~pH+conductance+P+N_Kjeldahl+chlA+secchi_RS,data=div_env_dat,family="binomial")
# summary(env_log_gmodel_inv)


