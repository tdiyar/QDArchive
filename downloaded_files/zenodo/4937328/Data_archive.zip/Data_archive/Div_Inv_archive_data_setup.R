#Script for initial data loading and preparation before conducting specific analyses


# Load survey and plant info data
lake_dat=read.csv("Lake_plant_diversity_data.csv") #Read in lake survey data
plant_sp_data=read.csv("MpcaFqa.csv",header=TRUE) #Read in data about species identities and native status
plant_sp_data[which(plant_sp_data$Scientific.Name=="Acorus calamus"),"MN.Nativity"]="Native"
vegnames_rect=read.csv("tnrs_results.csv",header=TRUE) #species names rectified via TNRS



# Prep data sets

lake_dat=lake_dat[!lake_dat$survey_id%in%c(5141,5163,4851,5203,5274,5266),] #Remove earlier/wierd surveys for lakes with multiple surveys in the most recent year


# rectify capitalization for veg codes
lake_dat$veg_code=toupper(lake_dat$veg_code)

# Fix names on carex spp. and eleocharis spp.
lake_dat$vegetation_scientific_name=paste(lake_dat$vegetation_scientific_name)
lake_dat$vegetation_scientific_name[lake_dat$veg_code=="CAN"]="Carex narrow spp."
lake_dat$vegetation_scientific_name[lake_dat$veg_code=="CAW"]="Carex wide spp."
lake_dat$vegetation_scientific_name[lake_dat$veg_code=="ELNE"]="Eleocharis spp. needle"
lake_dat$vegetation_scientific_name[lake_dat$veg_code=="ELSP"]="Eleocharis spp. spike"

vegnames_rect$use_name=paste(vegnames_rect$Name_matched)
vegnames_rect$use_name[which(vegnames_rect$Name_matched=="No suitable matches found.")]=paste(vegnames_rect$Name_submitted[which(vegnames_rect$Name_matched=="No suitable matches found.")])

lake_dat$vegnames_rect=vegnames_rect$use_name[match(lake_dat$vegetation_scientific_name,vegnames_rect$Name_submitted)]


# create column for present species where "no species present" is removed so that it is NA instead of an regular entry
lake_dat$veg_code[which(lake_dat$veg_code=="")]="EMT"
lake_dat$veg_noempty=lake_dat$veg_code
lake_dat$veg_noempty[lake_dat$veg_noempty=="EMT"]=NA


vegtypes_all=unique(lake_dat$veg_code)
vegtypes=vegtypes_all[which(vegtypes_all!=""&vegtypes_all!="EMT")]
scinames=unique(lake_dat$vegetation_scientific_name)
scinames=scinames[which(scinames!=""&scinames!="No Vegetation Present")]





# Include information on invasive species identities
invnames_rect=read.csv("tnrs_invasives.csv",header=TRUE)
invnames_rect$use_name=paste(invnames_rect$Name_matched)
invnames_rect$use_name[which(invnames_rect$Name_matched=="No suitable matches found.")]=paste(invnames_rect$Name_submitted[which(invnames_rect$Name_matched=="No suitable matches found.")])
invnames_rect=invnames_rect[-which(invnames_rect$use_name == "Phragmites australis"),]
inv_name_list=c(invnames_rect$use_name,"Typha x glauca","Typha angustifolia","Typha angustifolia or glauca",paste(plant_sp_data$TNRS_spp_name[which(plant_sp_data$TNRS_full_name%in%vegnames_rect$use_name&plant_sp_data$MN.Nativity!="Native")]))
inv_name_list=unique(inv_name_list)

# identify which identified species are in the invasive list
lake_dat$invasive_sp=lake_dat$vegnames_rect%in%inv_name_list


inv_names_set=scinames%in%inv_name_list
inv_sp_codes=vegtypes[inv_names_set]
inv_sp_names=scinames[inv_names_set]
sp_num=length(vegtypes)
invader_mask=rep(1,length(scinames))
invader_mask[inv_names_set]=2#mask of which species are invasive, can be used in plotting for colors/point style



# create column for lake by survey year combination
lake_dat$lake_year=paste0(lake_dat$lake_id,"_",lake_dat$survey_year)
lakeids=unique(lake_dat$lake_id)




lake_dat_full=lake_dat
lake_dat=lake_dat_full[lake_dat_full$sample_point_surveyed=="yes",] #limit data set to only locations that were surveyed




##################################################################
# Create data frame for analyzing lake level diversity
lake_inv_dat=data.frame(lakeID=unique(lake_dat$lake_id))

lake_inv_dat$inv_pres=0
lake_inv_dat$samps=0
lake_inv_dat$lake_nat_richness=0
lake_inv_dat$depth_hetero=0
lake_inv_dat$secchi_hetero=0
lake_inv_dat$depth_mean=0
lake_inv_dat$secchi_mean=0
inv_lake_pres=array(dim=c(length(lake_inv_dat$lakeID),length(inv_sp_codes)))


# Aggregate Lake level data but only using most recent sampling at a lake
# loop through each lake to identify species present and measure richness
for (ii in 1:length(lake_inv_dat$lakeID)){
  recent_year=max(unique(lake_dat$survey_year[which(lake_dat$lake_id==lake_inv_dat$lakeID[ii])])) #identify most recent survey for lake

  recent_id=unique(lake_dat$survey_id[which(lake_dat$lake_id==lake_inv_dat$lakeID[ii]&lake_dat$survey_year==recent_year)])

  
  #Identify species present in lake
  pres_sp=lake_dat$veg_noempty[lake_dat$lake_id==lake_inv_dat$lakeID[ii]]
  
  pres_sp=pres_sp[!is.na(pres_sp)]
  lake_inv_dat$lake_richness[ii]=length(unique(pres_sp))
  lake_inv_dat$lake_nat_richness[ii]=length(unique(pres_sp))-sum(unique(pres_sp)%in%inv_sp_codes)#count only number of native species
  
  curr_sp=unique(pres_sp)
  native_sp=unique(pres_sp)[!unique(pres_sp)%in%inv_sp_codes]
  
  lake_inv_dat$inv_pres[ii]=sum(curr_sp%in%inv_sp_codes)
  # Adjust for ambiguous Typha identification
  if(("TSNL"%in%curr_sp&"TA"%in%curr_sp)|("TSNL"%in%curr_sp&"TG"%in%curr_sp)){lake_inv_dat$inv_pres[ii]=sum(curr_sp%in%inv_sp_codes)-1
  }
  currlake_dat=lake_dat[lake_dat$lake_id==lake_inv_dat$lakeID[ii]&lake_dat$survey_year==recent_year,]
  samp_points=unique(currlake_dat$sample_point_num)#total number of sampled points in a lake
  
  
  lake_inv_dat$samps[ii]=length(unique(samp_points))
  lake_inv_dat$depth_hetero[ii]=sd(lake_dat$depth_ft[lake_dat$survey_id==recent_id][match(unique(lake_dat$sample_point_num[lake_dat$survey_id==recent_id]),lake_dat$sample_point_num[lake_dat$survey_id==recent_id])],na.rm = TRUE)#calculate lake heterogeneity in secchi depth by using depths at each sampling point, but only use first record for each point when there are multiple plants in a sampling
  lake_inv_dat$depth_mean[ii]=mean(lake_dat$depth_ft[lake_dat$survey_id==recent_id][match(unique(lake_dat$sample_point_num[lake_dat$survey_id==recent_id]),lake_dat$sample_point_num[lake_dat$survey_id==recent_id])],na.rm = TRUE)#calculate lake heterogeneity in secchi depth by using depths at each sampling point, but only use first record for each point when there are multiple plants in a sampling
  
  lake_inv_dat$secchi_hetero[ii]=sd(lake_dat$secchi_ft[lake_dat$survey_id==recent_id][match(unique(lake_dat$sample_point_num[lake_dat$survey_id==recent_id]),lake_dat$sample_point_num[lake_dat$survey_id==recent_id])],na.rm = TRUE)#calculate lake heterogeneity in secchi depth by using depths at each sampling point, but only use first record for each point when there are multiple plants in a sampling
  lake_inv_dat$secchi_mean[ii]=mean(lake_dat$secchi_ft[lake_dat$survey_id==recent_id][match(unique(lake_dat$sample_point_num[lake_dat$survey_id==recent_id]),lake_dat$sample_point_num[lake_dat$survey_id==recent_id])],na.rm = TRUE)#calculate lake heterogeneity in secchi depth by using depths at each sampling point, but only use first record for each point when there are multiple plants in a sampling
}



# Aggregate Sampling point level data
surveys=unique(lake_dat$survey_id)

# Initialize vectors for point level data
survey_lake=NA
depth_vals=list()
secchi_vals=list()
lake_vals=list()
survey_sp_list=list(surveys)


# Loop through surveys to get individual point level data. This may throw an error for some locations with no vegetation, but summary objects will correctly include NAs

for(ss in 1:length(surveys)){
  survey_sp_list[[ss+1]]=list()
  #identify number of sampling points for each survey
  gridpoints=unique(lake_dat$sample_point_num[which(lake_dat$survey_id==surveys[ss])])
  gridpoints=gridpoints[!is.na(gridpoints)]
  depth_vals[[ss]]=rep(NA,length(gridpoints))
  secchi_vals[[ss]]=rep(NA,length(gridpoints))
  lake_vals[[ss]]=rep(NA,length(gridpoints))
  #loop through each sampling point for the current survey
  for (vv in 1:length(gridpoints)){
    survey_sp_list[[ss+1]][[vv]]=lake_dat$veg_noempty[which(lake_dat$survey_id==surveys[ss]&lake_dat$sample_point_num==gridpoints[vv])]
    if(length(na.omit(survey_sp_list[[ss+1]][[vv]]))>0){
      depth_vals[[ss]][vv]=unique(lake_dat$depth_ft[which(lake_dat$survey_id==surveys[ss]&lake_dat$sample_point_num==gridpoints[vv])])
      secchi_vals[[ss]][vv]=unique(lake_dat$secchi_ft[which(lake_dat$survey_id==surveys[ss]&lake_dat$sample_point_num==gridpoints[vv])])
      lake_vals[[ss]][vv]=unique(lake_dat$lake_id[which(lake_dat$survey_id==surveys[ss]&lake_dat$sample_point_num==gridpoints[vv])])
      
    }
  }
}


#Simplify species lists for each survey
survey_sp_list_simp=list()
surv=0
for (ss in 1:length(surveys)){
  for(vv in 1:length(survey_sp_list[[ss+1]])){
    surv=surv+1
    survey_sp_list_simp[[length(survey_sp_list_simp)+1]]=survey_sp_list[[ss+1]][[vv]]
    survey_lake[surv]=paste(lake_dat$lake_id[match(surveys[ss],lake_dat$survey_id)])
  }
}

# Identify individual samples with any vegetation present and create an array of which species are present at each location
allgrids_ind=survey_sp_list_simp[!is.na(survey_sp_list_simp)]
totgrids=length(allgrids_ind)
survey_lake_rem=survey_lake[!is.na(survey_sp_list_simp)]#lake ids with unvegetated lakes removed

allgrids_array=array(0,dim=c(length(allgrids_ind),length(vegtypes)))
for(gg in 1:length(allgrids_ind)){
  allgrids_array[gg,match(allgrids_ind[gg][[1]],vegtypes)]=1
}



# Calculate the survey level species richness and invader presence
survey_rich=rowSums(allgrids_array) #total species richness
survey_nat_rich=rowSums(allgrids_array[,!inv_names_set]) #native species richness
survey_invaders=rowSums(allgrids_array[,inv_names_set]) #invasive species richness




#########################################################
# Calculate  richness and diversity summaries for each sampling date for lakes with surveys in multiple years 

#Get all lake by year combinations
lake_surveys=unique(lake_dat$survey_id)

# Create data frame to summarise each lake survey
lake_year_div=data.frame(survey_id=lake_surveys)
lake_year_div$lakeID=lake_dat$lake_id[match(lake_surveys,lake_dat$survey_id)]
lake_year_div$inv_pres=NA #invader presence
lake_year_div$samps=NA #samples taken in survey
lake_year_div$maxsamps=NA #total number of potential sampling positions; used to rectify when lakes had different sampling grids in different years
lake_year_div$survey_year=NA #Year of survey
lake_year_div$survey_id=NA #Survey id#




# Loop through each lake by year combination
for (ii in 1:length(lake_surveys)){
  #All samples for current survey
  currlake_dat=lake_dat[lake_dat$survey_id==lake_surveys[ii],]
  samp_points=unique(currlake_dat$sample_point_num)
    lake_year_div$survey_year[ii]=unique(currlake_dat$survey_year) #Include survey year
  lake_year_div$survey_id[ii]=unique(currlake_dat$survey_id) #include survey id 

  #Find species present in each survey across entire lake
  pres_sp=currlake_dat$veg_noempty
  pres_sp=pres_sp[!is.na(pres_sp)]
  
  # Calculate richness
  lake_year_div$lake_richness[ii]=length(unique(pres_sp)) #total species richness
  lake_year_div$lake_nat_richness[ii]=length(unique(pres_sp))-sum(unique(pres_sp)%in%inv_sp_codes) #native species richness
  lake_year_div$inv_pres[ii]=sum(unique(pres_sp)%in%inv_sp_codes)   #Invasive species richness
  lake_year_div$samps[ii]=length(samp_points)
  lake_year_div$maxsamps[ii]=max(samp_points)

}



#######################

# Identify lakes with repeated surveys
survey_num=NA
for (ii in 1:length(lakeids)){
  survey_num[ii]=length(unique(lake_dat$survey_id[which(lake_dat$lake_id==lakeids[ii])])) #number of surveys conducted on each lake
}

multi_surveys=lakeids[which(survey_num>1)] #lakes with multiple surveys


gridsets=list() #grid locations for surveys
check_survey_list=list() #List of surveys to be included for repeat survey analyses

#Evaluate if lakes with repeated surveys use a consistent sampling grid across years
for (mm in 1:length(multi_surveys)){
  replake=lake_year_div[which(lake_year_div$lakeID==multi_surveys[mm]),] #Subset out data for a specific lake with repeated surveys
  samp_freq=table(replake$maxsamps) #number of sampling points in each survey
  rep_survs=which(replake$maxsamps%in%as.numeric(attr(which(samp_freq>1),"names"))) #Identify when there are multiple surveys with the same sample number 
  if(length(unique(replake$maxsamps[rep_survs]))==1){

    check_survey_list[[mm]]=replake$survey_id[rep_survs]

  }
 
  gridsets[[mm]]=which(table(lake_year_div[which(lake_year_div$lakeID==multi_surveys[mm]),"samps"])>1) #identify when multiple surveys have the same number of gridpoints
  }

multisetid=which(!unlist(lapply(check_survey_list,FUN=is.null))) #lakes with multiple sampling timepoints, where the same sampling grids were used


