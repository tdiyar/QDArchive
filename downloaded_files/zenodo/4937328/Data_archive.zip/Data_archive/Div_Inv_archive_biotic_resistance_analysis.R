# Biotic resistance analysis using logistic regression (GLM with binomial family), calculate effect of species richness of probability of being invaded in subsequent time point

# alldiffs=data.frame(diffs=vector(),inv_pres=vector(),reg_coefs=vector(),no_pres=vector())
lake_chng=rep(0,length(multisetid))
lk_prev=list()
lk_pres_list=list()
prev_rich=vector()
replake_id=vector()
inv_chng=vector()
lk_inv_init_pres=vector()
no_pres_all=vector()

for(ii in 1:length(multisetid)){ #Loop through each lake with multiple surveys
  replake=lake_year_div[which(lake_year_div$lakeID==multi_surveys[multisetid[ii]]),] #Get yearly data for each lake

  check_surveys=check_survey_list[[multisetid[ii]]] #identify specific surveys to include in analysis
  lk_inv_init_pres[ii]=replake$inv_pres[which(check_surveys[1]==replake$survey_id)] # Number of invader species present at initial timepoint
  
  
#Lake level responses
  lk_prev[[ii]]=replake$lake_nat_richness[replake$survey_id%in%check_surveys[-length(check_surveys)]] #native species richness at "previous" time point as opposed to "subsequent" timepoint; removes last timepoint
  lk_pres_list[[ii]]=replake$inv_pres[replake$survey_id%in%check_surveys[-1]] # Number of invasive species present in "subsequent" timepoint; removes initial time point. 
  
  #Identify locations that are already invaded and should not be included in analysis
  for(ss in 2:length(check_surveys)){ 
    if(replake$inv_pres[replake$survey_id%in%check_surveys[ss-1]]>0){lk_pres_list[[ii]][ss-1]=NA}
  }

  
# Calculate individual sampling point level data
  gridpoints=unique(lake_dat_full$sample_point_num[which(lake_dat_full$lake_id==replake$lakeID[1]&lake_dat_full$survey_id%in%check_surveys)]) #Identify shared grid locations in surveys
  
  samp_sizes=length(gridpoints) #Number of usable sampling points
  
  survey_sp_list=list(check_surveys) #Object for species lists at each time point and location, but first object in list, is vector of survey ids
  
  for(ss in 1:length(check_surveys)){survey_sp_list[[ss+1]]=list()}
  
  rich_mat=matrix(NA,nrow=length(gridpoints),ncol=length(check_surveys)) #Matrix for native species richness
  lake_mat=matrix(multi_surveys[multisetid[ii]],nrow=samp_sizes,ncol=length(check_surveys)-1) #matrix of Lake ids appropriately shaped for total number of samples  
  inv_pres_mat=matrix(NA,nrow=samp_sizes,ncol=length(check_surveys)) #matrix of invaders present at each sampling point and time
  surveyed_mat=matrix(NA,nrow=samp_sizes,ncol=length(check_surveys)) #matrix of whether location was sampled
  inv_chng_mat=matrix(NA,nrow=samp_sizes,ncol=length(check_surveys)-1) #matrix of whether location became invaded since last timepoint
  no_sp_mat=matrix(NA,nrow=samp_sizes,ncol=length(check_surveys)-1) #matrix of whether no species were present
  
  
  for (vv in 1:length(gridpoints)){
    for(ss in 1:length(check_surveys)){
     
      survey_sp_list[[ss+1]][[vv]]=lake_dat_full$veg_code[which(lake_dat_full$survey_id==check_surveys[ss]&lake_dat_full$sample_point_num==gridpoints[vv])] #list of all species at a location 
      rich_mat[vv,ss]=length(survey_sp_list[[ss+1]][[vv]])-(sum(survey_sp_list[[ss+1]][[vv]]%in%inv_sp_codes))-("EMT"%in%survey_sp_list[[ss+1]][[vv]]) #native species richness
      inv_pres_mat[vv,ss]=as.numeric(any(inv_sp_codes%in%survey_sp_list[[ss+1]][[vv]])) #identify if any invasive species were present

      # Create matrix of whether points were survey for each time point. this has to account for locations that ae not recorded in data set as well as locations that are recorded but with a comment that it was not surveyed
      if(length(unique(lake_dat_full$sample_point_surveyed[which(lake_dat_full$survey_id==check_surveys[ss]&lake_dat_full$sample_point_num==gridpoints[vv])]))==0){
        surveyed_mat[vv,ss]=1 #values of 1 indicate not surveyed
      }else{
        surveyed_mat[vv,ss]=unique(lake_dat_full$sample_point_surveyed[which(lake_dat_full$survey_id==check_surveys[ss]&lake_dat_full$sample_point_num==gridpoints[vv])]) #values of 1 indicate not surveyed, 2 is surveyed
      }
    }
  }
  
  rich_mat[surveyed_mat==1]=NA #Change richness values for locations that were not surveyed to NAs so they will be ignored

  # Loop through timepoints other than the initial to calculate changes
  for(tt in 2:length(check_surveys)){
    inv_chng_mat[,tt-1]=inv_pres_mat[,tt]==1&inv_pres_mat[,tt-1]==0 #Identify locations that shift from uninvaded to invaded
    no_sp_mat[,tt-1]=rowSums(rich_mat+inv_pres_mat)==0 #identify locations with no species which will be removed if no species at any time point
  }

  # Turn matricies into vectors to facilitate analysis
  prev_rich=c(prev_rich,rich_mat[,1:(length(check_surveys)-1)])
  inv_chng=c(inv_chng,inv_chng_mat)
  no_pres_all=c(no_pres_all,no_sp_mat)
  replake_id=c(replake_id,lake_mat)
 
}


#Biotic resistance statistical analysis

multi_survey_lakes=multi_surveys[multisetid] #lake ids of lakes with multiple surveys and appropriate for analysis

# Sampling point level

# Set up variables for analysis
resp=(inv_chng) # Identification of locations that became invaded
pred=prev_rich #species richness at prior timepoint
block=replake_id # Lake id for random effect

# Remove locations with no vegetation at any time point
resp=resp[!no_pres_all]
pred=pred[!no_pres_all] 
block=block[!no_pres_all]

# Remove locations that have NAs, mostly locations that were already invaded
any_na=!(is.na(resp)|is.na(pred)|is.na(block))
resp=resp[any_na]
pred=pred[any_na]
block=block[any_na]

# Remove lakes that did not have an invader at the initial sampling timepoint
with_inv=block%in%multi_survey_lakes[lk_inv_init_pres>0]
resp=resp[with_inv]
pred=pred[with_inv]
block=block[with_inv]


# Run Generalized Linear Mixed Effects model for point level data and calculate p-value with parametric bootstrap
bio_res_full_mod=glmer(resp~pred+(1|block),family="binomial",control=glmerControl(optimizer="bobyqa")) #Full model with predictor variable of interest
# summary(bio_res_full_mod)

bio_res_red_mod=glmer(resp~(1|block),family="binomial",control=glmerControl(optimizer="bobyqa")) #reduced model without predictor variable of interest

bio_res_boot_result=PBmodcomp(bio_res_full_mod,bio_res_red_mod,nsim=1000) #parametric bootstrap for p-value on predictor effect



# Lake level statistical analysis
lake_pred=unlist(lk_prev) #Species richness at prior timepoint
lake_resp=unlist(lk_pres_list) # Response variable that converts number of invasive species at subsequent timepoint into binary response of invaded vs uninvaded

# Remove locations that have NAs e.g., locations that were already invaded
lake_pred=lake_pred[!is.na(lake_resp)]
lake_resp=lake_resp[!is.na(lake_resp)]

# Run Generalized Linear model
lake_resist_mod=glm(lake_resp>0~lake_pred,family="binomial")
# summary(lake_resist_mod)


