#Scrypt based on carol-rowe666/vcf2hetAlleleDepth
#In terminal (Python) download https://github.com/carol-rowe666/vcf2hetAlleleDepth 
vcf2hetAlleleDepth-master]$ python vcf2hetAlleleDepth.py yourvcf #gives 2 files
library("gbs2ploidy")
## getting our data ready in R From https://cran.r-project.org/web/packages/gbs2ploidy/gbs2ploidy.pdf and check the file .html in the folder of vcf2...
ids<-read.csv("HAD_ID.csv")
het<-as.matrix(read.table("hetAlleleDepth.txt", header=F))
het[1:6, 1:4]
# GET VARIABLES cvo1 AND cov2
# cov1 and cov2 are essentially 2 dataframes with all a_alleles in one, and b_alleles in the other
# first split all samples by allele_a and allele_b
# a contains the a alleles, b is corresponding b alleles for each indivudual
a<-seq(1,10,2) # start at position 1 and go through all 362 columns and get every 2nd column position (362 is the doble of the specimens you have)
b<-seq(2,10,2) # start at position 2 and go through all 362 columns and get every 2nd column position
# Use the column positions to retrieve the entire column and put into a "dataframe"
# dataframe is what I'd call this in python
length(a) 
length(b)
cov1<-het[,a]
cov2<-het[,b]
dim(het) # 134616    170
dim(cov1) # 134616    43
dim(cov2) #134616    42
as.data.frame(cov1)->cov1
as.data.frame(cov2)->cov2
# ESTPROPS
## "This functions uses Markov chain Monte Carlo to obtain Bayesian estimates of allelic proportions,
## which denote that proportion of heterozygous GBS SNPs with different allelic ratios."
propOut<-estprops(cov1=cov1,cov2=cov2,props = c(0.25, 0.33, 0.5, 0.66, 0.75), mcmc.nchain=3,mcmc.steps=10000,mcmc.burnin=1000,mcmc.thin=5)
dev.new()
par(mfrow=c(1,5))
for(i in 1:10){
  plot(propOut[[i]][,3],ylim=c(0,1),axes=FALSE,xlab="ratios",ylab="proportions")
 axis(1,at=1:5,c("1:3","1:2","1:1","2:1","3:1"))
 axis(2)
 box()
  segments(1:5,propOut[[i]][,1],1:5,propOut[[i]][,5])
title(main=paste("sample name =",ids[[1]][i]))
}
dev.off()