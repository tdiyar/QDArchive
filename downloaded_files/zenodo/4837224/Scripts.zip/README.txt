1-Morphological data
Morphological analysis.R
Data input: morphological matrix provide as supplementary material in the paper
2-PCA was performed in the jupyter notebook, please read the file jupyternotebook_ipyrad.txt
to check the parameters.
3-STRUCTURE-> first see the parameters for each dataset in the file jupyternotebook_ipyrad.txt
to check the parameters.
After obtaining results, use the R script pos_structure.R
pos_strucure.R #run with each data set
#Structure results were compared with DAPC
DAPC.R #vcf file as input
4-Ploidy inference from gbs2ploidy in the R environment. 
gbs2ploidy.R #Each species was performed separately for this analysis.
Data input: vcf files
5-Population genetic summary statistics
#Fst.R #should be run for 3sps data set and I_uniflorum dataset
Data input: vcf files