library(vcfR)
library(poppr)
library(RColorBrewer)
library(ape)
vcf.file <-"soloses.vcf"
iph_rec_VCF <- read.vcfR(vcf.file)
gl.iphrec_todo <- vcfR2genlight(iph_rec_VCF)
gl.iphrec_todo
ploidy(gl.iphrec_todo) <- 2
pop(gl.iphrec_todo) <- rec$Pop #tiene q estar en el mismo orden q los indviduos
nb.cols <- 5 #number of species or populations to color
cols <- colorRampPalette(brewer.pal(3, "Set2"))(nb.cols)
library(igraph)
iph_todo.dist <- bitwise.dist(gl.iphrec_todo)
iph_todo.msn <- poppr.msn(gl.iphrec_todo, iph_todo.dist, showplot = FALSE, include.ties = T)
node.size <- rep(2, times = nInd(gl.iphrec_todo))
names(node.size) <- indNames(gl.iphrec_todo)
vertex.attributes(iph_todo.msn$graph)$size <- node.size
set.seed(9)
plot_poppr_msn(gl.iphrec_todo, iph_todo.msn , palette = brewer.pal(n = nPop(gl.iphrec_todo), name = "Dark2"), gadj = 70)
#PCA
iph_rec.pca <- glPca(gl.iphrec_todo, nf = 3, parallel = TRUE)
barplot(100*iph_rec.pca$eig/sum(iph_rec.pca$eig), col = heat.colors(50), main="PCA Eigenvalues")
title(ylab="Percent of variance\nexplained", line = 2)
title(xlab="Eigenvalues", line = 1)
iph_rec.pca.scores <- as.data.frame(iph_rec.pca$scores)
iph_rec.pca.scores <- pop(gl.iphrec_todo)
library(ggplot2)
set.seed(9)
p <- ggplot(iph_rec.pca.scores, aes(x=PC1, y=PC2, colour=pop)) 
p <- p + geom_point(size=2)
p <- p + stat_ellipse(level = 0.95, size = 1)
p <- p + scale_color_manual(values = cols) 
p <- p + geom_hline(yintercept = 0) 
p <- p + geom_vline(xintercept = 0) 
p <- p + theme_bw()
p
#add labels
p + geom_text(aes(label=indNames(gl.iphrec_todo),hjust=0, vjust=0))
#DAPC
pnw.dapc <- dapc(gl.iphrec_todo, n.pca = 3, n.da = 2, parallel=TRUE)
scatter(pnw.dapc, col = cols, cex = 2, legend = TRUE, clabel = F, posi.leg = "bottomleft", scree.pca = TRUE,
        posi.pca = "topleft", cleg = 0.75)
compoplot(pnw.dapc,col = cols, posi = 'top')
dapc.results <- as.data.frame(pnw.dapc$posterior)
dapc.results$pop <- pop(gl.iphrec_todo)
dapc.results$indNames <- rownames(dapc.results)
library(reshape2)
dapc.results <- melt(dapc.results)
colnames(dapc.results) <- c("Original_Pop","Sample","Assigned_Pop","Posterior_membership_probability")
p <- ggplot(dapc.results, aes(x=Sample, y=Posterior_membership_probability, fill=Assigned_Pop))
p <- p + geom_bar(stat='identity') 
p <- p + scale_fill_manual(values = cols) 
p <- p + facet_grid(~Original_Pop, scales = "free")
p <- p + theme(axis.text.x = element_text(angle = 90, hjust = 1, size = 8))
p
write.csv(dapc.results, "dapc.results.csv")
#
my_genind <- vcfR2genind(read.vcfR(vcf.file))
my_genclone <- poppr::as.genclone(my_genind)
#crossvalidation
set.seed(999)
dapcl_cv_iph_todo <- xvalDapc(tab(my_genclone, NA.method = "mean"), pop(my_genclone))
system.time(dapcl_cv_iph_todo <- xvalDapc(tab(my_genclone, NA.method = "mean"), pop(my_genclone),
                              n.pca = 10:20, n.rep = 1000,
                              parallel = "multicore", ncpus = 4L))
scatter(dapcl_cv_iph_todo$DAPC, col=cols, cex = 2, legend = TRUE,
        +         clabel = FALSE, posi.leg = "bottomleft", scree.pca = TRUE,
        +         posi.pca = "topleft", cleg = 0.75, xax = 1, yax = 2, inset.solid = 1)
library(reshape2)
dapc.results <- melt(dapc.results)
colnames(dapc.results) <- c("Original_Pop","Sample","Assigned_Pop","Posterior_membershiph_todo_probability")
p <- ggplot(dapc.results, aes(x=Sample, y=Posterior_membershiph_todo_probability, fill=Assigned_Pop))
p <- p + geom_bar(stat='identity') 
p <- p + scale_fill_manual(values = cols) 
p <- p + facet_grid(~Original_Pop, scales = "free")
p <- p + theme(axis.text.x = element_text(angle = 90, hjust = 1, size = 8))
p