library(FD)
library(readxl)
dataframe_matrix <- read_excel(file.choose())#upload the morphological matrix
View(matrix)
#leo matriz, Otus->son las filas
as.factor(ipheion$sp)->sp#columns sp indicates species
gowdis(ipheion[,3:19])->godis #gower distance 
#si se quiere exportar para ntsys
write.csv(dist_jar, file="gower_jar.csv")#hay que dejar la diagonal para abajo para que lo abra
library(ggplot2)
library(ggrepel) #to avoid labels from overlapping
#PCOA
library(ape)
pcoa<-(pcoa(godis, correction="none", rn = NULL))
pcoa1<-data.frame(pcoa$vectors,Species=sp)#lo convertis en dataframe
View(pcoa1)#lo miras
ggplot(pcoa1,aes(x=Axis.1,y=Axis.2,col=Species))+
geom_point(size=3,alpha=0.5)+ #Size and alpha just for fun
scale_color_manual(values = c("#FF1BB3","#A7FF5B","#99554D"))+ #your colors here
theme_classic()
pcoa$values#ves el aporte de los ejes
#cluter-UPGMA
plot(hclust(godis, "average"),labels =sp)
#only quantitative character
matrix[,3:12]->ipheion#remove qulitative columns
View(ipheion)
str(ipheion)#chequeas que tome los caracteres como numericos
Pearson_cor<-cor(ipheion, use="complete.obs", method = "pearson")
View(Pearson_cor)#chequeas matriz
#para hacer el heatmap del cluster de corr
library(corrplot)
corrplot(Pearson_cor, type = "upper", order = "hclust", tl.col = "black", tl.srt = 45)
matrix_da <- ipheion[, !(names(ipheion) %in% delete)]
#agrego las species
matrix_da$Species<-Ipheion$sp
View(matrix_da)
#Discriminant Analysis
set.seed(101)
total.size <- nrow(matrix_da)
total.size
# Select a subsampling (70%)
train.size <- round(55*0.7)
train.size
index <- sample(1:total.size , size=train.size)
train.data <- matrix_da[index,]
test.data <- matrix_da[-index,]
library(MASS)
library(klaR)
train.data.lda <- lda(formula= Species~. , data=train.data)
train.data.lda.p <- predict(train.data.lda, newdata=test.data, interval='confidence')
color <- rep("green",nrow(train.data))
color[train.data$Species == "tw"] <- "red"
color[train.data$Species == "uni"] <- "yellow"
color[train.data$Species == "rec"] <- "orange"
plot(ord, dimen=2, col=color, abbrev=3)
#PCA
library(ggfortify)
princomp(data[2:17])->pca #only characters
summary(pca)
#save results
write.csv(pca$loadings, "pca_loading.csv")
write.csv(pca$scores, "pca_scores.csv")
autoplot(pca, data=matrix, label = F, colour = "sp", loadings = TRUE, loadings.label = TRUE)
autoplot(pca, data=matrix, label = F, colour = "sp",col=c("orange", "blue"), loadings = FALSE, loadings.label = FALSE)#without loadings
#PC1 vs.PC3 with the help of https://huboqiang.cn/2016/03/03/RscatterPlotPCA
as.factor(matrix$sp)->sp
PoV <- as.matrix(pca$sdev^2/sum(pca$sdev^2))#Proportion of Variance 
round(PoV, 3)*100->rPoV
percentage <- paste( rownames(rPoV), "(", paste( as.character(rPoV), "%", ")", sep="") )
library(ggplot2)
ggplot(pca,aes(x=Comp.1,y=Comp.3,col=sp))->p
p<-p+geom_point()+theme_classic() + xlab(percentage[1]) + ylab(percentage[3])
p+scale_color_manual(values = c("orange","blue", "red")) #your colors here
dev.off()