library(data.table)
library(vcfR)
library(hierfstat)
library(StAMPP)
library(dartR)
samples<-fread("pob.csv", header = T)#read pop data
vcf<-read.vcfR("ipheion.vcf")#read vcf file per species (output from ipyrad)
head(vcf)
#transform vcf to genlight 
genlight<-vcfR2genlight(vcf)
genlight$pop<-as.factor(samples$Species)#specier or pop
genlsp<-genlight
genlsp$pop<-as.factor(samples$sp)
gl2gi(aa.genlight, probar = TRUE)->sps_genind
genind2hierfstat(sps_genind, pop=as.factor(samples$Species))->sps_hierfstat
View(sps_hierfstat)
sps_hierfstat
basic.stats(sps_genind, diploid=TRUE,digits=4)->basicstat_sps
write.table(basicstat_sps, "basicstats_3SPS.txt")
basicstat_sps
pairwise.WCfst(sps_hierfstat)->WCfst_pop
WCfst_pop
View(aa.genlight)
stamppFst(aa.genlight, nboots = 1000, percent = 95, nclusters = 3)->stamp_fst_sp
stamp_fst_sp
View(stamp_fst_sp)
basicstat_sps$overall
basicstat_sps$perloc
# wc(rechierf)#global fis and dst
write.table(basicstat_sps$Hs,"unistats_he.txt")
write.table(basicstat_sps$Ho,"unistats_ho.txt")
write.table(basicstat_sps$Fis,"unistats_fis.txt")