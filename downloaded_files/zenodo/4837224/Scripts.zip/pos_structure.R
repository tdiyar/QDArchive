setwd()#choose the directory where the results of structure analysis from ipyrad API
# load library
install.packages(c("ggplot2","gridExtra","label.switching","tidyr","remotes"),repos="https://cloud.r-project.org")
library(pophelper)
library(gridExtra)
sfiles <- list.files(path="./", full.names=T) # <-- Look carefully here! You must put in the path where you have put the results files. No other files can be in that directory!
# basic usage
slist <- readQ(files=sfiles, indlabfromfile=T)
readQ(files=sfiles,filetype="structure")
sr1 <- summariseQ(tabulateQ(slist))
write.csv(evannoMethodStructure(sr1), "evannoMethodStructure.csv", na = "")
p <- evannoMethodStructure(data=sr1,exportplot=F,returnplot=T,returndata=F,basesize=12,linesize=0.7)
grid.arrange(p)# save plots
#barplotsalignK 
p1 <- plotQ(alignK(slist[39]),returnplot=T,exportplot=F,basesize=11, showindlab = T, useindlab = T,indlabheight = 0.01 )#chose the replicate or list of replicates slists[]
grid.arrange(p1$plot[[1]])
#another option
p1 <- plotQ(sortQ(slist)[41:45],imgoutput="join",returnplot=T,exportplot=F,basesize=11,useindlab=T)
p2 <- plotQ(alignK(sortQ(slist)[36:40]),imgoutput="join",returnplot=T,exportplot=F,basesize=11, useindlab=T)
grid.arrange(p1$plot[[1]],p2$plot[[1]],ncol=2,nrow=1)