# State of CAQDAS

Systematic collection and evaluation of qualitative data analysis software.
We provide all datasets as CC0 and using only free+open formats 
(text, json, yaml, csv).

## Datasets

- [2025](./2025)

Each dataset contains the final data compilation plus the subsets and tools,
involved in the steps that lead to the final set.
All those aspects are described in their respective `summary.md` file.

## Goals and Methods

Our goal is to provide an extensive overview of **available**,
**relevant** and **complete** software for qualitative data analysis
(also known as CAQDAS; Computer Aided Qualitative Data AnalysiS) from
the perspective of various stakeholders, involved in QDA.

Since the specific definition of these criteria might be subject to change,
they are all described in each datasets' summary file.

## Contributing

We highly appreciate any form of contribution!
To make your contribution a success and a positive experience, please
make sure to get familiar with our [contribution guidelines](./CONTRIBUTING.md).

**A good starting point for is to open an issue or a discussion before 
opening pull requests.**

## License

All data and tools, used to collect it, are published under CC0.
